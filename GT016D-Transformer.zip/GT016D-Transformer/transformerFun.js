function myFun(inputData) {
  const rawData = inputData.data;
  const changeEndianness = (string) => {
    const result = [];
    let len = string.length - 2;
    while (len >= 0) {
      result.push(string.substr(len, 2));
      len -= 2;
    }
    return result.join("");
  };
  function hex2a(data) {
    let hex = data.toString();
    let str = "";
    for (let i = 0; i < hex.length; i += 2)
      str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
    return str;
  }
  function hexToBytes(hex) {
    for (var bytes = [], c = 0; c < hex.length; c += 2)
      bytes.push(parseInt(hex.substr(c, 2), 16));
    return bytes;
  }
  function fromIEEE754(bytes, ebits, fbits) {
    let bits = [];

    for (let i = bytes.length; i; i -= 1) {
      let byte = bytes[i - 1];
      for (let j = 8; j; j -= 1) {
        bits.push(byte % 2 ? 1 : 0);
        byte = byte >> 1;
      }
    }
    bits.reverse();
    let str = bits.join("");
    let bias = (1 << (ebits - 1)) - 1;
    let s = parseInt(str.substring(0, 1), 2) ? -1 : 1;
    let e = parseInt(str.substring(1, 1 + ebits), 2);
    let f = parseInt(str.substring(1 + ebits), 2);
    if (e === (1 << ebits) - 1) {
      return f !== 0 ? NaN : s * Infinity;
    } else if (e > 0) {
      return s * Math.pow(2, e - bias) * (1 + f / Math.pow(2, fbits));
    } else if (f !== 0) {
      return s * Math.pow(2, -(bias - 1)) * (f / Math.pow(2, fbits));
    } else {
      return s * 0;
    }
  }
  function fromIEEE754Double(b) {
    return fromIEEE754(b, 11, 52);
  }
  let data = {};
  let index = 0;
  let dataHeader = rawData.slice(index, index + 8);
  index = index + 8;
  let messageId = rawData.slice(index, index + 2);
  index = index + 2;
  if (messageId == "f6") {
    data.batVolt =
      20 * parseInt(changeEndianness(rawData.slice(index, index + 4)), 16);
    index = index + 4;
    data.stepNum = parseInt(
      changeEndianness(rawData.slice(index, index + 8)),
      16
    );
    index = index + 8;
    data.signalStrength = parseInt(rawData.slice(index, index + 2), 16);
    data.packetType = "battery";
    date = new Date();

    data.ts = Math.floor(date.getTime() / 1000);
    return data;
  } else if (messageId == "03") {
    data.lon = fromIEEE754Double(
      hexToBytes(changeEndianness(rawData.slice(index, index + 16)))
    );
    index = index + 16;
    data.lat = fromIEEE754Double(
      hexToBytes(changeEndianness(rawData.slice(index, index + 16)))
    );
    index = index + 16;
    data.northSouth = hex2a(rawData.slice(index, index + 2));
    index = index + 2;
    data.eastWest = hex2a(rawData.slice(index, index + 2));
    index = index + 2;
    data.status = hex2a(rawData.slice(index, index + 2));
    index = index + 2;
    data.packetType = "gps";
    date = new Date(
      parseInt(changeEndianness(rawData.slice(index, index + 8)), 16) * 1000
    );

    data.ts = Math.floor(date.getTime() / 1000);
    return data;
  } else if (messageId == "d8") {
    data.bpHigh = parseInt(
      changeEndianness(rawData.slice(index, index + 4)),
      16
    );
    index = index + 4;
    data.bpLow = parseInt(
      changeEndianness(rawData.slice(index, index + 4)),
      16
    );
    index = index + 4;
    data.bpHeart = parseInt(
      changeEndianness(rawData.slice(index, index + 4)),
      16
    );
    index = index + 4;
    temp1 = parseInt(changeEndianness(rawData.slice(index, index + 4)), 16);
    temp1 /= Math.pow(10, 1);
    data.temp = temp1;
    index = index + 4;
    data.packetType = "health";
    date = new Date(
      parseInt(changeEndianness(rawData.slice(index, index + 8)), 16) * 1000
    );

    data.ts = Math.floor(date.getTime() / 1000);

    return data;
  } else if (messageId == "b5") {
    data.status = parseInt(rawData.slice(index, index + 2), 16);
    data.packetType = "sos";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);
    return data;
  } else if (messageId == "16") {
    data.type = parseInt(rawData.slice(index, index + 2), 16);
    index = index + 2;
    value1 = parseInt(changeEndianness(rawData.slice(index, index + 4)), 16);
    value1 /= Math.pow(10, 1);
    data.value = value1;
    index = index + 4;
    data.packetType = "warning";
    date = new Date(
      parseInt(changeEndianness(rawData.slice(index, index + 8)), 16) * 1000
    );

    data.ts = Math.floor(date.getTime() / 1000);
    return data;
  }
}

console.log(
  myFun({
    cmd: "rx",
    EUI: "58508A880522E0207",
    data: "$LGN,abc,58508A880522E0207,3.2AIS,12.36,N,12.36,E",
  })
);
