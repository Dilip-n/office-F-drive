function myFun(inputData) {
  const rawData = inputData.data;
  let data = {};
  let index = 0;
  let messageId = rawData.slice(index + 6, index + 8);

  function getDate(date) {
    yy = parseInt(date.slice(0, 2), 16);
    mm = parseInt(date.slice(2, 4), 16);
    dd = parseInt(date.slice(4, 6), 16);
    hh = parseInt(date.slice(6, 8), 16);
    MM = parseInt(date.slice(8, 10), 16);
    ss = parseInt(date.slice(8, 10), 16);
    return `20${yy}-${mm}-${dd} ${hh}:${MM}:${ss}`;
  }
  //Login message
  if (messageId == 01) {
    data.packetType = "Login Message Packet";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);
    data.data = {
      startBit: rawData.slice(0, 4),
      packetLength: rawData.slice(4, 6),
      protocolNumber: rawData.slice(6, 8),
      deviceId: rawData.slice(8, 24),
      informationSerialNumber: parseInt(rawData.slice(24, 28)),
      errorCheck: rawData.slice(28, 32),
      stopBit: rawData.slice(32, 36),
    };
    return data;
  }
  //
  else if (messageId == 12) {
    data.packetType = "Location Data Packet";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);

    data.data = {
      startBit: rawData.slice(0, 4),
      packetLength: rawData.slice(4, 6),
      protocolNumber: rawData.slice(6, 8),
      gpsInformation: {
        dateTime: getDate(rawData.slice(8, 20)),
        quantityofGPSinformationsatellites: rawData.slice(20, 22),
        latitude: parseFloat(rawData.slice(22, 24)).toFixed(6),
        longitude: parseFloat(rawData.slice(24, 32)).toFixed(6),
        speed: parseInt(rawData.slice(32, 34)),
        courseStatus: rawData.slice(34, 38),
      },
      LBSInformation: {
        mcc: rawData.slice(38, 42),
        mnc: rawData.slice(42, 44),
        lac: rawData.slice(44, 48),
        cellId: rawData.slice(48, 54),
      },

      serialNumber: rawData.slice(54, 58),

      errorCheck: rawData.slice(58, 62),

      stopBit: rawData.slice(62, 66),
    };

    return data;
  }
  //Alarm Packet (
  else if (messageId == 16) {
    data.packetType = "Location Data Packet";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);

    data.data = {
      startBit: rawData.slice(0, 4),
      packetLength: rawData.slice(4, 6),
      protocolNumber: rawData.slice(6, 8),
      dateTime: getDate(rawData.slice(8, 20)),
      gpsInformation: {
        quantityOfGpsInformationSatellites: rawData.slice(20, 22),
        lat: rawData.slice(22, 30),
        lon: rawData.slice(30, 38),
        speed: rawData.slice(38, 40),
        courseStatus: rawData.slice(40, 44),
      },
      lbsInformation: {
        lbsLength: rawData.slice(44, 46),
        mcc: rawData.slice(46, 50),
        mnc: rawData.slice(50, 52),
        lac: rawData.slice(52, 56),
        cellId: rawData.slice(56, 68),
      },

      statusInformation: {
        terminalInformationContent: rawData.slice(68, 70),
        voltageLevel: rawData.slice(70, 72),
        gsmSignalStrength: rawData.slice(72, 74),
        alarmLanguage: rawData.slice(74, 78),
      },
      serialNumber: rawData.slice(78, 82),
      errorCheck: rawData.slice(82, 86),
      stopBit: rawData.slice(86, 90),
    };

    return data;
  }

  //Heartbeat Packet (status information pa cket)
  else if (messageId == 13) {
    data.packetType = "Heartbeat Packet";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);

    data.data = {
      startBit: rawData.slice(0, 4),

      packetLength: rawData.slice(4, 6),

      protocolNumber: rawData.slice(6, 8),

      statusInformation: {
        terminalInformationContent: rawData.slice(8, 10),
        voltageLevel: parseInt(rawData.slice(10, 12)),

        gsmSignalStrength: rawData.slice(12, 14),

        alarmLanguage: parseInt(rawData.slice(14, 18), 16),
      },

      serialNumber: rawData.slice(18, 22),

      errorCheck: rawData.slice(22, 26),

      stopBit: rawData.slice(26, 30),
    };
    return data;
  }
}

//Login Message

console.log(
  myFun({
    cmd: "rx",
    EUI: "58508A880522E0207",
    data: "78780D0158508A8805Z1020100018CDD0D0A",
  })
);

// Location Data Packet (combined information package of GPS and LBS)

// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "78781F120B081D112E10CC027AC7EB0C46584900148F01CC00287D001FB8000380810D0A",
//   })
// );

// Alarm packet
// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "787825160B0B0F0E241DCF027AC8870C4657E60014020901CC00287D001F726506040101003656A40D0A",
//   })
// );

//Heartbeat Packet (status information pa cket)
// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "787808134B040300010011061F0D0A",
//   })
// );
