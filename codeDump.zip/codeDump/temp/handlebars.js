const path = require("path");
var nodemailer = require("nodemailer");
var hbs = require("nodemailer-express-handlebars");

// let testAccount = await nodemailer.createTestAccount();

var transporter = nodemailer.createTransport({
  //  host: "smtp.gmail.com", //give your host name
  // host: "smtp.hyperthinksys.com",
  host: "mail.hyperthinksys.com", //give your host name
  port: 465,
  secure: true,
  // true, // true for 465, false for other ports
  auth: {
    // user: "dilipnntemp@gmail.com",
    // pass: "ABCD@1234",
    user: "notification@hyperthings.in",
    pass: "5fH6N+#-d3SfeU!C@",

    // pass: "Hw)8+WsG1ho&?SR-kY3",
  },
  tls: {
    // do not fail on invalid certs
    rejectUnauthorized: false,
  },
});
transporter.verify(function (error, success) {
  if (error) {
    console.log(error);
  } else {
    console.log("Server is ready to take our messages");
  }
});

const handlebarOptions = {
  viewEngine: {
    extName: ".handlebars",
    partialsDir: path.resolve("./views"),
    defaultLayout: false,
  },
  viewPath: path.resolve("./views"),
  extName: ".handlebars",
};

transporter.use("compile", hbs(handlebarOptions));

var mailOptions = {
  from: "dilip@hyperthings.in",
  // "dilip@hyperthings.in",
  to: "dilip@hyperthings.in",
  subject: "Sending Email using Node.js",
  template: "email",
  context: {
    // title: "Title Here",
    // text: "Lorem ipsum dolor sit amet, consectetur...",
    Italy: "bangalore",
  },
};

transporter.sendMail(mailOptions, function (error, info) {
  if (error) {
    console.log(error);
  } else {
    console.log("Email sent: " + info.response);
  }
});
