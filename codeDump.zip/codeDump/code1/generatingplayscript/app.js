// console.log("abc");
const nodemailer = require("nodemailer");
const fs = require("fs");
const excel = require("exceljs");
const fileName = "../../result.json";
const file = require(fileName);
const path = require("path");

var hbs = require("nodemailer-express-handlebars");

// let testAccount = await nodemailer.createTestAccount();

var transporter = nodemailer.createTransport({
  //  host: "smtp.gmail.com", //give your host name
  // host: "smtp.hyperthinksys.com",
  host: "mail.hyperthinksys.com", //give your host name
  port: 465,
  secure: true,
  // true, // true for 465, false for other ports
  auth: {
    // user: "dilipnntemp@gmail.com",
    // pass: "ABCD@1234",
    user: "notification@hyperthings.in",
    pass: "5fH6N+#-d3SfeU!C@",

    // pass: "Hw)8+WsG1ho&?SR-kY3",
  },
  tls: {
    // do not fail on invalid certs
    rejectUnauthorized: false,
  },
});
transporter.verify(function (error, success) {
  if (error) {
    console.log(error);
  } else {
    console.log("Server is ready to take our messages");
  }
});

const handlebarOptions = {
  viewEngine: {
    extName: ".handlebars",
    partialsDir: path.resolve("./views"),
    defaultLayout: false,
  },
  viewPath: path.resolve("./views"),
  extName: ".handlebars",
};

transporter.use("compile", hbs(handlebarOptions));

var mailOptions = {
  from: "dilip@hyperthings.in",
  // "dilip@hyperthings.in",
  to: "dilip@hyperthings.in",
  subject: "Sending Email using Node.js",
  template: "email",
  context: {
    bs: file.data[2].status,
    bls: file.data[2].login,
    tdc: file.data[2].ActiveDeviceCount,
    lut: file.data[2].LastupdatedAt,
    ms: file.data[3].status,
    mls: file.data[3].login,
    mtdc: file.data[3].ActiveDeviceCount,
    mlut: file.data[3].LastupdatedAt,
    vigs: file.data[4].status,
    vigls: file.data[4].login,
    vigtdc: file.data[4].ActiveDeviceCount,
    viglut: file.data[4].LastupdatedAt,
    diccs: file.data[6].status,
    diccs: file.data[6].login,
    diccdc: file.data[6].ActiveDeviceCount,
    dicclut: file.data[6].LastupdatedAt,
    // title: "Title Here",
    // text: "Lorem ipsum dolor sit amet, consectetur...",
    Italy: "bangalore",
  },
};

transporter.sendMail(mailOptions, function (error, info) {
  if (error) {
    console.log(error);
  } else {
    console.log("Email sent: " + info.response);
  }
});

// var xlsx = require("xlsx");

// const filePath = __dirname + "/assets/DAS1.xlsx";
// const workbook = xlsx.readFile(filePath);
// const worksheet = workbook.Sheets[workbook.SheetNames[0]];

// const data = xlsx.utils.sheet_to_html(worksheet, {
//   // header: "A",
//   // range: 9,
// });

// console.log(data);

// if (
//   cellAsString[1] !== "r" &&
//   cellAsString[1] !== "m" &&
//   cellAsString[1] > 1
// ) {
//   if (cellAsString[0] === "A") {
//     post.title = worksheet[cell].v;
//   }
//   if (cellAsString[0] === "B") {
//     post.author = worksheet[cell].v;
//   }
//   if (cellAsString[0] === "C") {
//     post.released = worksheet[cell].v;
//     posts.push(post);
//     post = {};
//   }
// }
//   console.log(cell);
// }

// (async () => {
//   var transporter = nodemailer.createTransport({
//     host: "mail.hyperthinksys.com", //give your host name
//     port: 465,
//     secure: true, // true for 465, false for other ports
//     auth: {
//       user: "notification@hyperthings.in",
//       pass: "Hw)8+WsG1ho&?SR-kY3",
//     },
//     tls: {
//       // do not fail on invalid certs
//       rejectUnauthorized: false,
//     },
//   });

//   const date = new Date();
//   let info = await transporter.sendMail({
//     from: "dilip@hyperthings.in", // sender address
//     to: "supriya.k@hyperthings.in,debajyoti@hyperthings.in,debajyotipanda1998@gmail.com,jayasankaran@hyperthinksys.com,aruleeswaran@hyperthings.in,darshan.ny@hyperthings.in,nikhil@hyperthings.in,dilip@hyperthings.in", // list of receivers
//     subject: "Health Check Report", // Subject line
//     //text: "Mongo DB running at {port} on {server} is down.Please look into it.", // plain text body
//     html: `<p>Dear Team,</p>
//                    <p>Here is the ${date.getDate()}-${date.getMonth()}-${date.getFullYear()} health check report of GCP application</p>
//                    <p>Thanks,</p>
//                    <p>Dilip</p>`,
//     // html body
//     attachments: [
//       {
//         filename: "DAS1.xlsx",
//         path: __dirname + "/assets/DAS1.xlsx",
//       },
//     ],
//   });
// })();
