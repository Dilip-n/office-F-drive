const { test, expect } = require("@playwright/test");
const { fmsBadalpurCreds } = require("../../config");

const fs = require("fs");
const fileName = "../../result.json";
const file = require(fileName);

const excel = require("exceljs");

test("test", async ({ page }) => {
  await page.goto(fmsBadalpurCreds.host + "/");

  await page.click('input[type="username"]');

  await page.fill('input[type="username"]', fmsBadalpurCreds.username);

  await page.click('input[type="password"]');

  await page.fill('input[type="password"]', fmsBadalpurCreds.password);

  await Promise.all([
    page.waitForNavigation(/*{ url: `${fmsBadalpurCreds.host}/dashboard` }*/),
    page.click('button:has-text("Login")'),
  ]);

  await page.waitForLoadState("networkidle");

  let workbook = new excel.Workbook();
  let worksheet;
  const url = await page.url();
  let value = "";
  if (url === `${fmsBadalpurCreds.host}/dashboard`) {
    value = "UP";
  } else {
    value = "Down";
  }

  console.log("Value", value);

  file.data[2].status = value;

  // result.fmsb.push({ status: value });

  await workbook.xlsx.readFile("assets/DAS1.xlsx");
  worksheet = workbook.getWorksheet("DAS");
  let cell = worksheet.getCell("E6");
  cell.value = value;

  if (value === "UP") {
    let cell = worksheet.getCell("F6");
    cell.value = "YES";
    file.data[2].login = "YES";
    // content.data[2].login = "YES";
    // result.fmsb.push({ login: "YES" });
  } else {
    let cell = worksheet.getCell("F6");
    cell.value = "No";
    file.data[2].login = "No";
    // content.data[2].login = "No";

    // result.fmsb.push({ login: "No" });
  }

  await new Promise((resolve) => setTimeout(resolve, 3000));
  const onlineDevice = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]"
  );
  const onlineDevice_innertext = await onlineDevice.innerText();

  console.log("online devices", onlineDevice_innertext);
  const totalDevice = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/span[2]"
  );
  const totalDevice_innertext = await totalDevice.innerText();

  console.log("total devices", onlineDevice_innertext + totalDevice_innertext);
  let cell1 = worksheet.getCell("G6");
  cell1.value = onlineDevice_innertext + totalDevice_innertext;
  // content.data[2].ActiveDeviceCount =
  file.data[2].ActiveDeviceCount =
    onlineDevice_innertext + totalDevice_innertext;

  // result.fmsb.push({
  //   ActiveDeviceCount: onlineDevice_innertext + totalDevice_innertext,
  // });

  //checking last updated time

  await page.click(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]"
  );

  await expect(page).toHaveURL(
    `${fmsBadalpurCreds.host}/devicesStatus?status=online`
  );

  const lastupdatedTime = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/span[1]"
  );
  const lastupdatedTime_innertext = await lastupdatedTime.innerText();

  console.log("last updateddevices", lastupdatedTime_innertext);

  let cell2 = worksheet.getCell("H6");
  cell2.value = lastupdatedTime_innertext;
  // content.data[2].lastupdatedTime = lastupdatedTime_innertext;
  // result.fmsb.push({
  //   LastupdatedAt: lastupdatedTime_innertext,
  // });
  file.data[2].LastupdatedAt = lastupdatedTime_innertext;

  workbook.xlsx.writeFile("assets/DAS1.xlsx").then(() => {
    console.log("sendmail");
  });

  // // var json = JSON.stringify(obj);
  //   "utf8", () => {
  //   console.log("data");
  // });

  fs.writeFile(fileName, JSON.stringify(file), function writeJSON(err) {
    if (err) return console.log(err);
    console.log(JSON.stringify(file.data[2]));
    console.log("writing to " + fileName);
  });
  // console.log("results", result.data[2]);

  // let bddlpurInfo = {
  //   value: value,
  //   totalDevices: onlineDevice_innertext + totalDevice_innertext,
  //   lastUpdatedTime: lastupdatedTime_innertext,
  // };
  // console.log("oneObj", bddlpurInfo);

  await page.click('button:has-text("Welcome KBMC,")');
  await page.click('button[role="menuitem"]:has-text("logout")');
  await expect(page).toHaveURL(fmsBadalpurCreds.host + "/login");
  await page.close();
});

// console.log("Value", value);
// console.log("total devices", onlineDevice_innertext + totalDevice_innertext);
// console.log("last updateddevices", lastupdatedTime_innertext);
