const { Kafka } = require("kafkajs");

const {
  kafkaHost,
  kafkaPort,
  kafkaPublishTopic,
  kafkaClientId,
} = require("./config");

const kafka = new Kafka({
  clientId: kafkaClientId,
  brokers: [`${kafkaHost}:${kafkaPort}`],
});
const kafkaProducer = kafka.producer();
(async () => {
  await kafkaProducer
    .connect()
    .then(() => {
      console.log("Kafka is Ready");
    })
    .catch((err) => {
      console.log("Crashed 2", err);
      process.exit(-1);
    });
})();

async function producer(payload) {
  await kafkaProducer.send(payload).then(() => {
    console.log("Data successfully sent to kafka topic");
  });
}

async function consumer(dataTopic, message) {
  await consumer.subscribe({ topic: dataTopic });

  await consumer.run({
    eachMessage: async (message) => {
      //parse topic data
      const task = JSON.parse(message.value);
      console.log(task);
    },
  });
}

module.exports = {
  producer,
};
