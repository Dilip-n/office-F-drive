"use strict";
// Import Config
const config = require("./config");

//Import Moment
const Moment = require("moment");
const kafkaProducer = require("./kafka");

(async () => {
  const mockDatad1 = async (deviceId, filePath) => {
    try {
      filePath = "./routes/" + filePath;
      const jsonData = require(filePath);
      const coordinatesArray = jsonData["coordinates"][0];
      for (let i = 0; i < coordinatesArray.length; i++) {
        let packetType = "nr";
        let today = Moment().format("YYYY-MM-DDTHH:mm:ss");

        if (i == 21 || i == 41 || i == 61 || i == 71) {
          packetType = "hb";
        }
        let dbSize = config.dbSize;
        let updData = {
          ts: Moment(today).unix(),
          data: {
            gf: "3D",
            a01: 48,
            lac: null,
            lat: parseFloat(coordinatesArray[i][1]),
            lon: parseFloat(coordinatesArray[i][0]),
            nfs: 9,
            pgn: null,
            sig: 13,
            spd: 1.36,
            //   csvData[i].Speed,
            tas: null,
            date: today,
            di01: null,
            di02: null,
            di03: null,
            di04: null,
            di05: null,
            di06: null,
            do01: null,
            do02: null,
            fspd: null,
            hdop: 0.76,
            //   parseFloat(csvData[i].HDOP),
            imei: deviceId,
            ispd: null,
            latD: "N",
            lonD: "E",
            pdop: 1.1,
            rfid: null,
            stat: 1010,
            temp: 32,
            time: today,
            //   csvtime,
            vdop: 0.69,
            //   parseFloat(csvData[i].VDOP),
            engOn: 1,
            seqNo: null,
            Others: {
              lac: null,
              mcc: null,
              mnc: null,
              firstNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
              thirdNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
              fourthNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
              secondNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
            },
            batCur: 50,
            batPer: 40,
            cellId: null,
            gpsAvi: 1,
            digInp1: 0,
            mileage: 2265,
            roamAct: 0,
            datafrom: "gps",
            distance: null,
            duration: null,
            direction: 65,
            packetType: packetType,
            packetStatus: "h",
          },
          deviceId: deviceId,
          deviceType: null,
        };
        let obj = {
          today,
          dbSize,
          deviceId,
          updData,
          deviceId,
          today,
        };
        const kafkaMessages = {
          appId: "6226e3672609a31ab76ea83b",
          tenantId: "K9gG4r",
          deviceId: deviceId,
          data: obj,
        };
        console.log(kafkaMessages);
        // let kafkaData = {
        //   topic: config.kafkaPublishTopic,
        //   messages: [{ value: JSON.stringify(kafkaMessages) }],
        // };

        kafkaProducer.producer(kafkaData);
      }
    } catch (err) {
      console.log("Error: ", err);
    }
  };
  const deviceIds = config.dbDeviceId;
  const filePaths = config.filePath;

  for (let i = 0; i < deviceIds.length; i++) {
    await mockDatad1(deviceIds[i], filePaths[i]);
  }
})();
