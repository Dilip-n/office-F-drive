"use strict";

module.exports = {
  dbHost: process.env.FTS_PGDB_HOST || "localhost",

  dbPort: process.env.FTS_PGDB_PORT || "54323",

  dbUser: process.env.FTS_PGDB_USERNAME || "master",

  dbPassword: process.env.FTS_PGDB_PASSWORD || "DHNNOQIYWMDZZPOQ",

  dbName: process.env.FTS_PGDB_NAME || "fts-app",

  dbDeviceId: process.env.FTS_PGDB_DEVICEID || [
    "351924100188670",
    "351924100188669",
  ],

  filePath: process.env.FTS_PGDB_FILEPATH || [
    "delhitonoida.json",
    "australia.json",
  ],

  dbSize: process.env.FTS_PGDB_SIZE || 960,

  rawDataSchema: process.env.FTS_RAW_DATA_SCHEMA || {
    gf: "3D",
    a01: 45,
    igs: 0,
    nfs: 9,
    sig: 13,
    hdop: 0.8,
    imei: "351924100188676",
    latD: "N",
    lonD: "E",
    pdop: 1.1,
    stat: 1010,
    temp: 33,
    vdop: 0.8,
    batPer: 40,
    gpsAvi: 1,
    idalTs: 300,
    digInp1: 1,
    mileage: 2267,
    roamAct: 0,
    datafrom: "gsm",
    direction: 68,
    packetType: "bd",
    packetStatus: "h",
  },

  // filePath: process.env.FTS_PGDB_FILEPATH || "data.csv",

  dbInterval: process.env.FTS_INTERVAL || 20,
  kafkaHost:
    process.env.DATA_HANDLER_KAFKA_HOST ||
    process.env.KAFKA_HOST ||
    "localhost",
  kafkaPort:
    process.env.DATA_HANDLER_KAFKA_PORT || process.env.KAFKA_PORT || "29092",
  kafkaPublishTopic: process.env.DATA_HANDLER_KAFKA_TOPIC_PUB || "testtopic",
};
