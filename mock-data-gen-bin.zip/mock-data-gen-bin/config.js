module.exports = {
  dbHost:
    process.env.BTS_MOCK_DATA_GEN_DB_HOST || process.env.DB_HOST || "localhost",

  dbPort:
    process.env.BTS_MOCK_DATA_GEN_DB_PORT || process.env.DB_PORT || "54323",

  dbName:
    process.env.BTS_MOCK_DATA_GEN_DB_NAME ||
    process.env.DB_NAME ||
    "bin-app-vig",

  dbUser:
    process.env.BTS_MOCK_DATA_GEN_DB_USER || process.env.DB_USER || "master",

  dbPassword:
    process.env.BTS_MOCK_DATA_GEN_DB_PASSWORD ||
    process.env.BTS_DB_PASSWORD ||
    "DHNNOQIYWMDZZPOQ",

  dbAppId: process.env.BTS_APPID || 1,

  dbSize: process.env.BTS_SIZE || 168,

  dbDeviceId: process.env.BTS_DEVICE_IDS || [
    "868326028242907",
    "868326028242909",
    "32646827342",
    "86832602256121",
  ],

  dbInterval: process.env.BTS_DAILY_CRON_JOB || "* * * * * *",
};
