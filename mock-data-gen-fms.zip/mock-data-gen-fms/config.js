"use strict";
module.exports = {
  dbHost:
    process.env.PGDB_HOST ||
    // "localhost",
    "35.206.94.22",

  dbPort:
    process.env.PGDB_PORT ||
    // "54323",
    "17002",

  dbName: process.env.PGDB_NAME || "fms-app",

  dbUser:
    process.env.PGDB_USERNAME ||
    // "master",
    "superuser",

  dbPassword:
    process.env.PGDB_PASSWORD ||
    // "DHNNOQIYWMDZZPOQ",
    "349hf34r90fh0348fh0er3f80342",

  dbAppId: process.env.FMS_APPID || 3,

  dbSize: process.env.FMS_PACKET_SIZE || 200,

  dbInsert: process.env.DB_INSERT || true,

  dbDuration: process.env.FMS_INSERT_DURATION || 10,

  dtIY: process.env.FMS_INSERT_YEAR || 2021,
  dtIM: process.env.FMS_INSERT_MONTH || "02",
  dtID: process.env.FMS_INSERT_DAY || "06",
};
