"use strict";
// Import Node-Cron
const cron = require("node-cron");
// Import Config
const config = require("./config");
// Import PostgreSQL
const { Client } = require("pg");
// Import moment
const moment = require("moment");
// Import Chance
const Chance = require("chance");
//Import PG Format
const pgFormat = require("pg-format");
// Instantiate Chance
const chance = new Chance();
//Import Objects to CSV
const ObjectsToCsv = require("objects-to-csv");
//Import Randomize
const randomize = require("randomatic");
const fs = require("fs");
const { time } = require("console");
// Import configs
const appId = config.dbAppId;
const size = config.dbSize;
const duration = config.dbDuration;
const insert = config.dbInsert;
let client = null;
(async () => {
  // DB Connection
  client = new Client({
    host: config.dbHost,
    user: config.dbUser,
    password: config.dbPassword,
    database: config.dbName,
    port: config.dbPort,
  });
  await client.connect();
  console.log("Database connected!");
})();
//Generating Random Dates
function randomDate(start, end) {
  return new Date(
    start.getTime() + Math.random() * (end.getTime() - start.getTime())
  );
}
// Generating mock-data
const mockData = async (input) => {
  try {
    let data = [];
    let date = input.split(" ");
    let year = date[0].split("-");
    let dt1 = new Date(`${year[0]}-${year[1]}-${year[2]}T${date[1]}`);
    let dt = new Date(`${year[0]}-${year[1]}-${year[2]}T${date[1]}`);
    dt.setMinutes(dt.getMinutes() - duration);
    let ts = moment(dt1).format("HH:mm");
    //Defining Feedback Values
    const feedback = [
      {
        value: 1,
        valueInWords: "good",
      },
      {
        value: 2,
        valueInWords: "average",
      },
      {
        value: 3,
        valueInWords: "dirty",
      },
    ];
    //Getting Random Feedback's
    function getRandom() {
      function randomInRange(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
      }
      const rndInt = randomInRange(0, feedback.length - 1);
      return feedback[rndInt];
    }
    //Storing Device ID From Database
    let devId = [];
    //Query to find 'deviceId' from 'devices' table w.r.t. 'appId'
    const query = `select "deviceId" from devices d where "appId" = ${appId}`;
    //Querying Data
    client.query(query, (err, res) => {
      if (err) {
        console.log("Error: ", err.stack);
      } else {
        // console.log("Device ID: ", res.rows);
        devId.push(res.rows);
      }
      if (ts >= "06:00" && ts <= "10:00") {
        for (let i = 0; i < devId[0].length; i++) {
          let length = randomize("0", 1);
          for (let j = 0; j < length; j++) {
            if (j < 3) {
              const rawData = {
                ts: moment(randomDate(dt1, dt)).format(),
                data: { data: getRandom() },
                deviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            } else {
              const rawData = {
                ts: moment(randomDate(dt1, dt)).format(),
                data: { data: getRandom() },
                deviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            }
          }
        }
      } else if (ts >= "10:00" && ts <= "16:00") {
        for (let i = 0; i < devId[0].length; i++) {
          let length = randomize("0", 1);
          for (let j = 0; j < length; j++) {
            if (j < 3) {
              const rawData = {
                ts: moment(randomDate(dt1, dt)).format(),
                data: { data: getRandom() },
                deviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            } else {
              const rawData = {
                ts: moment(randomDate(dt1, dt)).format(),
                data: { data: getRandom() },
                deviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            }
          }
        }
      } else if (ts >= "16:00" && ts <= "23:30") {
        for (let i = 0; i < devId[0].length; i++) {
          let length = randomize("0", 1);
          for (let j = 0; j < length; j++) {
            if (j < 3) {
              const rawData = {
                ts: moment(randomDate(dt1, dt)).format(),
                data: { data: getRandom() },
                deviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            } else {
              const rawData = {
                ts: moment(randomDate(dt1, dt)).format(),
                data: { data: getRandom() },
                deviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            }
          }
        }
      } else {
        data = [];
      }

      //Save data
      if (insert == true) {
        if (data.length > 0) {
          //Format data for DB Insert
          const tempArray = data.map((row) => {
            return [...Object.values(row), appId, size, row.deviceId, row.ts];
          });
          //Bulk Insert
          const query = pgFormat(
            `INSERT INTO raw_data("time","data","deviceId", "appId", "size", "dataFrom", "ingestTime") VALUES %L`,
            tempArray
          );
          client.query(query, (err, res) => {
            if (err) {
              console.log("Error: ", err.stack);
            } else {
              console.log(`${res.rowCount} Data inserted`);
            }
          });
        } else {
          console.log(`No Data to be inserted`);
        }
      } else {
        //Generating CSV File
        const csv = new ObjectsToCsv(data);
        csv.toDisk("./file.csv");
        console.log("Number of rows inserted: ", data.length);
      }
    });
  } catch (err) {
    console.log(err);
  }
};
//get days list
const getDaysArray = function (start, end) {
  let dayArray = [];
  for (let dt = new Date(start); dt <= end; dt.setDate(dt.getDate() + 1)) {
    dayArray.push(new Date(dt).toISOString().slice(0, 10));
  }
  return dayArray;
};
//get times array
const getTimesArray = function () {
  let times = []; // time array
  for (let i = 7; i < 23; ) {
    let u = "00";
    ["00", "59"].map((one) => {
      if (i < 10) u = `0${i}`;
      else u = i;
      times.push(`${u}:${one}`);
      if (one === "59") i++;
    });
  }
  return times;
};
let daylist = getDaysArray(new Date("2022-01-01"), new Date("2022-01-27"));
let timeList = getTimesArray();
// //2021 - OCT
// daylist = getDaysArray(new Date("2021-10-01"), new Date("2021-10-31"));
for (let i = 0; i < daylist.length; i++) {
  for (let index = 0; index < timeList.length; index++) {
    mockData(`${daylist[i]} ${timeList[index]}`);
  }
}
