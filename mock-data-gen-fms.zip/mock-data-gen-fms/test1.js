let timeArr = [];

for (let i = 6; i < 23; ) {
  ["00", "10", "20", "30", "40", "50"].map((one) => {
    timeArr.push(`${i}:${one}`);
    if (one === "50") i++;
  });
}
console.log(timeArr);
