"use strict";
// Import Node-Cron
const cron = require("node-cron");
// Import Config
const config = require("./config");
// Import PostgreSQL
const { Pool } = require("pg");
// Import moment
const moment = require("moment");
// Import Chance
const Chance = require("chance");
const pgFormat = require("pg-format");
// Instantiate Chance
const chance = new Chance();

// Defining column values
const appId = config.dbAppId;
const size = config.dbSize;
const deviceId = config.dbDeviceId;

// DB Connection
const pool = new Pool({
  host: config.dbHost,
  user: config.dbUser,
  password: config.dbPassword,
  database: config.dbName,
  port: config.dbPort,
});

// Generating mock-data
const mockData = async () => {
  try {
    cron.schedule(config.dbInterval, () => {
      let data = [];

      for (let i = 0; i < deviceId.length; i++) {
        let fill, temp;
        let time = moment().toISOString();
        let ts = moment(time).format("HH:mm");
        if (ts >= "08:00" && ts <= "12:00") {
          fill = 30;
          temp = chance.integer({ min: 25, max: 30 });
        } else if (ts >= "12:00" && ts <= "16:00") {
          fill = 60;
          temp = chance.integer({ min: 35, max: 40 });
        } else if (ts >= "16:00" && ts <= "18:00") {
          fill = 80;
          temp = chance.integer({ min: 30, max: 35 });
        } else {
          fill = 100;
          temp = chance.integer({ min: 25, max: 30 });
        }

        const rawData = {
          ts: moment().unix(),
          data: {
            ts: moment().unix(),
            gld: chance.integer({ min: 640, max: 650 }),
            lat: 12.9081357,
            lfl: chance.integer({ min: 10, max: 50 }),
            lng: 77.6476079,
            poi: 0,
            tbh: chance.integer({ min: 1400, max: 1500 }),
            ufl: chance.integer({ min: 60, max: 100 }),
            fill: fill,
            slNo: deviceId[i],
            temp: temp,
            alert: 13,
            tamper: 0,
            battery: 80,
            deviceId: deviceId[i],
          },
          deviceId: deviceId[i],
        };
        data.push([time, appId, size, deviceId[i], rawData, deviceId[i], time]);
      }
      //Bulk Insert
      const query = pgFormat(
        'INSERT INTO raw_data("time", "appId", "size", "deviceId", "data", "dataFrom", "ingestTime") VALUES %L',
        data
      );
      pool.query(query, (err, res) => {
        if (err) {
          console.log("Error: ", err.stack);
        } else {
          console.log(`${res.rowCount} Data inserted`);
        }
      });
    });
  } catch (err) {
    console.log(err);
  }
};

mockData();
