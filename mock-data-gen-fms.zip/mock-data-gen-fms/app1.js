"use strict";

// Import Config
const config = require("./config");
//Import Objects to CSV
const ObjectsToCsv = require("objects-to-csv");
// Import PostgreSQL
const { Client } = require("pg");
// Import moment
const moment = require("moment");
//Import PG Format
const pgFormat = require("pg-format");
//Import Randomize
const randomize = require("randomatic");

//connect to db
const appId = config.dbAppId;
const insert = config.dbInsert;
const size = config.dbSize;

let client = null;
(async () => {
  // DB Connection
  client = new Client({
    host: config.dbHost,
    user: config.dbUser,
    password: config.dbPassword,
    database: config.dbName,
    port: config.dbPort,
  });
  await client.connect();
  console.log("Database connected!");
})();

//get days list
var getDaysArray = function (start, end) {
  for (
    var arr = [], dt = new Date(start);
    dt <= end;
    dt.setDate(dt.getDate() + 1)
  ) {
    arr.push(new Date(dt));
  }
  return arr;
};
//2021 - Dec
// let daylist = getDaysArray(new Date("2021-12-01"), new Date("2021-12-31"));
//2021 - Nov
let daylist = getDaysArray(new Date("2021-11-01"), new Date("2021-11-30"));
// //2021 - OCT
// daylist = getDaysArray(new Date("2021-10-01"), new Date("2021-10-31"));
const dayArray = [];
daylist.forEach((element) => {
  dayArray.push(element.toISOString().slice(0, 10));
});

//get times array
var times = []; // time array
for (let i = 6; i < 23; ) {
  let u = "00";
  ["00", "10", "20", "30", "40", "50"].map((one) => {
    if (i < 10) u = `0${i}`;
    else u = i;
    times.push(`${u}:${one}`);
    if (one === "50") i++;
  });
}

const mockData = async (input) => {
  try {
    let data = [];
    let date = input.split(" ");
    let year = date[0].split("-");
    let ts = moment().format("HH:mm:ss");
    let dt = new Date(`${year[0]}-${year[1]}-${year[2]}T${date[1]}`);

    //Defining Feedback Values
    const feedback = [
      {
        value: 1,
        valueInWords: "good",
      },
      {
        value: 2,
        valueInWords: "average",
      },
      {
        value: 3,
        valueInWords: "dirty",
      },
    ];

    //Getting Random Feedback's
    function getRandom() {
      function randomInRange(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
      }
      const rndInt = randomInRange(0, feedback.length - 1);
      return feedback[rndInt];
    }

    //Storing Device ID From Database
    let devId = [];

    //Query to find 'deviceId' from 'devices' table w.r.t. 'appId'
    const query = `select "deviceId" from devices d where "appId" = ${appId}`;

    //Querying Data
    client.query(query, (err, res) => {
      if (err) {
        console.log("Error: ", err.stack);
      } else {
        devId.push(res.rows);
      }

      if (ts >= "06:00" && ts <= "10:00") {
        for (let i = 0; i < devId[0].length; i++) {
          let length = randomize("0", 1);
          for (let j = 0; j < length; j++) {
            if (j < 3) {
              const rawData = {
                ts: Math.floor(dt.getTime() / 1000),
                data: getRandom(),
                DeviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            } else {
              const rawData = {
                ts: Math.floor(dt.getTime() / 1000),
                data: getRandom(),
                DeviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            }
          }
        }
      } else if (ts >= "10:00" && ts <= "16:00") {
        for (let i = 0; i < devId[0].length; i++) {
          let length = randomize("0", 1);
          for (let j = 0; j < length; j++) {
            if (j < 3) {
              const rawData = {
                ts: Math.floor(dt.getTime() / 1000),
                data: getRandom(),
                DeviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            } else {
              const rawData = {
                ts: Math.floor(dt.getTime() / 1000),
                data: getRandom(),
                DeviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            }
          }
        }
      } else if (ts >= "16:00" && ts <= "23:30") {
        for (let i = 0; i < devId[0].length; i++) {
          let length = randomize("0", 1);
          for (let j = 0; j < length; j++) {
            if (j < 3) {
              const rawData = {
                ts: Math.floor(dt.getTime() / 1000),
                data: getRandom(),
                DeviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            } else {
              const rawData = {
                ts: Math.floor(dt.getTime() / 1000),
                data: getRandom(),
                DeviceId: devId[0][i].deviceId,
              };
              data.push(rawData);
              data.sort(function (a, b) {
                return a.ts < b.ts ? -1 : 1;
              });
            }
          }
        }
      } else {
        data = [];
      }
      // console.log(data);

      //Save data`
      if (insert == true) {
        if (data.length > 0) {
          // Format data for DB Insert
          const tempArray = data.map((row) => {
            return [dt, row, row.DeviceId, appId, size, row.DeviceId, dt];
          });

          //Bulk Insert
          const query = pgFormat(
            `INSERT INTO raw_data("time","data","deviceId", "appId", "size", "dataFrom", "ingestTime") VALUES %L`,
            tempArray
          );
          client.query(query, (err, res) => {
            if (err) {
              console.log("Error: ", err.stack);
            } else {
              console.log(`${res.rowCount} Data inserted`);
            }
          });
        } else {
          console.log(`No Data to be inserted`);
        }
      } else {
        //Generating CSV File
        const csv = new ObjectsToCsv(data);
        csv.toString.toDisk("./fms.csv");
        console.log("Number of rows inserted: ", data.length);
      }
    });
  } catch (err) {
    console.log(err);
  }
};
const dateArray = dayArray;
const timeArray = times;
for (let i = 0; i < dateArray.length; i++) {
  for (let index = 0; index < timeArray.length; index++) {
    mockData(`${dateArray[i]} ${timeArray[index]}`);
  }
}
