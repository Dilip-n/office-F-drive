const fetch = require("node-fetch");
const config = require("../config");
const logger = require("../handlers/logHandler");

async function getApps(token) {
  let fetchParams = {
    method: "get",
    headers: { Authorization: `Bearer ${token}` },
  };
  try {
    let url = `${config.iotpfDsApi}/apps`;
    console.log("app url ", url);
    let response = await fetch(url, fetchParams);
    response = await response.json();

    console.log("app response : ", response);

    if (response.success) {
      return response.data.results;
    } else {
      return [];
    }
  } catch (err) {
    logger.error("Apps fetch error");
    logger.error(err);
    return [];
  }
}

async function getDevices(token) {
  let fetchParams = {
    method: "get",
    headers: { Authorization: `Bearer ${token}` },
  };
  try {
    let url = `${config.iotpfDsApi}/devices`;
    // console.log(url);
    let response = await fetch(url, fetchParams);
    response = await response.json();
    console.log("device response : ", response);
    if (response.success) {
      return response.data.results;
    } else {
      return [];
    }
  } catch (err) {
    logger.error("Devices fetch error");
    logger.error(err);
    return [];
  }
}

async function getSites(token) {
  let fetchParams = {
    method: "get",
    headers: { Authorization: `Bearer ${token}` },
  };
  try {
    let response = await fetch(`${config.iotpfDsApi}/sites`, fetchParams);
    response = await response.json();
    console.log("sites response : ", response);
    if (response.success) {
      return response.data.results;
    } else {
      return [];
    }
  } catch (err) {
    logger.error("Sites fetch error");
    logger.error(err);
    return [];
  }
}

async function getData(deviceId, from, to, token) {
  let fetchParams = {
    method: "get",
    headers: { Authorization: `Bearer ${token}` },
  };
  try {
    let url = `${config.iotpfDsApi}/devices/${deviceId}/data?fromDate=${from}&toDate=${to}`;
    console.log("am in get data", url);
    let response = await fetch(url, fetchParams);
    response = await response.json();
    console.log("data response : ", response);
    //console.log(response);
    if (response.success) {
      return response.data.results;
    } else {
      return [];
    }
  } catch (err) {
    logger.error("Data fetch error");
    logger.error(err);
    return [];
  }
}

async function getDeviceStatus(from, to, token) {
  let fetchParams = {
    method: "get",
    headers: { Authorization: `Bearer ${token}` },
  };
  try {
    let url = `${config.iotpfDsApi}/deviceStatus/data?fromDate=${from}&toDate=${to}`;
    console.log(
      "================================================================"
    );
    console.log("am in get device status", url);
    let response = await fetch(url, fetchParams);
    response = await response.json();
    //console.log(response);
    if (response.success) {
      return response.data.results;
    } else {
      return [];
    }
  } catch (err) {
    logger.error("Data fetch error");
    logger.error(err);
    return [];
  }
}

module.exports = {
  getApps,
  getDevices,
  getData,
  getSites,
  getDeviceStatus,
};
