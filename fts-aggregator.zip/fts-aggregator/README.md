## Environment variables

| Parameter       | Application specific | global        | default                                    |
| --------------- | -------------------- | ------------- | ------------------------------------------ |
| pgdbHost        | FMS_PGDB_HOST        | PGDB_HOST     | 'iot.hyperthings.in'                       |
| pgdbPort        | FMS_PGDB_PORT        | PGDB_PORT     | '17060'                                    |
| pgdbIsAuth      | FMS_PGDB_IS_AUTH     | PGDB_IS_AUTH  | 'true'                                     |
| pgdbUsername    | FMS_PGDB_USERNAME    | PGDB_USERNAME | 'root'                                     |
| pgdbPassword    | FMS_PGDB_PASSWORD    | PGDB_PASSWORD | 'hdsgfhgrd6346tyhg436'                     |
| pgDbName        | FMS_PGDB_NAME        | PGDB_NAME     | 'fms-app'                                  |
| iotpfDsApi      | FMS_DS_API           | DS_API        | 'http://iot.hyperthings.in:7000/ds/api/v1' |
| iotpfDsApiKey   | FMS_DS_API_KEY       | DS_API_KEY    | 'api-key'                                  |
| refreshInterval | FMS_REFRESH_INTERVAL |               | '600'                                      |
