const winston = require("winston");
const { combine, timestamp, json, printf } = winston.format;
const constants = require("../utils/constants");

const loggerFormat = printf(({ level, message, timestamp }) => {
  return `${timestamp} [${constants.appName}] ${level}: ${JSON.stringify(
    message
  )}`;
});

const logger = winston.createLogger({
  level: "info",
  format: combine(timestamp(), json(), loggerFormat),
  defaultMeta: { service: "mqtt-data-handler" },
  transports: [
    new winston.transports.Console({
      level: "info",
      format: combine(timestamp(), json(), loggerFormat),
    }),
    new winston.transports.File({
      filename: "./logs/error.log",
      level: "error",
    }),
    new winston.transports.File({ filename: "./logs/combined.log" }),
  ],
});

module.exports = logger;
