const ON_DEATH = require("death");
const fetch = require("node-fetch");
const _ = require("lodash");

const config = require("./config");
const logger = require("./handlers/logHandler");

const pool = require("./handlers/pgHandler");
const {
  getApps,
  getData,
  getDevices,
  getSites,
  getDeviceStatus,
} = require("./utils/dsUtil");

// Metrics related
const promClient = require("prom-client");
const http = require("http");

// Metrics Setup

const collectDefaultMetrics = promClient.collectDefaultMetrics;
const Registry = promClient.Registry;
const register = new Registry();

collectDefaultMetrics({ register });

async function main() {
  const refreshApps = async () => {
    logger.info("Refreshing Apps");
    return new Promise((resolve, reject) => {
      let appQuery = `SELECT * FROM public.apps;`;
      pool.query(appQuery).then((result) => {
        logger.info(`Got ${result.rows.length} apps`);
        const apps = result.rows;
        // Update or insert each of the apps
        if (apps.length) {
          Promise.all(
            apps.map((app) => {
              return new Promise((resolve, reject) => {
                getApps(config.iotpfDsApiKey).then((newApp) => {
                  // console.log("app info ", newApp);
                  let query = `INSERT INTO public.apps
        ("name", status, "appId", address, "appUrl", "desc", "token", "createdAt", "updatedAt")
        VALUES($1, $2, $3, $4, $5, $6, $7, now(), now())
        ON CONFLICT ("appId") DO UPDATE
        SET "name"=excluded."name",
            status=excluded.status,
            address=excluded.address,
            "appUrl"=excluded."appUrl",
            "desc"=excluded."desc",
            "token"=excluded."token",
            "updatedAt"=excluded."updatedAt";
        `;
                  pool
                    .query(query, [
                      newApp.name,
                      newApp.status,
                      newApp.appId,
                      newApp.address,
                      newApp.appUrl,
                      newApp.desc,
                      newApp.token,
                    ])
                    .then((result) => {
                      console.log("result ", result);
                      logger.info(`Updated app ${newApp.appId}:${newApp.name}`);

                      refreshSites(app.id, newApp.token);
                      refreshDevices(app.id, newApp.token).then(() => {
                        refreshData(app.id, newApp.token);
                        resolve(apps);
                      });
                    })
                    .catch((err) => reject(err));
                });
              });
            })
          )
            .then(() => {
              // Remove the sites which are deleted
              query = `DELETE FROM apps WHERE "appId"!= all($1) RETURNING *;`;
              return pool.query(query, [apps.map((app) => app.appId)]);
            })

            .then((results) => {
              if (results.rows.length) {
                results.rows.map((row) => {
                  logger.info(
                    `Deleted Orphaned app ${row.appId}:${row.name} successfully`
                  );
                });
              } else {
                logger.info("No app orphans to delete");
              }
              resolve();
            })
            .catch((err) => reject(err));
        }
      });
    });
  };

  const refreshData = (appId, token) => {
    let query = `SELECT "deviceId" FROM devices`;
    pool
      .query(query)
      .then((results) => {
        return Promise.all(
          results.rows.map((device) => {
            return new Promise((resolve, reject) => {
              let time = new Date().getTime() / 1000;
              logger.info(
                `Updating ${device.deviceId}, ${
                  time - config.refreshInterval
                }, ${time}`
              );
              getData(
                device.deviceId,
                Math.ceil(time - config.refreshInterval),
                Math.ceil(time),
                token
              )
                .then(async (raw_datas) => {
                  logger.info(
                    `Got ${raw_datas.length} new messages for ${device.deviceId}`
                  );
                  return Promise.all(
                    await raw_datas.map(async (raw_data) => {
                      const query1 = `INSERT INTO public.raw_data
("time", "size", "deviceId", "data", "dataId", "dataFrom", "appId", "ingestTime")
VALUES($1, $2, $3, $4, $5, $6, $7, now() ) returning id;
`;

                      let data1 = await pool.query(query1, [
                        raw_data.time,
                        raw_data.size,
                        raw_data.device_id,
                        JSON.stringify(raw_data.data),
                        raw_data.id,
                        raw_data.data_from,
                        appId,
                      ]);

                      if (raw_data.data.packetType != "nr") {
                        const query1 = `INSERT INTO public.alerts
                        ("time", "size", "deviceId", "data", "dataId", "dataFrom", "appId", "ingestTime")
                        VALUES($1, $2, $3, $4, $5, $6, $7, now() ) returning id;
                        `;

                        let data1 = await pool.query(query1, [
                          raw_data.time,
                          raw_data.size,
                          raw_data.device_id,
                          JSON.stringify(raw_data.data),
                          raw_data.id,
                          raw_data.data_from,
                          appId,
                        ]);
                      }

                      resolve(data);
                    })
                  );
                })
                .then((result) => logger.info(`---Successfully inserted `));
            });
          })
        );
      })
      .then(async (finalResult) => {
        logger.info(`Processed all device Ids for messages `);
      })
      .catch((err) => console.log(err));
  };

  const refreshSites = async (appId, token) => {
    return new Promise((resolve, reject) => {
      logger.info("Refreshing Sites");
      getSites(token).then(async (sites) => {
        logger.info(`Got ${sites.length} sites`);
        // Update or insert each of the sites
        if (sites.length) {
          Promise.all(
            sites.map((site) => {
              return new Promise((resolve, reject) => {
                let query = `INSERT INTO sites
("name", "siteId", lat, lng, address, "parentId", "appId", "createdAt", "updatedAt")
VALUES($1, $2, $3, $4, $5, $6, $7, now(), now()) 
ON CONFLICT ("siteId") DO UPDATE 
SET name = excluded.name, 
    lat = excluded.lat,
    lng = excluded.lng,
    address = excluded.address,
    "parentId" = excluded."parentId",
     "appId" = excluded."appId",
    "updatedAt" = excluded."updatedAt";
`;
                pool
                  .query(query, [
                    site.name,
                    site._id,
                    site.lat,
                    site.lng,
                    site.address,
                    site.parentId,
                    appId,
                  ])
                  .then((result) => {
                    logger.info(`Updated site ${site._id}:${site.name}`);
                    resolve();
                  })
                  .catch((err) => reject(err));
              });
            })
          )
            .then((results) => {
              // Remove the sites which are deleted
              query = `DELETE FROM sites WHERE "siteId"!= all($1) RETURNING *;`;
              return pool.query(query, [sites.map((site) => site._id)]);
            })

            .then((results) => {
              if (results.rows.length) {
                results.rows.map((row) => {
                  logger.info(
                    `Deleted Orphaned site ${row.siteId}:${row.name} successfully`
                  );
                });
              } else {
                logger.info("No site orphans to delete");
              }
              resolve();
            })
            .catch((err) => reject(err));
        }
      });
    });
  };
  const refreshDevices = async (appId, token) => {
    return new Promise((resolve, reject) => {
      logger.info("Refreshing Devices");
      getDevices(token).then((devices) => {
        logger.info(`Got ${devices.length} devices`);
        // Update or insert each of the devices
        if (devices.length) {
          Promise.all(
            devices.map((device) => {
              return new Promise((resolve, reject) => {
                let query = `INSERT INTO public.devices
("isActive", state, "deviceId", "name", "macAddress", gateway, "mfrId", "addedBy", "protocolType", lat, lng, address, site, "appId", "createdAt", "updatedAt")
VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, now(), now()) 
ON CONFLICT ("deviceId") DO UPDATE 
SET "isActive"=excluded."isActive",
    state=excluded.state,
    "name"=excluded."name",
    "macAddress"=excluded."macAddress",
    gateway=excluded.gateway,
    "mfrId"=excluded."mfrId",
    "addedBy"=excluded."addedBy",
    "protocolType"=excluded."protocolType",
    lat=excluded.lat,
    lng=excluded.lng,
    address=excluded.address,
    site=excluded.site,
     "appId" = excluded."appId",
    "updatedAt"=excluded."updatedAt";
`;
                pool
                  .query(query, [
                    device.is_active,
                    device.state,
                    device.deviceId,
                    device.name,
                    device.macAddress,
                    device.gateway,
                    device.mfrId,
                    device.addedBy,
                    device.protocolType,
                    device.lat,
                    device.lng,
                    device.address,
                    device.site,
                    appId,
                  ])
                  .then((result) => {
                    logger.info(
                      `Updated device ${device.deviceId}:${device.name}`
                    );
                    resolve(device);
                  })
                  .catch((err) => reject(err));
              });
            })
          )
            .then(() => {
              // Remove the sites which are deleted
              query = `DELETE FROM devices WHERE "deviceId"!= all($1) RETURNING *;`;
              return pool.query(query, [
                devices.map((device) => device.deviceId),
              ]);
            })

            .then((results) => {
              if (results.rows.length) {
                results.rows.map((row) => {
                  logger.info(
                    `Deleted Orphaned device ${row.deviceId}:${row.name} successfully`
                  );
                });
              } else {
                logger.info("No device orphans to delete");
              }
              resolve();
            })
            .catch((err) => reject(err));
        }
      });
    });
  };
  refreshApps();
  // Setup the refresh timer
  refrestTimer = setInterval(() => {
    refreshApps();
  }, config.refreshInterval * 1000);

  http
    .createServer(function (req, res) {
      res.writeHead(200, {
        "Content-Type": "text/plain",
      });
      res.write(register.metrics());
      res.end();
    })
    .listen(8742);

  ON_DEATH(function (signal, err) {
    clearInterval(refrestTimer);
    logger.info("Died gracefully");
    process.exit();
  });
}
if (require.main === module) {
  main();
}
