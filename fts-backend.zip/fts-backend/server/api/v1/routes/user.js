"use strict";
//Import Koa Router
const Router = require("koa-router");
//Instantiate Router
const router = new Router();
//Import Controller
const Controller = require("./../controllers/user");
//Import Auth - Middleware
const Auth = require("./../middlewares/auth");
/*
 
! User Routes

*/
//Signin
router.post("/signin", Controller.signin);

//Get local Users
router.get("/", Auth.jwtAuth, Controller.getAllUsers);

//Add local User
router.post("/", Auth.jwtAuth, Controller.addUser);

//Delete local User
router.delete("/:userId", Auth.jwtAuth, Controller.deleteUser);

//Add Staff
router
  .post("/drivers", Auth.jwtAuth, Controller.addDriver)
  .use(router.allowedMethods());

//Get all Staffs
router.get("/drivers", Auth.jwtAuth, Controller.getDrivers);

//Update Staff
router.patch("/drivers/:userId", Auth.jwtAuth, Controller.updateDriver);

//Delete Staff
router.delete("/drivers/:userId", Auth.jwtAuth, Controller.deleteDriver);

//Get logged in user profile
router.get("/profile", Auth.jwtAuth, Controller.getProfile);

//Update profile
router.patch("/profile", Auth.jwtAuth, Controller.updateProfile);

//Export
module.exports = router;
