module.exports = (input = {}) => {
  const Schema = {
    User: {
      id: {
        type: input.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      name: input.STRING,
      email: input.STRING,
      mobile: input.STRING,
      password: input.STRING,
      address: input.STRING,
      isAdmin: input.STRING,
      isStaff: input.STRING,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    Device: {
      id: {
        type: input.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      isActive: input.BOOLEAN,
      state: input.BOOLEAN,
      deviceId: input.BIGINT,
      name: input.STRING,
      macAddress: input.STRING,
      gateway: input.BOOLEAN,
      mfrId: input.STRING,
      addedBy: input.STRING,
      protocolType: input.STRING,
      lat: input.STRING,
      lng: input.STRING,
      address: input.STRING,
      site: input.STRING,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    RawData: {
      time: {
        type: input.DATE,
        allowNull: false,
      },
      id: {
        type: input.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      deviceId: {
        type: input.STRING,
        allowNull: false,
      },
      data: {
        type: input.JSONB,
        allowNull: false,
      },
    },
    Driver: {
      id: {
        type: input.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      userId: input.INTEGER,
      dob: input.DATE,
      city: input.STRING,
      emMobileNo: input.STRING,
      deviceId: input.STRING,
      emp: input.STRING,
      licenseNo: input.STRING,
      licenseExpiredAt: input.DATE,
      idCardNo: input.STRING,
      bloodGroup: input.STRING,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    Vehicle: {
      id: {
        type: input.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      deviceId: input.BIGINT,
      name: input.STRING,
      imei: input.STRING,
      vehicleNo: input.STRING,
      vehicleType: input.INTEGER,
      owner: input.STRING,
      engineNo: input.STRING,
      chassisNo: input.STRING,
      make: input.STRING,
      yearOfMfg: input.STRING,
      unladenWeight: input.STRING,
      serviceDate: input.DATE,
      nextService: input.DATE,
      insuranceNo: input.STRING,
      insurancePeriod: input.STRING,
      insuranceDate: input.STRING,
      roadTaxNo: input.STRING,
      roadTaxPeriod: input.STRING,
      roadTaxRenewDate: input.STRING,
      simCardSerialNo: input.STRING,
      mobileNo: input.STRING,
      existingPlan: input.STRING,
      planValidity: input.STRING,
      polygonId: input.INTEGER,
      routeId: input.INTEGER,
      odoNumber: input.STRING,
      rfidNo: input.STRING,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    Route: {
      name: input.STRING,
      route: {
        type: input.JSONB,
        allowNull: false,
      },
      status: input.BOOLEAN,
      startedAt: input.DATE,
      completedAt: input.DATE,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    Polygon: {
      name: input.STRING,
      polygon: {
        type: input.JSONB,
        allowNull: false,
      },
      status: input.BOOLEAN,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    Unit: {
      id: {
        type: input.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      name: {
        type: input.STRING,
        allowNull: true,
      },
      ref: {
        type: input.STRING,
        allowNull: false,
      },
      uom: {
        type: input.STRING,
        allowNull: true,
      },
      format: {
        type: input.STRING,
        allowNull: true,
      },
    },
    VehicleTypes: {
      id: {
        type: input.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      name: {
        type: input.STRING,
        allowNull: true,
      },
    },
    Alert: {
      id: {
        type: input.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      time: {
        type: input.DATE,
        allowNull: false,
      },
      alertType: {
        type: input.STRING,
        allowNull: false,
      },
      alertLevel: {
        type: input.INTEGER,
        allowNull: false,
      },
      deviceId: {
        type: input.STRING,
        allowNull: false,
      },
      data: {
        type: input.JSONB,
        allowNull: false,
      },
      severity: {
        type: input.INTEGER,
        allowNull: false,
      },
      resolved: {
        type: input.BOOLEAN,
        allowNull: false,
      },
      resolvedBy: {
        type: input.INTEGER,
        allowNull: false,
      },
      resolvedAt: {
        type: input.DATE,
        allowNull: false,
      },
      desc: {
        type: input.STRING,
        allowNull: true,
      },
    },
  };
  //User Schema final
  const { password, ...UserSchema } = Schema.User;
  //Device Schema final
  const { isActive, ...DeviceSchema } = Schema.Device;
  //Raw data Schema final
  const { ...RawDataSchema } = Schema.RawData;
  //Driver Schema final
  const { ...DriverSchema } = Schema.Driver;
  //Vehicle Schema final
  const { ...VehicleSchema } = Schema.Vehicle;
  //Route Schema final
  const { ...RouteSchema } = Schema.Route;
  //Polygon Schema final
  const { ...PolygonSchema } = Schema.Polygon;
  //Vehicle types
  const { ...VTSchema } = Schema.VehicleTypes;
  //Alert Schema
  const { ...AlertSchema } = Schema.Alert;
  //Return
  return {
    Schema,
    UserSchema,
    DeviceSchema,
    RawDataSchema,
    DriverSchema,
    VehicleSchema,
    RouteSchema,
    PolygonSchema,
    VTSchema,
    AlertSchema,
  };
};
