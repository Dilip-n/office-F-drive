"use strict";
//Import Schema
const Schema = require("./Schema");

module.exports = (sequelize, DataTypes) => {
  const polygonSchema = Schema(DataTypes).Schema.Polygon;
  const Polygon = sequelize.define("polygon", polygonSchema);
  Polygon.associate = function (models) {
    // associations can be defined here
  };
  return Polygon;
};
