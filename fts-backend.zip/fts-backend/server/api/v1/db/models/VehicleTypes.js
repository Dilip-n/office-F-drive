"use strict";
//Import Schema
const Schema = require("./Schema");
module.exports = (sequelize, DataTypes) => {
  const vtSchema = Schema(DataTypes).Schema.VehicleTypes;
  const VT = sequelize.define("vehicle_types", vtSchema, {
    // don't add the timestamp attributes (updatedAt, createdAt)
    timestamps: false,
    // your other configuration here
  });
  VT.associate = function (models) {
    // associations can be defined here
  };
  return VT;
};
