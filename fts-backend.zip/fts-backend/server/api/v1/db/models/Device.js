"use strict";
//Import Schema
const Schema = require("./Schema");
module.exports = (sequelize, DataTypes) => {
  const deviceSchema = Schema(DataTypes).Schema.Device;
  const Device = sequelize.define("device", deviceSchema);

  Device.associate = function (models) {
    Device.hasOne(models.vehicle, {
      foreignKey: {
        allowNull: false,
        name: "deviceId",
      },
      sourceKey: "deviceId",
    });
  };
  return Device;
};
