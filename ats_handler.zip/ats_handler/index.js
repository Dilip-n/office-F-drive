const manageIntervalApiCall = require("./helper/intervalCall")

const dev = [2222331,936532,2222331,2323223];
const rawPacket = {
  cmd: "rx",
  seqno: 6372537,
  EUI: "2222331",
  ts: 1643103988120,
  fcnt: 349,
  port: 100,
  freq: 915600000,
  rssi: -93,
  snr: 11.5,
  toa: 226,
  dr: "SF9 BW125 4/5",
  ack: false,
  bat: 77,
  offline: false,
  data: "0001a9108aec2545213a9a45c39bc64701",
};


const data = dev.map((v) => {
  const mapData = { ...rawPacket };
  mapData.EUI = v;
  mapData.ts = null
  return mapData;
});

const filterData = data.filter(v => v.cmd == "rx" && v.EUI )

manageIntervalApiCall(filterData);



