module.exports = {
    appEnv: process.env.NODE_ENV || "dev",
    appLog: process.env.APP_LOG || "dev",
  
    pgdbHost:
      process.env.SSSS_PGDB_HOST || process.env.PGDB_HOST || "localhost",
    pgdbPort: process.env.SSSS_PGDB_PORT || process.env.PGDB_PORT || "54323",
    pgdbIsAuth:
      process.env.SSSS_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || "true",
    pgdbUsername:
      process.env.SSSS_PGDB_USERNAME || process.env.PGDB_USERNAME || "master",
    pgdbPassword:
      process.env.SSSS_PGDB_PASSWORD ||
      process.env.PGDB_PASSWORD ||
      "DHNNOQIYWMDZZPOQ",
    pgDbName: process.env.PGDB_NAME || "ats-app",
  
    iotPFAppToken:
      process.env.IOT_PF_APP_TOKEN ||
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRJZCI6IjVlOTlhOTAzMTQyMWZmMDAxOTk2Y2ZlNCIsImFwcElkIjoiNjYzNTI0ODIxNTMwNjQ5MyIsImlhdCI6MTY0MjY4Mjg3Mn0.4QCBSps6oZJDiMKEEoC8q18mc-_lBUSIyLzeoqPquD0",
  
    iotPFDSAPI: process.env.IOT_PF_DS_API || "http://iot.hyperthings.in:17016/api/v1",
  
    DeviceAddress: process.env.IOT_PF_DEVICE_ADDRESS || "ATS Test Location",
  
    smart_Guardian_MFRID:
      process.env.S_GUARDIAN_MFR_ID || "6091ea822d32659cca50812d",
  
    smart_Guard_MFRID: process.env.S_GUARD_MFR_ID || "6086ac2073d276001232ef72",
  
    AddedBy: process.env.IOT_PF_DEVICE_ADDEDBY || "5edf2701cbcb05001258fb36",
    iotPFDSAPI:"http://localhost:3047/lora-handler",
  };
  