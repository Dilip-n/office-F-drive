const axios = require("axios");
const {iotPFDSAPI} = require("../config/setting")
const axiosCall = async (data = {}) => {
    try {
        const response = await axios({
            method: "POST",
            url: `${iotPFDSAPI}`,
            data,
        });
        if (response.status == 200) {
            return response.data;
        } else {
            return null;
        }
    }
    catch(err){
        console.log(err)
        return null
    }

};


const intervalAxiosCall = async (data, second) => {
    try{
        returndata = axiosCall(data);
        await new Promise((resolve) => setTimeout(resolve, second * 2000));
        return returndata;
    }
    catch(err){
        console.log(err)
        return null
    }
    
};

const manageIntervalApiCall = async (my_arr) => {
    try{
        const result = [];
        for (let i = 0; i < my_arr.length; i++) {
          
          let today = new Date();
        //   let date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
        //   let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
        //   console.log(today);
          my_arr[i].ts = today
      
          const response = await intervalAxiosCall(my_arr[i], 2);
          if(response != null) {
            console.log(response)
            result.push(response);
            console.log(`No ${i + 1} api call copmpleted`);
          }
          else{
            console.log(`No ${i + 1} api call failed`);
          }
         
        }
    }
    catch(err){
        console.log(err)
    }
  
};

module.exports = manageIntervalApiCall