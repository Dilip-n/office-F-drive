/*jshint esversion: 8 */
const { port, env, ip } = require("./constants");
const app = require("./config/express.config");
const chalk = require("chalk");
const logger = require("./api/v1/utils/logger");

// listen to requests
app.listen(port, ip, (err) => {
  if (err) {
    console.log("Server failed to start", err);
    //Logger
    return logger.info("Server failed to start", err);
  }
  console.log(
    chalk.greenBright(`\n-------\nServer is Running->
        mode: [${chalk.magentaBright(`${env}`)}]
        url: [${chalk.magentaBright(`http://${ip}:${port}`)}]\n-------`)
  );
  //Logger
  return logger.info(`Server is running at http://${ip}:${port}`);
});
