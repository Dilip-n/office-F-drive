/*jshint esversion: 8 */
const path = require("path");
// const config = require("./../config");
const config = require("./../config.dev");
module.exports = {
  env: config.appEnv,
  port: parseInt(config.appPort),
  logs: config.appLog,
  //ip:'localhost', //This will not let app accesible on LAN
  ip: config.appHost,

  root: path.normalize(`${__dirname}/../..`), // root
  base: path.normalize(`${__dirname}/..`), // base

  mongoDbSuffix: "tenant-db",
  pgDbSuffix: "tenant-db",
  //Collection suffix
  collSuffix: {
    data: "device.data",
    livedata: "device.livedatas",
  },

  loraCredentials: {
    password: config.loraUsername,
    username: config.loraPassword,
  },
  logFileName: {
    info: "info.log",
    error: "exceptions.log",
  },

  mongoDb: {
    // MongoDB - Sample URI
    // uri: mongodb://username:password@host:port/database?options
    uri: (() => {
      //If Username Password is set
      if (config.mongodbIsAuth === "true") {
        return `mongodb://${config.mongodbUsername}:${config.mongodbPassword}@${config.mongodbHost}:${config.mongodbPort}/${config.mongoDbName}?authSource=admin`;
      }
      //Without auth
      return `mongodb://${config.mongodbHost}:${config.mongodbPort}/${config.mongoDbName}`;
    })(),

    masterDb: `${config.mongoDbName}`,
    options: {
      useCreateIndex: true,
      useNewUrlParser: true,
      useUnifiedTopology: true,
    },
  },
  pgdb: {
    // PGSQL - Sample URI
    // uri: 'postgres://user:pass@example.com:5432/dbname'
    uri: (() => {
      //If Username Password is set
      if (config.pgdbIsAuth === "true") {
        return `postgres://${config.pgdbUsername}:${config.pgdbPassword}@${config.pgdbHost}:${config.pgdbPort}/${config.pgDbName}`;
      }
      //Without auth
      return `postgres://${config.pgdbHost}:${config.pgdbPort}/${config.pgDbName}`;
    })(),

    masterDb: `${config.pgDbName}`,
    options: {},
    host: config.pgdbHost,
    port: parseInt(config.pgdbPort),
    username: config.pgdbUsername,
    password: config.pgdbPassword,
  },
  jwtSecrets: {
    accessSecret: config.accessTokenSecret,
    refreshSecret: config.refreshTokenSecret,
    tokenSecret: config.tokenSecret,
  },
  licensingServer: config.licensingServer,
  dataHandlerHost: config.dataHandlerHost,

  dataSharingPort: config.dataSharingPort,

  emqxHost: config.emqxHost,

  promEndpoint: config.promEndpoint,
  sendCommandEndPoint: config.sendCommandEndPoint,

  minioServer: {
    host: config.minioHost,
    port: parseInt(config.minioPort),
    username: config.minioUsername,
    password: config.minioPassword,
  },
  minioAppLogoBucket: config.minioAppLogoBucket,
  logTypes: {
    app: { added: 100, updated: 101, removed: 102 },
    device: { added: 200, updated: 201, removed: 202 },
    site: { added: 300, updated: 301, removed: 302 },
    user: { added: 400, updated: 401, removed: 402 },
    rule: { added: 500, updated: 502, removed: 503 },
  },
};
