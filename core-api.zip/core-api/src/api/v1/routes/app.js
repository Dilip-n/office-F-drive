/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/app.controller");
const router = express.Router();

//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo } = require("../middlewares/user.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
//Check License
const { checkLicense } = require("../middlewares/license.check");

//Add Apps - Resource ID - 101
// router
//   .route("/")
//   .post(
//     verifyUserAndCheckRights(101),
//     getMetaInfo,
//     checkLicense("app"),
//     controller.addApp
//   );
router
  .route("/")
  .post(verifyUserAndCheckRights(101), getMetaInfo, controller.addApp);

//Add App Logo - Resource ID - 101
router
  .route("/logo")
  .post(verifyUserAndCheckRights(101), getMetaInfo, controller.uploadLogo);

//Get All Apps - Resource ID - 102
router
  .route("/?")
  .get(
    verifyUserAndCheckRights(102),
    getMetaInfo,
    checkLicense("app"),
    controller.getAllApps
  );

//Get Apps health - Resource ID - 102
router
  .route("/health")
  .get(verifyUserAndCheckRights(102), getMetaInfo, controller.getAppsHealth);
//Get All Apps - Resource ID - 401
router
  .route("/customers-app")
  .get(
    verifyUserAndCheckRights(401),
    getMetaInfo,
    controller.getAllCustomerApps
  );

//Update one App - Resource ID - 103
router
  .route("/:appId")
  .patch(verifyUserAndCheckRights(103), getMetaInfo, controller.updateApp);

//Delete App - Resource ID - 104
router
  .route("/:appId")
  .delete(verifyUserAndCheckRights(104), getMetaInfo, controller.deleteApp);

router
  .route("/:appId/devices")
  .get(verifyUserAndCheckRights(102), getMetaInfo, controller.getAllDevices); // Rajesh

router
  .route("/:appId/Solutions-Metadata")
  .get(
    verifyUserAndCheckRights(102),
    getMetaInfo,
    controller.getAllSolutionsMetadata
  ); // Rajesh

router
  .route("/:appId/devices/unassigned")
  .get(
    verifyUserAndCheckRights(102),
    getMetaInfo,
    controller.getAllUnsndDevices
  ); //Rajesh
router
  .route("/:appId/devices/:deviceId/manufacturer")
  .get(
    verifyUserAndCheckRights(102),
    getMetaInfo,
    controller.getDeviceManufacturer
  ); //Rajesh
router
  .route("/devices/:deviceProfileId/dataPath")
  .get(
    verifyUserAndCheckRights(102),
    getMetaInfo,
    controller.getDeviceDataPath
  ); //Rajesh
router
  .route("/:appId/sites")
  .get(verifyUserAndCheckRights, controller.getAllSites);

router
  .route("/:appId/sites/:siteId")
  .put(verifyUserAndCheckRights, controller.updateTenantSite);

router
  .route("/:appId/sites/:siteId")
  .delete(verifyUserAndCheckRights, controller.deleteTenantSite);

router
  .route("/:appId/sites/:siteId/devices")
  .get(verifyUserAndCheckRights(102), getMetaInfo, controller.getSiteAllDevice);
router
  .route("/search?")
  .get(verifyUserAndCheckRights(102), getMetaInfo, controller.getAppsForSearch); //Rajesh

router
  .route("/:appId/device-types")
  .get(verifyUserAndCheckRights(102), getMetaInfo, controller.getDeviceTypes); //Rajesh

router
  .route("/:appId/logo-url")
  .get(verifyUserAndCheckRights(102), getMetaInfo, controller.getAppLogoURL);

module.exports = router;
