/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/device.data.controller");

const router = express.Router();
//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo, pgInfo } = require("../middlewares/user.auth");

//Routes
//Reports - Resource ID - 601 - Apply PGINFO middleware
router
  .route("/reports/:appId/:deviceId?")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.getReports
  );

//graph No of messages for a device for month  - Auth Rajesh
router
  .route("/graphs/daily-msg-counts")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.deviceMessagesCountGraph
  );

//graph Sum of messages for a device for month  - Auth Rajesh
router
  .route("/graphs/daily-msg-storage")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.deviceMessagesSumGraph
  );

//graph No of alerts/day for month  - Auth Rajesh
router
  .route("/widget/daily-alert-counts")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.alertsPerDayGraph
  );

// to get events count (resolved and un-resolved)  - Auth Rajesh
router
  .route("/widget/daily-msg-counts")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.eventStatusCount
  );

// to get events severity (high, medium and low) count - Auth Rajesh
router
  .route("/graphs/daily-alerts-severity")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.severityDashboardGraph
  );
// Get resource usage
router
  .route("/graphs/resource-usage")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.resourceUsageGraph
  );
router.route("/live/apps/:appId").get(controller.getAppLiveData);
router
  .route("/live/apps/:appId/sites/:siteId")
  .get(controller.getAppSiteLiveData);
router
  .route("/apps/:appId/sites/:siteId/devices/:deviceId")
  .get(controller.getAppSiteDeviceData);
//API for fetching data based on filters
//Query string will be sites, devices and date ranges
router.route("/apps/:appId/filter?").get(controller.getData);

router
  .route("/device-messages/:deviceId")
  .get(
    verifyUserAndCheckRights(602),
    getMetaInfo,
    pgInfo,
    controller.getDeviceMessages
  ); //Auth Rajesh - 22-June-2020
module.exports = router;
