/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/user.roles.controller");

const router = express.Router();
//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo } = require("../middlewares/user.auth");
//Check License
const { checkLicense } = require("../middlewares/license.check");

//Routes

//Add users - Resource ID 401
router
  .route("/users")
  .post(
    verifyUserAndCheckRights(401),
    getMetaInfo,
    checkLicense("user"),
    controller.addUsers
  );

//Get list of user types - Resource ID - 401
router
  .route("/user-types")
  .get(verifyUserAndCheckRights(401), getMetaInfo, controller.getUserTypes);

//Get all users - Resource ID 402
router
  .route("/users?")
  .get(verifyUserAndCheckRights(402), getMetaInfo, controller.getAllUsers);

//Update one user - Resource ID 403
router
  .route("/users/:userId")
  .patch(verifyUserAndCheckRights(403), getMetaInfo, controller.updateUser);

//Delete one user - Resource ID - 404
router
  .route("/users/:userId")
  .delete(verifyUserAndCheckRights(404), getMetaInfo, controller.deleteUser);

//User Search - Resource ID - 402
router
  .route("/users/search?")
  .get(
    verifyUserAndCheckRights(402),
    getMetaInfo,
    controller.getAllUsersForSearch
  );

router.route("/getPrivileges").get(controller.getUserPrivileges);
//Export
module.exports = router;
