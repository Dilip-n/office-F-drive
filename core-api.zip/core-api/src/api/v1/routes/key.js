const express = require("express");
const controller = require("../controllers/key.controller");

const router = express.Router();
const VerifyUser = require("./../middlewares/jwt.auth");
router.route("/hex/:bit").get(controller.getKeys);
router.route("/app-id").get(controller.getAppIdKey);
router.route("/site-id").get(controller.getSiteIdKey);
router.route("/device-id").get(controller.getDeviceIdKey);
module.exports = router;
