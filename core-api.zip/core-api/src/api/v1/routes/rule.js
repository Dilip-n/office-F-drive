/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/rule.controller");

//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo } = require("../middlewares/user.auth");

const router = express.Router();

//Add Rule
router
  .route("/")
  .post(verifyUserAndCheckRights(801), getMetaInfo, controller.addRule); //Rajesh
//Get All Rules
router
  .route("/?")
  .get(verifyUserAndCheckRights(802), getMetaInfo, controller.getAllRules); //Rajesh
//Update Rule
router
  .route("/:ruleId")
  .put(verifyUserAndCheckRights(803), getMetaInfo, controller.updateRule); //Rajesh
//Delete Rule
router
  .route("/:ruleId")
  .delete(verifyUserAndCheckRights(804), getMetaInfo, controller.deleteRule); //Rajesh
//Search Rule
router
  .route("/search?")
  .get(verifyUserAndCheckRights(802), getMetaInfo, controller.searchRule); //Rajesh

module.exports = router;
