/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/user.controller");
const router = express.Router();

//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo, pgInfo } = require("../middlewares/user.auth");

//Routes
//Login
router.route("/signin").post(controller.signin);

//Dashboard Home - Resource ID - 102
router
  .route("/home")
  .get(
    verifyUserAndCheckRights(102),
    getMetaInfo,
    pgInfo,
    controller.getDashboardData
  );

//Change Password - Resource ID - 903
router
  .route("/change-password")
  .post(verifyUserAndCheckRights(903), getMetaInfo, controller.postChangePwd);

module.exports = router;
