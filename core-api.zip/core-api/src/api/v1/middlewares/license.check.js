/*jshint esversion: 8 */
//Require Axios
const axios = require("axios");
//Get Settings
const { licensingServer } = require("./../../../constants");

module.exports.checkLicense = checkFor => {
  return async (req, res, next) => {
    try {
      //Send request to licenseing server
      const response = await axios({
        method: "POST",
        url: `${licensingServer}/auth`,
        headers: {
          Authorization: `Bearer ${req.metaObj.lsKey}`
        },
        data: {
          check: checkFor
        }
      });

      if (response.data.goAhead) {
        //Ok, Next

        return next();
      }
      return next();

      // return res.status(401).json({
      //   success: false,
      //   error: {
      //     code: 41,
      //     msg: "Unauthorized Access!"
      //   }
      // });
    } catch (error) {
      return next();
      // return res.status(401).json({
      //   success: false,
      //   error: {
      //     code: 41,
      //     msg: "Unauthorized Access!"
      //   }
      // });
    }
  };
};
