/*jshint esversion: 8 */
const mongoose = require("mongoose");
//Mongo DB connection
const dbConn = require("./../../../config/express.config");
const pgConn = require("./../../../config/pgsql.config");
const { mongoDb, pgdb } = require("./../../../constants");
const masterDb = mongoDb.masterDb;
//Require User Model
const User = require("./../models/User");
//Require Tenant Model
const Tenant = require("./../models/Tenants");
//Require App Model
const App = require("../models/App");
//Require License model
const License = require("./../models/License.js");
//Require Util
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();

//Get Meta information for the JWT Authenticated user
module.exports.getMetaInfo = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get user id
    const userJWT = req.user;
    const db = await dbConn.mongoDbConn.useDb(masterDb);
    //User Model
    const UserModel = await User.model(db, "user");
    //Tenant Model
    const TenantModel = await Tenant.model(db, "tenant");
    //License model
    const LicenseModel = License.model(db, "license");
    //Check if user exists
    UserModel.findOne({
      _id: userJWT.userId,
    })
      .populate({
        path: "tenant",
        select: "dbName _id name",
        model: TenantModel,
      })
      .then(async (user) => {
        if (!user) {
          return res.status(404).json({
            success: false,
            error: {
              code: 44,
              msg: "User does not exists !",
            },
          });
        }
        //Get Tenant DB
        const tenantDbName = user.tenant.dbName;
        const tenant = user.tenant._id;
        //Get customerId
        const customer = user.customer;
        //Get the full tenant db
        const dbName = UtilFunctions.tenantDbName(tenantDbName);
        if (!dbName || !tenantDbName) {
          return res.status(400).json({
            success: false,
            error: {
              code: 40,
              msg: "Something went wrong !",
            },
          });
        }
        let apps = [];
        let mongooseTAppIds = [];
        //Use tenant db
        const db1 = await dbConn.mongoDbConn.useDb(dbName);
        //Get App Model
        const ApplicationModel = App.model(db1, "app");

        //If customerId is not available then return all the records
        if (customer === undefined || customer === null) {
          apps = await ApplicationModel.find().select("_id");
        } else {
          apps = await ApplicationModel.find({ customer }).select("_id");
        }

        //Get license key
        const key = await LicenseModel.findOne({ tenantId: tenant });

        /*

        ! Return some basic info - metaObj
        
        ? tenantDb = tenant's db connection object, in next middleware or controller this can be directly used to connect to tenantDB
        ? apps = tenant/customer's apps
        ? tenantId = masterDB>tenants>_id, this can be used to fetch tenant details or check userLevel
        ? customerId = tenantsDB>customer>_id, this can be used to fetch customer details or check userLevl
        ? userLevel means - the logged in user is tenant or customer level user
        
        */
        //Format normal string type app _ids to mongoose type _ids. This will be used in match aggregation
        if (apps.length > 0) {
          mongooseTAppIds = apps.map(function (el) {
            return mongoose.Types.ObjectId(el._id);
          });
        }
        req.metaObj = {
          tenantDb: db1,
          tenantName: user.tenant.name,
          tenantDbName,
          apps,
          mongooseTAppIds,
          tenantId: tenant,
          customerId: customer,
          lsKey: key,
        };
        next();
      });
  } catch (err) {
    console.log(err);
    return res.status(401).json({
      success: false,
      error: {
        code: 40,
        msg: "Something went wrong !",
      },
    });
  }
};
// module.exports.checkSites = function(req, res, next) {
//   try {
//     console.log("Working");
//     next();
//   } catch (err) {
//     console.log(err);
//     return res.status(401).json({
//       success: false,
//       error: {
//         code: 41,
//         msg: "Unable to verify your credentials.s"
//       }
//     });
//   }
// };
//Get PGSQL Connection
module.exports.pgInfo = async (req, res, next) => {
  const tenantDbName = req.metaObj.tenantDbName;
  //Get this tenant db - PGSQL
  const dbName = UtilFunctions.tenantPgDbName(tenantDbName);
  const uri = `postgres://${pgdb.username}:${pgdb.password}@${pgdb.host}:${pgdb.port}/${dbName}`;
  const pgDbConn = await pgConn.connectDb(uri);
  /*

  ! Return some basic info - metaObj
  
  */
  req.metaPgObj = {
    tenantDb: pgDbConn,
  };
  next();
};
