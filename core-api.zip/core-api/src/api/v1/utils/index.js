/*jshint esversion: 9 */
//Require db constants
const { pgDbSuffix, mongoDbSuffix } = require("./../../../constants");
class UtilFunctions {
  constructor() {}
  //Method to create an tenant db name - Mongo DB
  tenantDbName(prefix) {
    return `${prefix}-${mongoDbSuffix}`;
  }
  //Method to create an application specific collection name - MongoDB
  collectionName(appId, collectionSuffix) {
    return `${appId}.${collectionSuffix}`.toLowerCase();
  }
  //Method to create an tenant db name - PGSQL DB
  tenantPgDbName(prefix) {
    return `${prefix}-${pgDbSuffix}`;
  }
  //Make first char of each word capital
  titleCase(str) {
    str = str.trim();
    var splitStr = str.toLowerCase().split(" ");
    for (var i = 0; i < splitStr.length; i++) {
      // You do not need to check if i is larger than splitStr length, as your for does that for you
      // Assign it back to the array
      splitStr[i] =
        splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    // Directly return the joined string
    return splitStr.join(" ");
  }

  //Flatten a JSON Object
  flatten(obj, path = "data->") {
    if (!(obj instanceof Object)) return { [path.replace(/->$/g, "")]: obj };
    return Object.keys(obj).reduce((output, key) => {
      return obj instanceof Array
        ? { ...output, ...this.flatten(obj[key], path + "[" + key + "]->") }
        : { ...output, ...this.flatten(obj[key], `${path}'${key}'->`) };
    }, {});
  }
  //Get columns
  getColumns(schema, otherSchema = {}) {
    let columns = [];
    //If other fileds are provided
    Object.keys(otherSchema).map((attribute) => {
      columns.push(attribute);
    });
    //DataSchema
    Object.keys(this.flatten(schema)).map((attribute) => {
      columns.push(attribute.replace(/->/g, ".").replace(/'/g, ""));
    });
    return columns;
  }
  //Convert seconds into hour/minute/second
  secondsToHms(d) {
    d = Number(d);
    var h = Math.floor(d / 3600);
    var m = Math.floor((d % 3600) / 60);
    var s = Math.floor((d % 3600) % 60);

    var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
    var mDisplay = m > 0 ? m + (m == 1 ? " minute " : " minutes") : "";
    var sDisplay = m < 1 && s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
    return hDisplay + mDisplay + sDisplay;
  }

  collectionNames() {
    const names = {
      site: "site",
      device: "device",
    };
    return names;
  }
}

module.exports.UtilFunctions = UtilFunctions;
