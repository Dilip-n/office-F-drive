/*jshint esversion: 8 */
const {
  createLogger,
  format,
  transports
} = require("winston");
const {
  root,
  base,
  logFileName
} = require("../../../constants");
module.exports = createLogger({
  format: format.combine(
    format.simple(),
    format.timestamp(),
    format.printf(info => `[${info.timestamp}] ${info.level} ${info.message}`)
  ),
  transports: [
    // new transports.Console(),
    new transports.File({
      maxsize: 520000,
      maxFiles: 5,
      filename: `${root}/logs/${logFileName.info}`
    })
  ],
  exceptionHandlers: [
    new transports.Console(),
    new transports.File({
      maxsize: 520000,
      filename: `${root}/logs/${logFileName.error}`
    })
  ]
});