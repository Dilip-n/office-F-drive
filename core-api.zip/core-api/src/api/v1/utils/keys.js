/*jshint esversion: 8 */
const converter = require("hex2dec");
const randomBytes = require("randombytes");
// var random = require('random-bytes');
const randtoken = require("rand-token").uid;
// const crypto = require('crypto');
//Require Randomatic for keys
const randomize = require("randomatic");
//Get random Device keys
exports.getDeviceId = async bit => {
  try {
    const deviceId = randomize("0", 16);
    return deviceId;
  } catch (err) {
    return false;
  }
};
//Get random App keys
exports.getAppId = async bit => {
  try {
    const appId = randomize("0", 16);
    return appId;
  } catch (err) {
    return false;
  }
};
