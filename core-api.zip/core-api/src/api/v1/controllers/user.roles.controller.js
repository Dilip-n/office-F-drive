/*jshint esversion: 8 */
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const underscore = require("underscore");
const bcrypt = require("bcrypt");
const logger = require("./../utils/logger");
const { mongoDb, logTypes } = require("./../../../constants");
const masterDb = mongoDb.masterDb;
//Require App Model
const App = require("../models/App");
//Require Site Model
const Site = require("./../models/Site");
//Require User Model
const User = require("./../models/User");
//Require Device Model
const Device = require("./../models/Device");
//Require RoleAndRights model
const RoleAndRights = require("./../models/RoleAndRights");
//Require Tenant Model
const Tenant = require("./../models/Tenants");
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();
//Db logger
let { DbLogger } = require("./../utils/dbLogger");

//Controller
//Getting all tenant users
exports.getAllUsers = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB
    const tenantDb = req.metaObj.tenantDb;
    //Get TenantId and customerId
    const tenant = req.metaObj.tenantId;
    const customer = req.metaObj.customerId;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Connect to master DB
    const masterDbConn = await tenantDb.useDb(masterDb);
    //User Model
    const UserModel = await User.model(masterDbConn, "users");
    //Role and Rights model
    const RoleAndRightsModel = await RoleAndRights.model(
      masterDbConn,
      "role.rights"
    );

    //Based on user level show users

    //For tenant show all linked users
    let find = { tenant: tenant };
    //For customer
    if (customer) {
      //Search customerId
      find = { customer };
    }

    //Find all users
    const users = await UserModel.find(find)
      .skip(prev)
      .limit(next)
      .populate({
        path: "role",
        select: "alias -_id",
        model: RoleAndRightsModel,
      })
      .select("-__v -password");
    // const pipeline = [
    //   {
    //     $match: find
    //   },
    //   {
    //     $skip: prev
    //   },
    //   {
    //     $limit: next
    //   },

    //   {
    //     $project: {
    //       user: "$$ROOT"
    //     }
    //   },

    //   {
    //     $lookup: {
    //       from: "role.rights",
    //       localField: "user.role",
    //       foreignField: "_id",
    //       as: "role"
    //     }
    //   },
    //   {
    //     $project: {
    //       user: 1,
    //       role: {
    //         $arrayElemAt: ["$role", 0]
    //       }
    //     }
    //   },
    //   {
    //     $project: {
    //       _id: 0,
    //       user: 1,
    //       "role.alias": 1
    //     }
    //   }
    // ];
    // const users = await UserModel.aggregate(pipeline);
    //Format response
    const response = {
      success: users.length > 0 ? true : false,
      data: {
        code: 20,
        msg: users.length > 0 ? "Records found" : "No records found",
        count: users.length,
        results: users,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Controller
//Get list of user types - for Tenant and Customer level
exports.getUserTypes = async (req, res) => {
  try {
    /*

    */
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    //Get TenantId and customerId
    const tenant = req.metaObj.tenantId;
    const customer = req.metaObj.customerId;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Customer Model
    const roleRightsColl = "role.rights";
    const masterDbConn = await tenantDb.useDb(masterDb);
    const RoleAndRightsModel = await RoleAndRights.model(
      masterDbConn,
      roleRightsColl
    );
    //Find user role and rights collection

    let find = { level: "n/a" };
    //For Tenant get all level users
    if (tenant) {
      find = { level: { $in: ["tenant", "customer"] } };
    }
    //For customer get users where customerId is matching
    if (customer) {
      find = { level: { $in: ["customer"] } };
    }

    const types = await RoleAndRightsModel.find(find).select(
      "-__v -role -rights"
    );
    //Format response
    const response = {
      success: types.length > 0 ? true : false,
      data: {
        code: types.length > 0 ? 20 : 44,
        msg: types.length > 0 ? "Records found" : "No records found",
        count: types.length,
        results: types,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Add Users - Tenant/Customer Level
exports.addUsers = async (req, res) => {
  try {
    /*

    */
    //Get user - who is trying to add the user
    const user = req.user;
    //Get tenant DB and userLevel
    const tenantDb = req.metaObj.tenantDb;
    //Get TenantId of user who is trying to add this user
    const tenant = req.metaObj.tenantId;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Connect to master DB
    const masterDbConn = await tenantDb.useDb(masterDb);
    //User Model
    const UserModel = await User.model(masterDbConn, "users");
    //Role and Rights model
    const RoleAndRightsModel = await RoleAndRights.model(
      masterDbConn,
      "role.rights"
    );

    //Check if the mobile/email exists
    const emailMobileCheck = await UserModel.findOne({
      $or: [
        {
          "email.address": req.body.email,
        },
        {
          "mobile.number": req.body.mobile,
        },
      ],
    });
    //Check if user email/mobile exists
    if (emailMobileCheck) {
      return res.status(409).json({
        success: false,
        error: {
          code: 49,
          msg: "User Already Exists !",
        },
      });
    }

    const roleIdCheck = await RoleAndRightsModel.findById(req.body.roleId);
    //If userCheck Fails
    if (!roleIdCheck) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Form the new User object
    const newUserObj = {
      name: req.body.name,
      "email.address": req.body.email,
      "mobile.number": req.body.mobile,
      password: await bcrypt.hash(req.body.password, 10),
      tenant,
      role: req.body.roleId,
      addedBy: user.userId,
    };
    //If the user who is being add is customer level then add the customerId in newUserObj
    if (roleIdCheck.level === "customer") {
      newUserObj.customer = req.body.customerId;
    }
    const newUser = new UserModel(newUserObj);
    await newUser.save();
    try {
      //DB Logger
      const logged = await DbLogger(
        user,
        tenant,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.user.added,
        true,
        {
          userName: newUserObj.name,
          role: newUserObj.role,
          msg: "User Added!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    res.status(201).json({
      success: true,
      data: {
        code: 21,
        msg: "User Added !",
      },
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Controller
//Update one user
exports.updateUser = async (req, res) => {
  try {
    //Get tenant DB
    const tenantDb = req.metaObj.tenantDb;
    //Get userId from request
    const userId = req.params.userId;
    //Get user - who is trying to update the user
    const user = req.user;
    //Get TenantId of user who is trying to add this user
    const tenant = req.metaObj.tenantId;

    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Switch to master db
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get User Model - master db
    const UserModel = await User.model(masterDbConn, "user");
    //Role and Rights model
    const RoleAndRightsModel = await RoleAndRights.model(
      masterDbConn,
      "role.rights"
    );
    //Find user
    const userCheck = await UserModel.findOne({
      _id: userId,
    }).populate({
      path: "role",
      model: RoleAndRightsModel,
    });

    //If user/role/level does not exists
    if (!userCheck || !userCheck.role || !userCheck.role.level) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get email/mobile from request
    //Check if the mobile/email exists
    const emailMobileCheck = await UserModel.findOne({
      $or: [
        {
          "mobile.number": req.body.mobile,
        },
      ],
    });
    //Check if user email/mobile exists
    if (emailMobileCheck) {
      return res.status(409).json({
        success: false,
        error: {
          code: 49,
          msg: "Mobile Already Exists !",
        },
      });
    }
    //Do role validation
    //Role can be updated but that has to be in same level
    const roleIdCheck = await RoleAndRightsModel.findById(req.body.roleId);
    //If roleCheck Fails
    if (!roleIdCheck || roleIdCheck.level != userCheck.role.level) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Incorrect Role ID !",
        },
      });
    }

    //Make user object
    let update = {
      name: req.body.name,
      "mobile.number": req.body.mobile,
      password: await bcrypt.hash(req.body.password, 10),
      role: req.body.roleId,
      addedBy: user.userId,
    };

    //Update
    await userCheck.updateOne({
      $set: update,
    });
    try {
      //DB Logger
      const logged = await DbLogger(
        user,
        tenant,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.user.updated,
        true,
        {
          userName: userCheck.name,
          msg: "User Updated!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    //Format and send response
    //HTTP code can be 204
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "User details updated",
        results: update,
      },
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Controller
//Remove one user
exports.deleteUser = async (req, res) => {
  try {
    //Get tenant DB
    const tenantDb = req.metaObj.tenantDb;
    //Get userId from request
    const userId = req.params.userId;
    //Get user - who is trying to delete the user
    const user = req.user;
    //Get TenantId of user who is trying to add this user
    const tenant = req.metaObj.tenantId;

    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Switch to master db
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get User Model - master db
    const UserModel = await User.model(masterDbConn, "user");
    //Find user
    const userCheck = await UserModel.findOne({
      _id: userId,
    });
    //If user does not exists
    if (!userCheck) {
      return res.status(409).json({
        success: false,
        error: {
          code: 49,
          msg: "User does not Exists !",
        },
      });
    }

    //Remove the user from user collection
    await userCheck.deleteOne();
    try {
      //DB Logger
      const logged = await DbLogger(
        user,
        tenant,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.user.removed,
        true,
        {
          userName: userCheck.name,
          msg: "User Removed!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    //Format and send response
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "User removed",
      },
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/*
Find all users - with search items - regex
*/
exports.getAllUsersForSearch = async (req, res) => {
  try {
    /*

    //Validation needs to be done 

    */
    //Get Query params for search and pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    let name = "";
    let email = "";
    let mobile = "";
    let role = "";
    let matchRegex = {};
    let matchRoleRegex = {};
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    //Get Tenant id
    const tenantId = req.metaObj.tenantId;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    const customer = req.metaObj.customerId;
    //Based on user level show users

    //For tenant show all linked users
    let find = { tenant: tenantId };
    //For customer
    if (customer) {
      //Search customerId
      find = { customer };
    }
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }
      //User email/mobile/name/role for regex
      if (req.query.role) {
        role = req.query.role;
        matchRoleRegex["role.alias"] = {
          $regex: role,
          $options: "i",
        };
      }
      if (req.query.email) {
        email = req.query.email;
        matchRegex["email.address"] = {
          $regex: email,
          $options: "i",
        };
      }
      if (req.query.mobile) {
        mobile = req.query.mobile;
        matchRegex["mobile.number"] = {
          $regex: mobile,
          $options: "i",
        };
      }
      if (req.query.name) {
        name = req.query.name;
        matchRegex.name = {
          $regex: name,
          $options: "i",
        };
      }
    }

    //Master db connection
    const db = await tenantDb.useDb(masterDb);
    //User model
    const UserModel = await User.model(db, "user");
    //Get user id
    const userJWT = req.user;
    if (userJWT.type === "tenant") {
      //Add Custom App schema in user model for tenant type
      UserModel.schema.add({
        applications: [
          {
            type: mongoose.Schema.Types.ObjectId,
          },
        ],
      });
    }

    //Check if user exists
    UserModel.findOne({
      _id: userJWT.userId,
    })
      .then(async (user) => {
        if (!user) {
          return res.status(404).json({
            success: false,
            error: {
              code: 44,
              msg: "User does not exists !",
            },
          });
        }
        const masterDbConn = await tenantDb.useDb(masterDb);
        console.log("matchRegex ", matchRoleRegex);
        //Role and Rights model
        const RoleAndRightsModel = await RoleAndRights.model(
          masterDbConn,
          "role.rights"
        );
        const data = await UserModel.find({
          $and: [
            find,
            { name: { $regex: name, $options: "i" } },
            { "email.address": { $regex: email, $options: "i" } },
            { "mobile.number": { $regex: mobile, $options: "i" } },
          ],
        })
          .skip(prev)
          .limit(next)
          .populate({
            path: "role",
            select: "alias -_id",
            match: matchRoleRegex,
            model: RoleAndRightsModel,
          })
          .select("-__v -password");
        return data;
      })
      .then((result) => {
        let finalResult = [];
        if (result.length > 0) {
          result.map((data) => {
            if (data.role) {
              finalResult.push(data);
            }
          });
        }

        //If there is no device
        if (result.length < 1 || finalResult.length < 1) {
          const response = {
            success: false,
            data: {
              code: 20,
              msg: "No user found !",
              results: [],
            },
          };
          return res.status(200).send(response);
        }
        const response = {
          success: true,
          data: {
            code: 20,
            msg: "Records found",
            count: finalResult.length,
            results: finalResult,
          },
        };
        return res.status(200).send(response);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error",
            error: err,
          },
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

exports.getUserPrivileges = async (req, res) => {
  try {
    let role = req.query.role;
    let user_privileges = [
      {
        role: "admin",
        privileges: [
          {
            group: "application",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "device",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "site",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "user",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "reports",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "alerts",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "rules",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          // {
          //   group: "password",
          //   view: "false",
          //   edit: "true",
          //   add: "false",
          //   delete: "false",
          // },
        ],
      },
      {
        role: "user",
        privileges: [
          {
            group: "application",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "device",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "site",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "user",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "reports",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "alerts",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "rules",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          // {
          //   group: "password",
          //   view: "false",
          //   edit: "true",
          //   add: "false",
          //   delete: "false",
          // },
        ],
      },
      {
        role: "developer",
        privileges: [
          {
            group: "application",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "device",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "site",
            view: "true",
            edit: "true",
            add: "true",
            delete: "true",
          },
          {
            group: "user",
            view: "true",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "reports",
            view: "false",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "alerts",
            view: "false",
            edit: "false",
            add: "false",
            delete: "false",
          },
          {
            group: "rules",
            view: "false",
            edit: "false",
            add: "false",
            delete: "false",
          },
          // {
          //   group: "password",
          //   view: "false",
          //   edit: "true",
          //   add: "false",
          //   delete: "false",
          // },
        ],
      },
    ];

    if (role) {
      let obj = user_privileges.find((o) => o.role === role);

      if (obj) {
        const response = {
          success: true,
          data: {
            code: 20,
            msg:
              obj.privileges.length > 0 ? "Records found" : "No records found",
            count: obj.privileges.length,
            results: obj,
          },
        };
        return res.status(200).send(response);
      } else {
        const response = {
          success: false,
          data: {
            code: 20,
            msg: "Please select proper role",
            count: 0,
            results: [],
          },
        };
        return res.status(200).send(response);
      }
    } else {
      const response = {
        success: false,
        data: {
          code: 20,
          msg: "Please send role",
          count: 0,
          results: [],
        },
      };
      return res.status(200).send(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Controller
//Get list of app
exports.add = async (req, res) => {};
