/*jshint esversion: 8 */
const mongoose = require("mongoose");
const async = require("async");

const underscore = require("underscore");
const logger = require("../utils/logger");

//Require Manufacturer Model
const Manufacturer = require("../models/Manufacturer");

//Getting all manufacturers
exports.getAllManufacturers = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const ManufacturerModel = await Manufacturer.model(tenantDb, "mfr.models");
    //Find all customers
    const manufacturerList = await ManufacturerModel.find({}).select(
      "-__v -gateway -helperId -deviceProfiles -model -_id -protocolType -created_at -updated_at"
    );

    //If there is no user
    if (!manufacturerList.length > 0) {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Manufacturers not found !",
          results: [],
        },
      };
      return res.status(200).send(response);
    }

    let response = {
      success: true,
      data: {
        code: 20,
        msg: "Manufacturers found",
        results: manufacturerList,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Getting all manufacturers-models
exports.getAllManufacturerModels = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const ManufacturerModel = await Manufacturer.model(tenantDb, "mfr.models");
    //Find all manufacturerModelList
    const manufacturerModelList = await ManufacturerModel.find({
      name: req.params.name,
    }).select(
      "-__v -gateway -helperId -deviceProfiles -name -created_at -updated_at"
    );

    //If there is no user
    if (!manufacturerModelList.length > 0) {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: `Manufacturers models not found for this name ${req.params.name}!`,
          results: [],
        },
      };
      return res.status(200).send(response);
    }

    let response = {
      success: true,
      data: {
        code: 20,
        msg: "Manufacturers models found",
        results: manufacturerModelList,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
