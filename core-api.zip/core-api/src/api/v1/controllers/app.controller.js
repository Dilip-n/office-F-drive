/*jshint esversion: 9 */
const mongoose = require("mongoose");
const moment = require("moment");
//Require Randomatic for keys
const randomize = require("randomatic");
const underscore = require("underscore");
const {
  mongoDb,
  minioServer,
  promEndpoint,
  dataSharingPort,
  minioAppLogoBucket,
  logTypes,
} = require("./../../../constants");
//Require Application Model
const App = require("../models/App");
//Require User Model
const User = require("../models/User");
//Require Site Model
const Site = require("../models/Site");
//Require Device Model
const Device = require("../models/Device");

//Require Device Manufacturer Model
const DeviceMfr = require("../models/Manufacturer");
//Require MDevice - Device in Master db
const MDevice = require("./../models/MDevice");
//Require MSolution - Device in Master db
const MSolution = require("./../models/MSolution");
//Require Customer Model
const Customer = require("./../models/Customer");
//Require Ports collection
const Port = require("./../models/Ports");
//Require multer
const Multer = require("multer");
//Require Minio
const Minio = require("minio");
//Require axios
const Axios = require("axios");
//Require MConfigUrls - config urls in Master db
const MConfigUrl = require("./../models/ConfigUrls");
//Require DeviceProfile Model
const DeviceProfile = require("./../models/DeviceProfile");
const Keys = require("./../utils/keys");
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();
//Auth Util
let { AuthUtils } = require("./../utils/auth");
AuthUtils = new AuthUtils();
//Db logger
let { DbLogger } = require("./../utils/dbLogger");
//Get master db name
const masterDb = mongoDb.masterDb;

/*

! Controller functions starts

*/
//Add Solution to master db
exports.addSolution = async (req, res) => {
  const db = await dbConn.mongoDbConn.useDb("hts-iot-platform-v1");
  const AppModel = App.model(db, "solution");
  //Add application
  const application = new AppModel({
    _id: new mongoose.Types.ObjectId(),
    app_id: req.body.appId,
    name: req.body.appName,
    port: req.body.port,
    url: req.body.url,
    desc: req.body.desc,
    solution: req.body.solution,
  });
  await application
    .save()
    .then((result) => {
      return res.status(201).json({
        success: true,
        data: {
          code: 21,
          msg: "Solution added successfully",
        },
      });
    })
    .catch((err) => {
      res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: err,
        },
      });
    });
};
//Get all solutions from master collection
exports.getSolution = async (req, res) => {
  //Get tenant DB and apps
  const tenantDb = req.metaObj.tenantDb;
  //Master DB Connection
  const masterDbConn = await tenantDb.useDb(masterDb);
  //Solution model
  const SolModel = MSolution.model(masterDbConn, "solution");
  //Find all
  SolModel.find()
    .exec()
    .then((docs) => {
      //If not application
      if (!docs.length > 0) {
        const response = {
          success: false,
          data: {
            code: 20,
            msg: "No records found !",
            results: [],
          },
        };
        return res.status(200).send(response);
      }
      const response = {
        success: true,
        data: {
          code: 20,
          msg: "Records found",
          results: docs,
        },
      };
      return res.status(200).send(response);
    })
    .catch((err) => {
      return res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: err,
        },
      });
    });
};
//Get Apps
exports.getAllApps = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;

    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    // //Customer Model
    // const customerColl = "customer";
    // const CustomerModel = await Customer.model(tenantDb, customerColl);
    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      {
        $match: {
          _id: {
            $in: mongooseTAppIds,
          },
        },
      },
      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $project: {
          app: "$$ROOT",
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          app: 1,
          customer: { $arrayElemAt: ["$customer", 0] },
        },
      },
    ];

    const apps = await tenantDb.models.app.aggregate(pipeline);

    //Format response
    const response = {
      success: apps.length > 0 ? true : false,
      data: {
        code: 20,
        msg: apps.length > 0 ? "Records found" : "No records found",
        count: apps.length,
        results: apps,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Add application - assign to customer or self
exports.addApp = async (req, res) => {
  try {
    //Form data
    //Get user - who is trying to add the app
    const user = req.user;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    //Get Tenant id
    const tenantId = req.metaObj.tenantId;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    try {
      /* Multer*/
      const storage = Multer.memoryStorage();
      //File validation
      const fileFilter = (req, file, cb) => {
        // reject a file
        if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
          cb(null, true);
        } else {
          cb(
            new Error(
              JSON.stringify({
                rc: errArray.fileType.rc,
                rd: errArray.fileType.rd,
              })
            ),
            false
          );
        }
      };
      const upload = Multer({
        storage,
        limits: {
          // 10 mb
          fileSize: 1024 * 1024 * 10,
        },
        fileFilter: fileFilter,
      }).single("logo");

      upload(req, res, async function (err) {
        if (err instanceof Multer.MulterError) {
          console.log(err);
          // A Multer error occurred when uploading.
          let response = {
            success: false,
            data: {
              code: 20,
              msg: "Something went wrong !",
            },
          };
          return res.status(200).send(response);
        } else if (err) {
          console.log(err);
          // An unknown error occurred when uploading.
          let response = {
            success: false,
            data: {
              code: 20,
              msg: "Something went wrong !",
            },
          };
          return res.status(200).send(response);
        }
        //Get request object
        const self = req.body.self;
        //If new user customerName will be provided
        let customerName = req.body.customerName;
        //If existing customer then customerId will be provided
        const customerId = req.body.customerId;

        //Generate AppId and internalId
        const appId = await Keys.getAppId();
        //Master DB Connection
        const masterDbConn = await tenantDb.useDb(masterDb);
        //Customer Model
        const customerColl = "customer";
        const CustomerModel = await Customer.model(tenantDb, customerColl);
        //Port model
        const PortModel = await Port.model(masterDbConn, "ports");
        //Get Monitoring URL and base URL
        const MConfigUrlModel = await MConfigUrl.model(
          masterDbConn,
          "configuration.urls"
        );
        //Get base url and monitoring port
        const baseUrl = await MConfigUrlModel.findOne({
          baseUrl: { $ne: null },
        });
        const mtPort = await MConfigUrlModel.findOne({
          monitoringPort: { $ne: null },
        });

        const internalId = randomize("a", 3);
        //Generate Ports
        const genPorts = async () => {
          //Default ports
          let fePort = 15000;
          let bePort = 16000;
          let bePortArray = [16000, 16001, 16002, 16003, 16004, 16005];
          const ports = await PortModel.findOne().sort({ _id: -1 });
          if (ports) {
            //Increamnet the last port
            fePort = ports.frontend + 1;
            bePortArray = [];
            //Last port
            const lastBePort = ports.backend[ports.backend.length - 1];
            for (let index = 1; index < 6; index++) {
              bePortArray.push(lastBePort + index);
            }
          }

          return {
            tenantId,
            frontend: fePort,
            backend: bePortArray,
          };
        };
        //Get all the ports related data
        const getFeport = await genPorts();

        const MSolutionModel = await MSolution.model(masterDbConn, "solution");

        const solutionDetails = await MSolutionModel.findOne({
          _id: req.body.solution,
        });

        let solutionData = {
          _id: solutionDetails._id,
          name: solutionDetails.name,
        };
        let appObj = {
          name: req.body.name,
          appId: appId,
          internalId: internalId,
          addedBy: user.userId,
          address: req.body.address,
          desc: req.body.desc,
          monitoringUrl: `${baseUrl.baseUrl}:${mtPort.monitoringPort}`,
          appUrl: `${baseUrl.baseUrl}:${getFeport.frontend}`,
          solution: solutionData,
          metadata: JSON.parse(req.body.metaData),
          token: await AuthUtils.generateToken({ tenantId, appId }),
        };

        //If app is being assigned to tenant itself
        if (self) {
          appObj.self = true;
        } else {
          //If new customer is being added
          if (customerName) {
            //Make customerName title case
            customerName = UtilFunctions.titleCase(customerName);
            const customerCheck = await CustomerModel.findOne({
              name: customerName,
            });

            //If wrong customerId
            if (customerCheck) {
              return res.status(200).json({
                success: false,
                data: {
                  code: 20,
                  msg: "Customer already exists !",
                },
              });
            }
            //Create new customer
            const custObj = new CustomerModel({
              name: customerName,
            });
            const customer = await custObj.save();
            //add the customerId in appObj - get it form customer
            appObj.customer = customer._id;
          }
          //If existing customer is being added
          if (customerId) {
            const customerCheck = await CustomerModel.findOne({
              _id: customerId,
            });
            //If wrong customerId
            if (!customerCheck) {
              return res.status(200).json({
                success: false,
                data: {
                  code: 20,
                  msg: "Customer does not exists !",
                },
              });
            }
            //add the customerId in appObj
            appObj.customer = customerCheck._id;
          }
        }
        const app = new tenantDb.models.app(appObj);
        await app.save();

        //Get all the ports related data
        const portObj = await genPorts();
        //Save ports - along with tenant id
        await PortModel.create({ ...portObj, appId: app._id });

        //Logo Upload
        const minioUpload = () => {
          // Instantiate the minio client with the endpoint
          // and access keys as shown below.
          var minioClient = new Minio.Client({
            endPoint: minioServer.host,
            port: minioServer.port,
            useSSL: false,
            accessKey: minioServer.username,
            secretKey: minioServer.password,
          });
          //Check if bucket exists
          minioClient.bucketExists(
            minioAppLogoBucket,
            function (error, exists) {
              if (error) {
                let response = {
                  success: false,
                  data: {
                    code: 20,
                    msg: "Something went wrong !",
                  },
                };
                return res.status(200).send(response);
              }
              if (!exists) {
                // Make a bucket called hts-apps.
                minioClient.makeBucket(
                  minioAppLogoBucket,
                  "us-east-1",
                  function (err) {
                    if (err) return console.log(err);
                    console.log("Bucket created successfully.");
                  }
                );
              }
            }
          );
          //Meta data
          const metaData = {
            "Content-Type": "image/*",
            "X-Amz-Meta-Testing": 1234,
            example: 5678,
          };
          // Using putObject API upload your file to the bucket europetrip - Create file using buffer
          minioClient.putObject(
            minioAppLogoBucket,
            `${appId}.jpg`,
            req.file.buffer,
            metaData,
            function (err, etag) {
              if (err) return console.log(err);
            }
          );
        };
        if (req.file) {
          //Call Minio
          minioUpload();
        }
        try {
          //DB Logger
          const logged = await DbLogger(
            user,
            tenantId,
            req.metaObj.tenantDbName,
            req.metaObj.tenantName,
            logTypes.app.added,
            true,
            {
              appName: appObj.name,
              appId: appObj.appId,
              msg: "Application Added!",
            }
          );
          if (logged) {
            console.log("Data logged !");
          }
        } catch (e) {
          console.log("Data could not logged !", e);
        }
        return res.status(200).json({
          success: true,
          data: {
            code: 21,
            msg: "Application added !",
            results: {
              token: appObj.token,
              url: appObj.appUrl,
              customer: customerName,
              appName: appObj.name,
              dataSharingUrl: `${baseUrl.baseUrl}:${dataSharingPort}`,
            },
          },
        });
      });
    } catch (err) {
      console.log(err);
      return res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: err,
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Update one application
exports.updateApp = async (req, res) => {
  try {
    //Get tenant DB
    const tenantDb = req.metaObj.tenantDb;
    const appId = req.params.appId;
    //Get user - who is trying to add the app
    const user = req.user;
    //Get Tenant id
    const tenantId = req.metaObj.tenantId;

    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Use tenant db > and app model form connection object returned from previous middleware
    const appCheck = await tenantDb.models.app.findById(appId);
    //Check if appId is valid
    if (!appCheck) {
      //Application does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application does not exists !",
        },
      });
    }
    /* Multer*/
    const storage = Multer.memoryStorage();
    //File validation
    const fileFilter = (req, file, cb) => {
      // reject a file
      if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
        cb(null, true);
      } else {
        cb(
          new Error(
            JSON.stringify({
              rc: errArray.fileType.rc,
              rd: errArray.fileType.rd,
            })
          ),
          false
        );
      }
    };
    const upload = Multer({
      storage,
      limits: {
        // 10 mb
        fileSize: 1024 * 1024 * 10,
      },
      fileFilter: fileFilter,
    }).single("logo");
    //If valid appId, make a update obj
    let update = {};

    upload(req, res, async function (err) {
      if (err instanceof Multer.MulterError) {
        console.log(err);
        // A Multer error occurred when uploading.
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Something went wrong !",
          },
        };
        return res.status(200).send(response);
      } else if (err) {
        console.log(err);
        // An unknown error occurred when uploading.
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Something went wrong !",
          },
        };
        return res.status(200).send(response);
      }
      //Get Name
      if (req.body.name) update.name = req.body.name;
      //Get Address
      if (req.body.address) update.address = req.body.address;
      //Get desc
      if (req.body.desc) update.desc = req.body.desc;
      //Add other object key, which needs to be updated
      if (req.body.customerId) update.customerId = req.body.customerId;
      //Get Metadata
      if (req.body.metaData) update.metadata = JSON.parse(req.body.metaData);

      //Update
      const updated = await appCheck.update({
        $set: update,
      });
      if (updated) {
        try {
          //DB Logger
          const logged = await DbLogger(
            user,
            tenantId,
            req.metaObj.tenantDbName,
            req.metaObj.tenantName,
            logTypes.app.updated,
            true,
            {
              appName: appCheck.name,
              appId: appCheck.appId,
              msg: "Application Updated!",
            }
          );
          if (logged) {
            console.log("Data logged !");
          }
        } catch (e) {
          console.log("Data could not logged !", e);
        }
        //HTTP code can be 204
        return res.status(200).json({
          success: true,
          data: {
            code: 20,
            msg: "Application updated",
            results: update,
          },
        });
      }
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Delete one application
exports.deleteApp = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    //Get user - who is trying to update the app
    const user = req.user;
    //Get Tenant id
    const tenantId = req.metaObj.tenantId;
    //Get appId from request
    const appId = req.params.appId;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    // Find appId in app collection
    //Use tenant db > and app model form connection object returned from previous middleware
    const appCheck = await tenantDb.models.app.findOne({
      $and: [
        {
          _id: appId,
        },
        {
          _id: { $in: appIds },
        },
      ],
    });
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Get site Model - Auth Rajesh
    const SiteModel = await Site.model(tenantDb, "site");
    //Switch to master db
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get Device Model - master db
    const MDeviceModel = await MDevice.model(masterDbConn, "device");

    //Check if appId is valid
    if (!appCheck) {
      //Application does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application does not exists !",
        },
      });
    }
    //Remove this app from app collection
    await appCheck.deleteOne();
    //Remove all the devices
    await DeviceModel.deleteMany({ app: appId });
    //Remove all the sites
    await SiteModel.deleteMany({ app: appId });
    //Remove all the devices from master device collection
    await MDeviceModel.deleteMany({ app: appId });
    try {
      //DB Logger
      const logged = await DbLogger(
        user,
        tenantId,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.app.removed,
        true,
        {
          appName: appCheck.name,
          appId: appCheck.appId,
          msg: "Application Removed!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    //Send response
    //HTTP code can be 204
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "Application removed !",
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get all devices of one application - Rajesh
exports.getAllDevices = async (req, res) => {
  try {
    //Get appId from  URL
    const appId = req.params.appId;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;

    const apps = await tenantDb.models.app.findOne({ _id: appId });
    //console.log(apps);
    if (apps) {
      const deviceColl = "device";
      const DeviceModel = await Device.model(tenantDb, deviceColl);
      const data = await DeviceModel.find({ app: appId }).select(
        "_id name macAddress deviceId"
      );

      if (data.length) {
        let response = {
          success: true,
          data: {
            code: 20,
            msg: "Devices found for this application",
            devices: data,
          },
        };
        return res.status(200).send(response);
      } else {
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Devices not found for this application",
            devices: [],
          },
        };
        return res.status(200).send(response);
      }
    } else {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Application does not exists !",
          devices: [],
        },
      };
      return res.status(200).send(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get all sites of one application
exports.getAllSites = async (req, res) => {
  try {
    //Get appId from  URL
    const appId = req.params.appId;
    const db = await dbConn.mongoDbConn.useDb(masterDb);
    const UserModel = await User.model(db, "user");
    //Get user id
    const user = req.user;
    //Add Custom application schema in user model
    UserModel.schema.add({
      applications: [mongoose.Schema.Types.ObjectId],
    });
    //Check if user exists
    UserModel.findOne({
      _id: user.userId,
    })
      .then(async (user) => {
        if (!user) {
          return res.status(409).json({
            success: false,
            error: {
              code: 49,
              msg: "User does not exists !",
            },
          });
        }
        //Check if the application is linked with this user
        const appCheck = user.applications.includes(appId);
        if (!appCheck) {
          return res.status(404).json({
            success: false,
            error: {
              code: 44,
              msg: "Application is not assigned !",
            },
          });
        }

        return {
          user,
        };
      })
      .then(async (result) => {
        if (result.user) {
          //Get this tenant db
          const dbName = UtilFunctions.tenantDbName(
            result.user.username,
            tenantDbSuffix
          );
          if (!dbName) {
            return res.status(400).json({
              success: false,
              error: {
                code: 40,
                msg: "Something went wrong !",
              },
            });
          }

          //Use tenant db
          const db1 = await dbConn.mongoDbConn.useDb(dbName);
          //Check if application exists
          const AppModel = App.model(db1, "app");
          const app = await AppModel.findOne({
            _id: appId,
          });
          if (!app) {
            //Application does not exists
            return res.status(404).json({
              success: false,
              error: {
                code: 44,
                msg: "Application does not exists !",
              },
            });
          }
          //Get collection name for the site
          const collection = UtilFunctions.collectionName(
            app.internal_id,
            "site"
          );

          //Get site Model
          const SiteModel = await Site.model(db1, collection);
          const sites = await SiteModel.find({}).select("-__v").populate({
            path: "users.user",
            select: "name -_id",
            model: UserModel,
          });
          //If there is no site
          if (!sites.length > 0) {
            const response = {
              success: false,
              data: {
                code: 20,
                msg: "No sites found !",
                results: [],
              },
            };
            return res.status(200).send(response);
          }

          //If some sites found
          const results = {
            count: sites.length,
            sites: sites,
          };
          const response = {
            success: true,
            data: {
              code: 20,
              msg: "Sites found",
              results,
            },
          };
          return res.status(200).send(response);
        }
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error",
            error: err,
          },
        });
      });
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Updating site of an application
exports.updateTenantSite = async (req, res) => {
  try {
    //Get appId and siteId from request
    const appId = req.params.appId;
    const siteId = req.params.siteId;

    const db = await dbConn.mongoDbConn.useDb(masterDb);
    const UserModel = await User.model(db, "user");

    //Get user id from JWT Token
    const userJWT = req.user;
    //Add Custom application schema in user model for tenant
    UserModel.schema.add({
      applications: [mongoose.Schema.Types.ObjectId],
    });
    //Check if user exists
    const userCheck = await UserModel.findOne({
      _id: userJWT.userId,
    });
    if (!userCheck) {
      return res.status(409).json({
        success: false,
        error: {
          code: 49,
          msg: "User does not exists !",
        },
      });
    }

    //Check if the application is linked with this user
    const appCheck = userCheck.applications.includes(appId);
    if (!appCheck) {
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application is not assigned !",
        },
      });
    }
    //Get this tenant db
    const dbName = UtilFunctions.tenantDbName(
      userCheck.username,
      tenantDbSuffix
    );
    if (!dbName) {
      return res.status(409).json({
        success: false,
        error: {
          code: 51,
          msg: "Something went wrong !",
        },
      });
    }
    //Use tenant db
    const db1 = await dbConn.mongoDbConn.useDb(dbName);
    //Check if application exists
    const AppModel = App.model(db1, "app");
    const app = await AppModel.findOne({
      _id: appId,
    });
    if (!app) {
      //If applicatio does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application does not exists !",
        },
      });
    }
    //Get collection name for this site
    const collection = UtilFunctions.collectionName(app.internal_id, "site");
    const SiteModel = await Site.model(db1, collection);
    const site = await SiteModel.findOne({
      _id: siteId,
    });
    if (!site) {
      //If site does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Site does not exists !",
        },
      });
    }

    //If application  and  site exists for this tenant then update the site details
    const update = {};
    update.name = req.body.name;
    //Update
    const updated = await site.update({
      $set: update,
    });
    if (updated) {
      return res.status(200).json({
        success: true,
        data: {
          code: 20,
          msg: "Site updated",
          results: update,
        },
      });
    }
    return res.status(400).json({
      success: false,
      error: {
        code: 40,
        msg: "Something went wrong !",
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Delete one site of an application
exports.deleteTenantSite = async (req, res) => {
  try {
    //Get appId and siteId from request
    const appId = req.params.appId;
    const siteId = req.params.siteId;

    const db = await dbConn.mongoDbConn.useDb(masterDb);
    const UserModel = await User.model(db, "user");

    //Get user id from JWT Token
    const userJWT = req.user;
    //Add Custom application schema in user model for tenant
    UserModel.schema.add({
      applications: [mongoose.Schema.Types.ObjectId],
    });
    //Check if user exists
    const userCheck = await UserModel.findOne({
      _id: userJWT.userId,
    });
    if (!userCheck) {
      return res.status(409).json({
        success: false,
        error: {
          code: 49,
          msg: "User does not exists !",
        },
      });
    }

    //Check if the application is linked with this user
    const appCheck = userCheck.applications.includes(appId);
    if (!appCheck) {
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application is not assigned !",
        },
      });
    }
    //Get this tenant db
    const dbName = UtilFunctions.tenantDbName(
      userCheck.username,
      tenantDbSuffix
    );
    if (!dbName) {
      return res.status(409).json({
        success: false,
        error: {
          code: 51,
          msg: "Something went wrong !",
        },
      });
    }
    //Use tenant db
    const db1 = await dbConn.mongoDbConn.useDb(dbName);
    //Check if application exists
    const AppModel = App.model(db1, "app");
    const app = await AppModel.findOne({
      _id: appId,
    });
    if (!app) {
      //If applicatio does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application does not exists !",
        },
      });
    }
    /*Get collection name for this site - which are inside "appInternalId.sites" collection
    // const siteColl = UtilFunctions.collectionName(app.internal_id, 'site');
    */
    //Collection name For the sites which are inside the "tenantDB > Sites" master collection
    const siteColl = "site";
    const SiteModel = await Site.model(db1, siteColl);
    const site = await SiteModel.findOne({
      _id: siteId,
    });
    if (!site) {
      //If site does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Site does not exists !",
        },
      });
    }
    const deleted = await site.deleteOne();
    //If deleted
    if (deleted) {
      return res.status(200).json({
        success: true,
        data: {
          code: 20,
          msg: "Site removed",
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get all devices of one site
exports.getSiteAllDevice = async (req, res) => {
  //Auth Rajesh
  try {
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get appId and siteId from request
    const appId = req.params.appId;
    const siteId = req.params.siteId;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;

    const apps = await tenantDb.models.app.findOne({ _id: appId });
    //console.log(apps);
    if (apps) {
      const deviceColl = "device";
      const DeviceModel = await Device.model(tenantDb, deviceColl);

      const AppModel = tenantDb.models.app;

      const data = await DeviceModel.find({
        app: appId,
        site: siteId,
      })
        .select("_id name deviceId macAddress lat lng protocolType")
        .skip(prev)
        .limit(next)
        .populate({
          path: "app",
          select: "name -_id",
          model: AppModel,
        });

      if (data.length) {
        console.log(data);
        let response = {
          success: true,
          data: {
            code: 20,
            msg: "Devices found ",
            count: data.length,
            results: data,
          },
        };
        return res.status(200).send(response);
      } else {
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Devices not found",
            count: data.length,
            results: [],
          },
        };
        return res.status(200).send(response);
      }
    } else {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Application does not exists !",
          devices: [],
        },
      };
      return res.status(200).send(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get all unassigned devices of one application - Auth Rajesh
exports.getAllUnsndDevices = async (req, res) => {
  try {
    //Get appId from  URL
    const appId = req.params.appId;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;

    const apps = await tenantDb.models.app.findOne({ _id: appId });
    console.log(apps);
    if (apps) {
      const deviceColl = "device";
      const DeviceModel = await Device.model(tenantDb, deviceColl);
      const data = await DeviceModel.find({ app: appId, site: null }).select(
        "_id name macAddress"
      );

      if (data.length) {
        console.log(data);
        let response = {
          success: true,
          data: {
            code: 20,
            msg: "Devices found for this application",
            count: data.length,
            results: data,
          },
        };
        return res.status(200).send(response);
      } else {
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Devices of this application are already assigned",
            count: data.length,
            results: [],
          },
        };
        return res.status(200).send(response);
      }
    } else {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Application does not exists !",
          devices: [],
        },
      };
      return res.status(200).send(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Apps Search - regex - Rajesh
exports.getAppsForSearch = async (req, res) => {
  try {
    //
    //Get Query params for search and pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    let appName = null;
    let solution = null;
    let customer = null;
    let status = null;
    let matchRegex = {};
    let matchCustomerRegex = {};
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }
      //Apps name/id/solution for regex
      if (req.query.appName) {
        appName = req.query.appName;
        matchRegex.name = {
          $regex: appName,
          $options: "i",
        };
      }
      if (req.query.solution) {
        solution = req.query.solution;
        matchRegex["solution.name"] = {
          $regex: solution,
          $options: "i",
        };
      }
      if (req.query.status) {
        status = req.query.status;
        matchRegex.status = {
          $regex: status,
          $options: "i",
        };
      }

      if (req.query.customer) {
        customer = req.query.customer;
        matchCustomerRegex["customer.name"] = {
          $regex: customer,
          $options: "i",
        };
      }
    }
    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      { $match: matchRegex },

      {
        $match: {
          _id: {
            $in: mongooseTAppIds,
          },
        },
      },
      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $project: {
          app: "$$ROOT",
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      { $match: matchCustomerRegex },
      {
        $project: {
          app: 1,
          customer: { $arrayElemAt: ["$customer", 0] },
        },
      },
    ];

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;

    const appIds = req.metaObj.apps;

    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    const apps = await tenantDb.models.app.aggregate(pipeline);
    //return app;

    const response = {
      success: apps.length > 0 ? true : false,
      data: {
        code: 20,
        msg: apps.length > 0 ? "Records found" : "No records found",
        count: apps.length,
        results: apps,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get Apps - Which should be assigned to "Customer"
exports.getAllCustomerApps = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Customer Model
    const customerColl = "customer";
    const CustomerModel = await Customer.model(tenantDb, customerColl);
    //Use tenant db > and app model form connection object returned from previous middleware
    const apps = await tenantDb.models.app
      .find({ self: { $ne: true } })
      .skip(prev)
      .limit(next)
      .populate({
        path: "customer",
        select: "name _id",
        model: CustomerModel,
      })
      .select("-_id name");
    //Format response
    const response = {
      success: apps.length > 0 ? true : false,
      data: {
        code: 20,
        msg: apps.length > 0 ? "Records found" : "No records found",
        count: apps.length,
        results: apps,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get Device manufacturer - Auth Rajesh
exports.getDeviceManufacturer = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;

    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },

      {
        $group: {
          _id: "$app",
          device: {
            $push: "$$ROOT",
          },
        },
      },
      {
        $project: {
          app: {
            $arrayElemAt: ["$device.app", 0],
          },
          device: 1,
          manufacturer: 1,
        },
      },
      { $unwind: "$device" },
      {
        $lookup: {
          from: "mfr.models",
          localField: "device.mfrId",
          foreignField: "_id",
          as: "manufacturer",
        },
      },
      {
        $lookup: {
          from: "apps",
          localField: "app",
          foreignField: "_id",
          as: "app",
        },
      },

      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },

      {
        $project: {
          device: 1,
          manufacturer: {
            $arrayElemAt: ["$manufacturer", 0],
          },
          app: {
            $arrayElemAt: ["$app", 0],
          },
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          app: {
            _id: "$app._id",
            name: "$app.name",
          },
          device: {
            _id: "$device._id",
            name: "$device.name",
            app: "$device.app",
          },
          manufacturer: {
            _id: "$manufacturer._id",
            name: "$manufacturer.name",
            model: "$manufacturer.model",
            gateway: "$manufacturer.gateway",
            helperFn: "$manufacturer.helperFn",
            deviceProfiles: "$manufacturer.deviceProfiles",
          },
        },
      },
    ];
    const deviceColl = "device";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);

    const data = await DeviceModel.aggregate(pipeline);
    let finalData = [];
    //return devs;
    data.map((obj) => {
      if (
        obj.device.app == req.params.appId &&
        obj.device._id == req.params.deviceId
      ) {
        finalData.push(obj);
      }
    });
    let resultData = finalData[0].manufacturer.deviceProfiles;
    if (resultData.length > 0) {
      let response = {
        success: resultData.length > 0 ? true : false,
        data: {
          code: 20,
          msg: resultData.length > 0 ? "Records found" : "No records found",
          count: resultData.length,
          results: resultData,
        },
      };
      return res.status(200).send(response);
    }

    let response = {
      success: finalData.length > 0 ? true : false,
      data: {
        code: 20,
        msg: finalData.length > 0 ? "Records found" : "No records found",
        count: finalData.length,
        results: [finalData[0].manufacturer.deviceProfiles],
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get Device data-path - Auth Rajesh
exports.getDeviceDataPath = async (req, res) => {
  try {
    let deviceProfileId = req.params.deviceProfileId;

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;

    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    const devicePColl = "device.profile";
    //Get device profile Model
    const DeviceProfileModel = await DeviceProfile.model(tenantDb, devicePColl);

    const data = await DeviceProfileModel.find({ _id: deviceProfileId });

    if (data.length > 0) {
      let parameters = data[0].dataSchema;
      parameters.CONNECT = false;
      parameters.DISCONNECT = false;

      const response = {
        success: data.length > 0 ? true : false,
        data: {
          code: 20,
          msg: data.length > 0 ? "Records found" : "No records found",
          count: data.length,
          results: parameters,
        },
      };
      return res.status(200).send(response);
    } else {
      const response = {
        success: data.length > 0 ? true : false,
        data: {
          code: 20,
          msg: data.length > 0 ? "Records found" : "No records found",
          count: data.length,
          results: data,
        },
      };
      return res.status(200).send(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get all solution-metadata of one application - Rajesh
exports.getAllSolutionsMetadata = async (req, res) => {
  try {
    //Get appId from  URL
    const appId = req.params.appId;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;

    const apps = await tenantDb.models.app.findOne({ _id: appId });
    //console.log(apps);
    if (apps) {
      const solutionName = apps.solution.name;
      const masterDbConn = await tenantDb.useDb(masterDb);
      //Get Configuration url Model - master db
      const MSolutionModel = await MSolution.model(masterDbConn, "solution");

      const data = await MSolutionModel.find({ name: solutionName }).select(
        "name metadata"
      );

      if (data.length) {
        let response = {
          success: true,
          data: {
            code: 20,
            msg: "Metadata found for this application",
            results: data[0],
          },
        };
        return res.status(200).send(response);
      } else {
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Metadata not found for this application",
            results: [],
          },
        };
        return res.status(200).send(response);
      }
    } else {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Application does not exists !",
          devices: [],
        },
      };
      return res.status(200).send(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

// Upload logo file
exports.uploadLogo = async (req, res, next) => {
  try {
    //Get appId from  URL
    const appId = req.query.appId;

    /* Multer*/
    const storage = Multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, "./uploads/");
      },
      filename: function (req, file, cb) {
        cb(null, file.originalname);
      },
    });
    const fileFilter = (req, file, cb) => {
      // reject a file
      if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
        cb(null, true);
      } else {
        cb(
          new Error(
            JSON.stringify({
              rc: errArray.fileType.rc,
              rd: errArray.fileType.rd,
            })
          ),
          false
        );
      }
    };
    const upload = Multer({
      storage: storage,
      limits: {
        // 10 mb
        fileSize: 1024 * 1024 * 10,
      },
      fileFilter: fileFilter,
    }).single("file");

    upload(req, res, function (err) {
      if (err instanceof Multer.MulterError) {
        console.log(err);
        // A Multer error occurred when uploading.
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Something went wrong !",
          },
        };
        return res.status(200).send(response);
      } else if (err) {
        console.log(err);
        // An unknown error occurred when uploading.
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Something went wrong !",
          },
        };
        return res.status(200).send(response);
      }
      //Upload
      const minioUpload = () => {
        // Instantiate the minio client with the endpoint
        // and access keys as shown below.
        var minioClient = new Minio.Client({
          endPoint: minioServer.host,
          port: minioServer.port,
          useSSL: false,
          accessKey: minioServer.username,
          secretKey: minioServer.password,
        });
        //Check if bucket exists
        minioClient.bucketExists("hts-apps", function (error, exists) {
          if (error) {
            let response = {
              success: false,
              data: {
                code: 20,
                msg: "Something went wrong !",
              },
            };
            return res.status(200).send(response);
          }
          if (!exists) {
            // Make a bucket called hts-apps.
            minioClient.makeBucket("hts-apps", "us-east-1", function (err) {
              if (err) return console.log(err);
              console.log('Bucket created successfully in "us-east-1".');
            });
          }
        });
        //Meta data
        const metaData = {
          "Content-Type": "image/*",
          "X-Amz-Meta-Testing": 1234,
          example: 5678,
        };
        console.log(req.file.path);
        // Using fPutObject API upload your file to the bucket europetrip.
        minioClient.fPutObject(
          "hts-apps",
          `${appId}.jpg`,
          req.file.path,
          metaData,
          function (err, etag) {
            if (err) return console.log(err);
            // Everything went fine.
            let response = {
              success: false,
              data: {
                code: 20,
                msg: "Logo uploaded !",
              },
            };
            return res.status(200).send(response);
          }
        );
      };
      //Call Minio
      minioUpload();
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
// Check apps health
exports.getAppsHealth = async (req, res, next) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    const tenantId = req.metaObj.tenantId;
    //Check
    if (!tenantDb || !appIds || !tenantId) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Prometheus promise
    const promPromise = () => {
      return new Promise(async (resolve, reject) => {
        try {
          //Get app status which are up
          const promQuery = await Axios({
            method: "GET",
            url: `${promEndpoint}/query?query=up{tenantId="${tenantId}"}`,
          });
          let appStatusArray = [];
          if (promQuery.data.data.result.length > 0) {
            promQuery.data.data.result.map((appStatus) => {
              appStatusArray.push(appStatus.metric.appId);
            });
          }
          let updateApps = {};
          // Update status
          if (appStatusArray.length > 0) {
            updateApps = await tenantDb.models.app.updateMany(
              { _id: { $in: appStatusArray } },
              { $set: { status: "Up" } }
            );
          }
          //Set timeout - 3 sec
          setTimeout(() => resolve(updateApps), 3000);
        } catch (err) {
          //Set timeout - 3 sec
          setTimeout(() => reject("Error"), 3000);
        }
      });
    };
    //Call the promise
    promPromise()
      .then((counts) => {
        return res.status(200).json({
          success: false,
          error: {
            code: 20,
            msg: "App status updated !",
          },
        });
      })
      .catch((e) => {
        return res.status(400).json({
          success: false,
          error: {
            code: 40,
            msg: "Something went wrong !",
          },
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get device types of one application - Rajesh
exports.getDeviceTypes = async (req, res) => {
  try {
    //Get appId from  URL
    const appId = req.params.appId;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;

    const deviceColl = "device";
    const devicePColl = "device.profile";
    const mfrModel = "mfr.model";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    //Device Profile Model
    const DeviceProfileModel = await DeviceProfile.model(tenantDb, devicePColl);
    //Device Manufacturer Model
    const DeviceMfrModel = await DeviceMfr.model(tenantDb, mfrModel);

    let types = [];
    let obj = {};

    const devicesMfrs = await DeviceModel.find({ app: appId }).select(" mfrId");
    let map1 = await devicesMfrs.map(async (mfr) => {
      let mfrDetails = await DeviceMfrModel.findOne({ _id: mfr.mfrId }).select(
        " deviceProfiles"
      );

      let input = mfrDetails.deviceProfiles;

      for (var type in input) {
        let a = input[type];
        obj[a] = type;
      }
    });

    let deviceTypes = await Promise.all(map1).then(async (data) => {
      // const swapedData = await Object.fromEntries(
      //   Object.entries(obj).map(([k, v]) => [v, k])
      // );
      types.push(obj);
    });

    console.log("types ", types);

    if (types.length) {
      if (types.length) {
        let response = {
          success: true,
          data: {
            code: 20,
            msg: "Records found",
            count: types.length,
            results: types,
          },
        };
        return res.status(200).send(response);
      } else {
        let response = {
          success: false,
          data: {
            code: 20,
            msg: "Records not found",
            results: [],
          },
        };
        return res.status(200).send(response);
      }
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//App logo URL
exports.getAppLogoURL = async (req, res) => {
  try {
    let assets = [];
    // Instantiate the minio client with the endpoint
    // and access keys as shown below.
    var minioClient = new Minio.Client({
      endPoint: minioServer.host,
      port: minioServer.port,
      useSSL: false,
      accessKey: minioServer.username,
      secretKey: minioServer.password,
    });
    var objectsStream = minioClient.listObjects(minioAppLogoBucket, "", true);
    objectsStream.on("data", function (obj) {
      // Lets construct the URL with our object name.
      var publicUrl =
        minioClient.protocol +
        "//" +
        minioClient.host +
        ":" +
        minioClient.port +
        "/" +
        minioAppLogoBucket +
        "/" +
        obj.name;
      assets.push(publicUrl);
    });
    objectsStream.on("error", function (e) {
      console.log(e);
      return res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: e,
        },
      });
    });
    objectsStream.on("end", function (e) {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Records found",
          results: assets,
        },
      };
      return res.status(200).send(response);
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
