/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      protocol: {
        type: String,
      },
      host: {
        type: String,
      },
      port: {
        type: Number,
      },
      baseUrl: {
        type: String,
      },
      monitoringPort: {
        type: Number,
      },
    },
    {
      timestamps: true,
      strict: false,
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
