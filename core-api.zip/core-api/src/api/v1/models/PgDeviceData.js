/*jshint esversion: 8 */
const Sequelize = require("sequelize");
/*
!PGSQL Model for device data
*/
function model(db, collection) {
  const schema = {
    // attributes
    id: {
      type: Sequelize.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    data: {
      type: Sequelize.JSON
    }
  };
  return db.define(collection, schema);
}
exports.model = model;
