/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      ruleId: { type: String, require: true },
      app: { type: mongoose.Schema.Types.ObjectId, require: false },
      deviceId: { type: String, require: true },
      deviceType: { type: String, require: true },
      name: { type: String, require: true },
      desc: { type: String },
      dataPath: { type: String },
      operator: { type: String },
      value: { type: String },
      severity: { type: Number },
      statement: { type: String },
      status: { type: Boolean, default: true },
      incharge: {
        L1: {
          userId: { type: mongoose.Schema.Types.ObjectId, require: true },
          notify: { email: { type: Boolean }, mobile: { type: Boolean } }
        },
        L2: {
          userId: { type: mongoose.Schema.Types.ObjectId, require: true },
          notify: { email: { type: Boolean }, mobile: { type: Boolean } }
        },
        L3: {
          userId: { type: mongoose.Schema.Types.ObjectId, require: true },
          notify: { email: { type: Boolean }, mobile: { type: Boolean } }
        },
        L4: {
          userId: { type: mongoose.Schema.Types.ObjectId, require: true },
          notify: { email: { type: Boolean }, mobile: { type: Boolean } }
        },
        L5: {
          userId: { type: mongoose.Schema.Types.ObjectId, require: true },
          notify: { email: { type: Boolean }, mobile: { type: Boolean } }
        }
      }
    },
    { timestamps: true, strict: false }
  );
  return db.model(collection, schema);
}
exports.model = model;
