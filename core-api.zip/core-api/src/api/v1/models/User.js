/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  let schema = mongoose.Schema(
    {
      email: {
        address: { type: String, required: true, unique: true },
        verified: {
          type: Boolean,
          default: false
        }
      },
      mobile: {
        number: { type: String, required: true, unique: true },
        verified: {
          type: Boolean,
          default: false
        }
      },
      name: {
        type: String
      },
      companyName: String,
      address: Array,
      tenant: {
        type: mongoose.Schema.Types.ObjectId
        // ref: "Tenant"
      },
      customer: {
        type: mongoose.Schema.Types.ObjectId
        // ref: "Customer"
      },
      addedBy: {
        type: mongoose.Schema.Types.ObjectId
        //ref: "User"
      },
      role: {
        type: mongoose.Schema.Types.ObjectId
        // required: true,
        // ref: "role.rights",
      },
      password: { type: String, required: true },
      timezone: {
        type: String,
        default: "Asia/Kolkata"
      },
      is_verified: {
        type: Boolean,
        default: false
      },
      is_active: {
        type: Boolean,
        default: true
      }
    },
    {
      // toJSON: { virtuals: true },
      // toObject: { virtuals: true },
      timestamps: true,
      strict: false
    }
  );
  //Set virtual for roleId
  // schema.virtual("getRole", {
  //   ref: "RoleAndRights",
  //   localField: "roleId",
  //   foreignField: "_id",
  //   justOne: true
  // });
  return db.model(collection, schema);
}
exports.model = model;
