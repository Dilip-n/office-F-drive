/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      name: {
        type: String,
        require: true
      },
      model: {
        type: String,
        require: true
      },
      gateway: {
        type: Boolean,
        default: false
      },
      helperFn: {
        type: String,
        default: "default"
      },
      protocolType: {
        type: String,
        require: true
      },
      deviceProfiles: {
        type: Object,
        require: true
      }
    },
    {
      timestamps: true,
      strict: false
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
