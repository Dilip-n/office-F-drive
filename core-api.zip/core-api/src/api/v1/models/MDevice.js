/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      tenantId: {
        type: String,
        require: true
      },
      deviceId: {
        type: String,
        require: true
      },
      app: {
        type: mongoose.Schema.Types.ObjectId,
        require: true
      },
      gateway: {
        type: Boolean,
        require: true
      },
      mfrId: {
        type: mongoose.Schema.Types.ObjectId,
        require: true
      },
      name: {
        type: String,
        require: true
      },
      macAddress: {
        type: String,
        require: true
      },
      protocolType: {
        type: String,
        require: true
      },
      credentials: {
        type: Object
      }
    },
    {
      timestamps: true,
      strict: false
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
