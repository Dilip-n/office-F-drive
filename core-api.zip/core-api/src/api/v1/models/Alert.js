/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      app: {
        type: String,
        required: true
      },
      device: {
        type: String,
        required: true
      },
      data: {
        type: Number
        // required: true
      },
      name: {
        type: String
        // required: true
      },
      serverity: {
        type: String
        // required: true
      },
      desc: {
        type: String
        // required: true
      },
      assigned: {
        type: Boolean,
        default: false
      }, //assigned= true, unassigned=false
      status: {
        type: Boolean,
        default: true
      } //active= true, inactive=false
    },
    {
      timestamps: true,
      strict: false
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
