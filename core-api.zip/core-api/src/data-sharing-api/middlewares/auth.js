/*jshint esversion: 8 */
const jwt = require("jsonwebtoken");
//Get JWT Signature
const { jwtSecrets, mongoDb, pgdb } = require("./../../constants");
const masterDb = mongoDb.masterDb;
//Require mongoose
const mongoose = require("mongoose");
//Mongo DB connection
const dbConn = require("./../../config/ds.express.config");
const pgConn = require("./../../config/pgsql.config");
//Require Tenant Model
const Tenant = require("./../../api/v1/models/Tenants");
//Require App Model
const App = require("./../../api/v1/models/App");
//Requiere Util
let { UtilFunctions } = require("./../../api/v1/utils");
UtilFunctions = new UtilFunctions();

module.exports = async function (req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        error: {
          code: 41,
          msg: "No Token Provided",
        },
      });
    }
    //Split token
    const token = authHeader.split(" ")[1]; //Authorization: Bearer token
    if (!token || token === "") {
      return res.status(401).json({
        success: false,
        error: {
          code: 41,
          msg: "No Token Provided",
        },
      });
    }
    //Verify JWT

    try {
      const decoded = jwt.verify(token, jwtSecrets.tokenSecret);

      //Master DB connection
      const db = await dbConn.mongoDbConn.useDb(masterDb);

      //Tenant Model
      const TenantModel = await Tenant.model(db, "tenant");
      //Find tenant
      const tenant = await TenantModel.findOne({ _id: decoded.tenantId });

      //Get Tenant DB
      const tenantDbName = tenant.dbName;
      //Get the full tenant db
      const dbName = UtilFunctions.tenantDbName(tenantDbName);
      if (!dbName || !tenantDbName) {
        return res.status(400).json({
          success: false,
          error: {
            code: 40,
            msg: "Something went wrong !",
          },
        });
      }
      //Use tenant db
      const db1 = await dbConn.mongoDbConn.useDb(dbName);
      //Get App Model
      const ApplicationModel = App.model(db1, "app");
      const app = await ApplicationModel.findOne({ appId: decoded.appId });
      // If no such app
      if (!app) {
        return res.status(400).json({
          success: false,
          error: {
            code: 40,
            msg: "Application not found !",
          },
        });
      }
      //Get this tenant db - PGSQL
      const pgdbName = UtilFunctions.tenantPgDbName(tenantDbName);
      const uri = `postgres://${pgdb.username}:${pgdb.password}@${pgdb.host}:${pgdb.port}/${pgdbName}`;
      const pgDbConn = await pgConn.connectDb(uri);
      //Pass on the meta info
      req.metaInfo = {
        app: app._id,
        mtenantDb: db1,
        pTenantDb: pgDbConn,
        tDbName: tenantDbName,
      };
      next();
    } catch (err) {
      console.log(err);
      return res.status(403).json({
        success: false,
        error: {
          code: 41,
          msg: "Invalid token",
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(401).json({
      success: false,
      error: {
        code: 41,
        msg: "Unable to verify your credentials.",
      },
    });
  }
};
