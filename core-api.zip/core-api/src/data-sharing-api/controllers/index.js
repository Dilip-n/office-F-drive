/*jshint esversion: 8 */
//Require Axios
const axios = require("axios");
//Require JOI
const Joi = require("@hapi/joi");
//Require Bcrypt
const Bcrypt = require("bcrypt");
//Import JWT
const Jwt = require("jsonwebtoken");
//Require Randomatic for keys
const randomize = require("randomatic");
const btoa = require("btoa");
const {
  mongoDb,
  emqxHost,
  jwtSecrets,
  sendCommandEndPoint,
} = require("./../../constants");
//Mongo DB connection
const dbConn = require("./../../config/ds.express.config");
//Require User Model
const User = require("./../../api/v1/models/User");
//Require App Model
const App = require("./../../api/v1/models/App");
//Require Site Model
const Site = require("./../../api/v1/models/Site");
//Require Device Model
const Device = require("./../../api/v1/models/Device");
//Require Tenant Model
const Tenant = require("./../../api/v1/models/Tenants");
//Require DeviceProfile Model
const DeviceProfile = require("./../../api/v1/models/DeviceProfile");
//Require Device Manufacturer Model
const DeviceMfr = require("./../../api/v1/models/Manufacturer");
//Require MDevice - Device in Master db
const MDevice = require("./../../api/v1/models/MDevice");
//Require MConfigUrls - config urls in Master db
const MConfigUrl = require("./../../api/v1/models/ConfigUrls");
//Require Util module
const Keys = require("./../../api/v1/utils/keys");
//Get master db name
const masterDb = mongoDb.masterDb;
//Requiere Util
let { UtilFunctions } = require("./../../api/v1/utils");
UtilFunctions = new UtilFunctions();
/*

! Controller functions starts

*/

//Normal signin
exports.generalSignin = async (req, res) => {
  try {
    //Master DB Conn
    const db = await dbConn.mongoDbConn.useDb(masterDb);
    const UserModel = await User.model(db, "user");

    //Check if the mobile/email exists
    UserModel.findOne({
      "email.address": req.body.email,
    })
      .then(async (user) => {
        if (!user) {
          res.status(401).json({
            success: false,
            error: {
              code: 44,
              msg: "User does not exists",
            },
          });
        } else {
          Bcrypt.compare(
            req.body.password,
            user.password,
            async function (err, result) {
              if (err) {
                return res.status(401).json({
                  success: false,
                  error: {
                    code: 41,
                    msg: "Auth Failed",
                  },
                });
              }
              if (result) {
                //Get tenant DB and apps - mongo
                const mTenantDb = req.metaInfo.mtenantDb;
                let app = req.metaInfo.app;
                //Check
                if (!mTenantDb || !app) {
                  return res.status(400).json({
                    success: false,
                    error: {
                      code: 40,
                      msg: "Something went wrong !",
                    },
                  });
                }
                //Get Tenant
                const tenant_id = user.tenant;
                //FInd
                //Tenant Model
                const TenantModel = await Tenant.model(db, "tenant");
                //Find tenant
                const tenant = await TenantModel.findOne({
                  _id: tenant_id,
                });
                try {
                  //Tenant DB Conn
                  const tdb = await db.useDb(`${tenant.dbName}-tenant-db`);
                  const AppModel = await App.model(tdb, "app");
                  //Find tenant
                  const appCheck = await AppModel.findOne({
                    _id: app,
                  });
                  //Check
                  if (!appCheck) {
                    return res.status(400).json({
                      success: false,
                      error: {
                        code: 40,
                        msg: "Application not found !",
                      },
                    });
                  }
                } catch (e) {
                  return res.status(400).json({
                    success: false,
                    error: {
                      code: 40,
                      msg: "Application not found !",
                    },
                  });
                }
                return res.status(200).json({
                  success: true,
                  data: {
                    code: 20,
                    msg: "Login Successful",
                    results: {
                      name: user.name,
                      email: user.email.address,
                      mobile: user.mobile.number,
                    },
                  },
                });
              }
              return res.status(401).json({
                success: false,
                error: {
                  code: 41,
                  msg: "Password does not match !",
                },
              });
            }
          );
        }
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error",
            error: err,
          },
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Signin with app tokens
exports.signin = async (req, res) => {
  try {
    //Master DB Conn
    const db = await dbConn.mongoDbConn.useDb(masterDb);
    const UserModel = await User.model(db, "user");

    //Check if the mobile/email exists
    const user = await UserModel.findOne({
      "email.address": req.body.email,
    });
    //If no such user
    if (!user) {
      res.status(401).json({
        success: false,
        error: {
          code: 44,
          msg: "User does not exists",
        },
      });
    }
    const passwordCheck = await Bcrypt.compareSync(
      req.body.password,
      user.password
    );
    if (!passwordCheck) {
      return res.status(401).json({
        success: false,
        error: {
          code: 41,
          msg: "Auth Failed",
        },
      });
    }
    const appTokens = req.body.tokens;
    //Check
    if (!appTokens || appTokens.length < 1) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //App Flag
    let appFlag = false;
    let validApp = null;
    //Check all the tokens
    for (i = 0; i < appTokens.length; i++) {
      //Check for all tokens
      if (appTokens[i].token) {
        try {
          const decoded = Jwt.verify(
            appTokens[i].token,
            jwtSecrets.tokenSecret
          );

          //Tenant Model
          const TenantModel = await Tenant.model(db, "tenant");
          //Find tenant
          const tenant = await TenantModel.findOne({
            _id: decoded.tenantId,
          });
          //Get Tenant DB
          const tenantDbName = tenant.dbName;
          //Get the full tenant db
          const dbName = UtilFunctions.tenantDbName(tenantDbName);
          if (dbName || tenantDbName) {
            //Use tenant db
            const db1 = await db.useDb(dbName);
            //Get App Model
            const ApplicationModel = App.model(db1, "app");
            //Find app
            const app = await ApplicationModel.findOne({
              appId: decoded.appId,
            });

            // If app found
            if (app) {
              appFlag = true;
              validApp = appTokens[i];

              break;
            }
          }
        } catch (err) {
          appFlag = false;
        }
      }
    }
    //After all checks
    if (appFlag && validApp != null) {
      return res.status(200).json({
        success: true,
        data: {
          code: 20,
          msg: "Login Successful",
          results: {
            name: user.name,
            email: user.email.address,
            mobile: user.mobile.number,
            address: user.address[0],
            app: validApp,
          },
        },
      });
    } else {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Application not found !",
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/*
Get app for one tenant - Mactching token
*/
exports.getApp = async (req, res) => {
  try {
    /*
    
    
    */

    //Get tenant DB and apps - mongo
    const mTenantDb = req.metaInfo.mtenantDb;
    let app = req.metaInfo.app;
    if (!mTenantDb || !app) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Find app
    const appCheck = await mTenantDb.models.app.findOne({ _id: app });
    //Response
    const response = {
      success: appCheck ? true : false,
      data: {
        code: 20,
        msg: appCheck ? "Records found" : "No records found",
        results: appCheck,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/*
Find all devices for one tenant 
*/
exports.getAllDevices = async (req, res) => {
  try {
    /*
    
    
    */

    //Get tenant DB and apps - mongo
    const mTenantDb = req.metaInfo.mtenantDb;
    let app = req.metaInfo.app;
    if (!mTenantDb || !app) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get device Model
    const DeviceModel = await Device.model(mTenantDb, "device");
    const devices = await DeviceModel.find({ app });
    //Response
    const response = {
      success: devices.length > 0 ? true : false,
      data: {
        code: 20,
        msg: devices.length > 0 ? "Records found" : "No records found",
        count: devices.length,
        results: devices,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

/*
Find all sites for one tenant
*/
exports.getAllSites = async (req, res) => {
  try {
    /*
    
    
    */

    //Get tenant DB and apps - mongo
    const mTenantDb = req.metaInfo.mtenantDb;
    let app = req.metaInfo.app;
    if (!mTenantDb || !app) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get site Model
    const SiteModel = await Site.model(mTenantDb, "site");
    const sites = await SiteModel.find({ app });
    //Response
    const response = {
      success: sites.length > 0 ? true : false,
      data: {
        code: 20,
        msg: sites.length > 0 ? "Records found" : "No records found",
        count: sites.length,
        results: sites,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

/*
Find raw data of one device 
*/
exports.getDeviceData = async (req, res) => {
  try {
    /*
    
    
    */

    //Get tenant DB and apps - mongo
    const mTenantDb = req.metaInfo.mtenantDb;
    //Get appId
    let app = req.metaInfo.app;
    //Get deviceId from request
    const deviceId = req.params.deviceId;
    //Get from - to date
    const fromDate = req.query.fromDate;
    const toDate = req.query.toDate;
    //D
    let deviceType = "default";
    if (req.query.deviceType) deviceType = req.query.deviceType;

    if (!mTenantDb || !app) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get device Model
    const DeviceModel = await Device.model(mTenantDb, "device");
    const device = await DeviceModel.findOne({ deviceId });

    if (!device) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Device not found !",
        },
      });
    }
    //Get PG Connection
    const pgConn = req.metaInfo.pTenantDb;
    //Default SQL
    let sql =
      "SELECT * FROM device_data where device_id =:deviceId and device_type = :deviceType ORDER BY time desc limit 10";
    let options = {
      replacements: { deviceId, deviceType },
      type: pgConn.QueryTypes.SELECT,
    };
    //Check to and from date range
    //Add time range
    if (fromDate && toDate) {
      sql =
        "SELECT * FROM device_data where device_id=:deviceId and device_type = :deviceType and extract(epoch FROM time) >= :fromDate and extract(epoch FROM time) <= :toDate ORDER BY time desc";
      options = {
        replacements: { deviceId, fromDate, toDate, deviceType },
        type: pgConn.QueryTypes.SELECT,
      };
    }
    //Execute Query
    const rawdata = await pgConn.query(sql, options);
    //Response
    const response = {
      success: rawdata.length > 0 ? true : false,
      data: {
        code: 20,
        msg: rawdata.length > 0 ? "Records found" : "No records found",
        count: rawdata.length,
        results: rawdata,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/*
Send Command using EMQX
*/
exports.sendMqttCommand = async (req, res) => {
  //Get request body
  const input = {
    username: req.body.username,
    password: req.body.password,
    topic: req.body.topic,
    payload: req.body.payload,
    qos: req.body.qos,
    retain: req.body.retain,
    clientid: req.body.clientid,
  };
  //Validate using JOI
  const schema = Joi.object({
    username: Joi.string().required(),
    password: Joi.string().required(),

    topic: Joi.string().required(),
    payload: Joi.string().required(),
    qos: Joi.number().required(),
    retain: Joi.boolean().required(),
    clientid: Joi.string().required(),
  });

  try {
    const value = await schema.validate(input);
    //Send Request to EMQX
    try {
      const response = await axios({
        method: "POST",
        url: `${emqxHost}/api/v3/mqtt/publish`,
        auth: {
          username: input.username,
          password: input.password,
        },
        data: {
          topic: input.topic,
          payload: input.payload,
          qos: input.qos,
          retain: input.retain,
          clientid: input.clientid,
        },
      });

      //If command sent successfully
      if (response.data && response.data.code === 0) {
        //Response
        return res.status(200).send({
          success: true,
          data: {
            code: 20,
            msg: "Command sent",
            results: response.data,
          },
        });
      }
      //Response
      return res.status(200).send({
        success: true,
        data: {
          code: 20,
          msg: "Command could not be sent",
          results: response.data,
        },
      });
    } catch (err) {
      console.log(err);
      return res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: err,
        },
      });
    }
  } catch (err) {
    return res.status(400).json({
      success: false,
      error: {
        code: 40,
        msg: "Invalid request data",
        error: err,
      },
    });
  }
};
/*
Send Command to TCP handler
*/
exports.sendTcpCommand = async (req, res) => {
  //Get request body
  const input = {
    deviceId: req.body.deviceId,
    payload: req.body.payload,
    ts: req.body.ts,
  };
  //Validate using JOI
  const schema = Joi.object({
    deviceId: Joi.string().required(),
    payload: Joi.string().required(),
    ts: Joi.string().required(),
  });

  try {
    const value = await schema.validate(input);

    try {
      /*
    
    
    */

      //Get tenant DB and apps - mongo
      const mTenantDb = req.metaInfo.mtenantDb;
      //Get appId
      let app = req.metaInfo.app;
      if (!mTenantDb || !app) {
        return res.status(400).json({
          success: false,
          error: {
            code: 40,
            msg: "Something went wrong !",
          },
        });
      }

      //Get device Model
      const DeviceModel = await Device.model(mTenantDb, "device");
      const device = await DeviceModel.findOne({
        macAddress: input.deviceId,
      });
      if (!device) {
        return res.status(400).json({
          success: false,
          error: {
            code: 40,
            msg: "Device not found !",
          },
        });
      }
      //Get tenant DB Name
      const tenantDbName = `${req.metaInfo.tDbName}-tenant-db`;
      //Send the input data to command handler
      const response = await axios({
        method: "POST",
        url: `${sendCommandEndPoint}/command`,
        data: {
          deviceId: device.deviceId,
          payload: input.payload,
          tenantDbName: tenantDbName,
          protocol: device.protocolType,
          tenantId: req.metaInfo.tDbName,
          ts: input.ts,
        },
      });
      //If command sent successfully
      if (response.data) {
        //Response
        return res.status(200).send({
          success: true,
          data: {
            code: 20,
            msg: "Command sent",
            results: response.data,
          },
        });
      }
      //Response
      return res.status(200).send({
        success: true,
        data: {
          code: 20,
          msg: "Command could not be sent",
          results: response.data,
        },
      });
    } catch (err) {
      console.log(err.response);
      return res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: err,
        },
      });
    }
  } catch (err) {
    return res.status(400).json({
      success: false,
      error: {
        code: 40,
        msg: "Invalid request data",
        error: err,
      },
    });
  }
};
//Getting all devices - (by Rajesh on 27-May-2020)
exports.getAllDeviceStatus = async (req, res) => {
  try {
    /*
    
    
    */

    //Get tenant DB and apps - mongo
    const mTenantDb = req.metaInfo.mtenantDb;
    //console.log(mTenantDb);
    //Get appId
    let app = req.metaInfo.app;
    //Get from - to date
    const fromDate = req.query.fromDate;
    const toDate = req.query.toDate;

    // console.log("app ", app);

    if (!mTenantDb || !app) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get device Model

    const DeviceModel = await Device.model(mTenantDb, "device");
    const devices = await DeviceModel.find({
      app: { $in: [app] },
    }).select("deviceId desc macAddress");
    //console.log(devices);
    //When no alerts
    if (devices.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let deviceIds = [];

    devices.map((id) => {
      //Convert the mongo _id type to string
      deviceIds.push(id.deviceId.toString());
    });
    console.log(deviceIds);
    //Get PG Connection
    const pgConn = req.metaInfo.pTenantDb;

    const rawdata = await pgConn.query(
      "SELECT * FROM device_events where event_type IN(:connect, :disconnect) and device_id IN(:ids) and extract(epoch FROM time) >= :fromDate and extract(epoch FROM time) <= :toDate ORDER BY time",
      {
        replacements: {
          connect: "CONNECT",
          disconnect: "DISCONNECT",
          ids: deviceIds,
          fromDate: fromDate,
          toDate: toDate,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    //Response
    const response = {
      success: rawdata.length > 0 ? true : false,
      data: {
        code: 20,
        msg: rawdata.length > 0 ? "Records found" : "No records found",
        count: rawdata.length,
        results: rawdata,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
exports.addDevice = async (req, res) => {
  try {
    /*
    
    
    */

    //Get tenant DB and apps - mongo
    const tenantDb = req.metaInfo.mtenantDb;
    let appId = req.metaInfo.app;
    //tenantId = tenantDbName
    const tenantId = req.metaInfo.tDbName;
    if (!tenantDb || !appId) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get Request object

    //Generate DeviceId
    const deviceId = req.body.macAddress;
    const deviceColl = "device";
    const devicePColl = "device.profile";
    const mfrModel = "mfr.model";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    //Device Profile Model
    const DeviceProfileModel = await DeviceProfile.model(tenantDb, devicePColl);
    //Device Manufacturer Model
    const DeviceMfrModel = await DeviceMfr.model(tenantDb, mfrModel);
    //Master DB Connection
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get Device Model - master db
    const MDeviceModel = await MDevice.model(masterDbConn, deviceColl);
    //Device Profile Model - master db
    const MDeviceProfileModel = await DeviceProfile.model(
      masterDbConn,
      devicePColl
    );
    //Device Manufacturer Model - master db
    const MDeviceMfrModel = await DeviceMfr.model(masterDbConn, mfrModel);

    //Get Configuration url Model - master db
    const MConfigUrlModel = await MConfigUrl.model(
      masterDbConn,
      "configuration.urls"
    );

    //Check if device ID exists - in tenant DB
    const deviceCheck = await DeviceModel.findOne({
      $or: [
        {
          deviceId: deviceId,
        },
        {
          macAddress: req.body.macAddress,
        },
      ],
    });
    //Check if device ID exists - in master DB
    const mDeviceCheck = await MDeviceModel.findOne({
      $or: [
        {
          deviceId: deviceId,
        },
        {
          macAddress: req.body.macAddress,
        },
      ],
    });
    if (deviceCheck || mDeviceCheck) {
      //App does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "`Device ID or Mac Address` already exists !",
        },
      });
    }
    /*

    !Note: 
    Here we are only accepting LORA Devices
  
    */
    macAddress = req.body.macAddress;
    deviceName = req.body.name;

    //Get Data transform functions
    dataTransformers = req.body.dataTransformers;
    let mfrId = null;
    let gateway = null;
    //Custom device/gateway
    if (req.body.existing === false) {
      //To store it in separate documents
      let profiles = [];
      //If it is device
      if (req.body.gateway === true) {
        //Array of data transformers
        dataTransformers.map((obj) => {
          profiles.push({
            for: obj.for,
            fnCode: `${obj.fnCode} processedData = myFun(rawData)`,
            dataSchema: obj.schema,
          });
        });
      } else {
        //One transformer object only
        profiles.push({
          for: dataTransformers.for,
          fnCode: `${dataTransformers.fnCode} processedData = myFun(rawData)`,
          dataSchema: dataTransformers.schema,
        });
      }

      //Insert new device profiles
      const newDeviceProfiles = await DeviceProfileModel.insertMany(profiles);
      if (newDeviceProfiles.length > 0) {
        let deviceProfiles = {};

        newDeviceProfiles.map((obj) => {
          deviceProfiles[obj.for] = obj._id;
        });

        //Create Device MFR Model
        const mfrObj = {
          name: req.body.manufacturer,
          model: req.body.model,
          gateway: req.body.gateway,
          helperFn: req.body.helperFn,
          protocolType: req.body.protocolType,
          deviceProfiles,
        };
        //Save to Tenant db
        const newMfr = new DeviceMfrModel(mfrObj);
        //Get mfrId
        savedMfr = await newMfr.save();
        mfrId = savedMfr._id;
        gateway = savedMfr.gateway;
      }
    }
    //Existing device/gateway
    if (req.body.existing === true) {
      //Get manufacturerId from request
      const givenMfrId = req.body.manufacturerId;
      const mfrCheck = await DeviceMfrModel.findById(givenMfrId);
      if (!mfrCheck) {
        //Manufacturer does not exists
        return res.status(404).json({
          success: false,
          error: {
            code: 44,
            msg: "Manufacturer does not exists!",
          },
        });
      }
      mfrId = mfrCheck._id;
      gateway = mfrCheck.gateway;
    }

    //If Manufacturer is not set
    if (!mfrId) {
      //Something went wrong
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Something went wrong!",
        },
      });
    }
    //Unique API Key Generator
    const uniqueKeyB64 = randomize("Aa0", 32);
    //const uniqueKeyB64 = btoa(uniqueKey);
    //Save Device now and attach the "mfrId, gateway" obtained from last step
    const deviceObj = {
      deviceId: deviceId,
      app: appId,
      name: req.body.name,
      macAddress: req.body.macAddress,
      lat: req.body.lat,
      lng: req.body.lng,
      address: req.body.address,
      gateway,
      mfrId,
      addedBy: appId,
      protocolType: req.body.protocolType,
      protocolInfo: req.body.protocolInfo,
      uniqueKeyB64,
    };
    //Create object and save device
    const newDevice = new DeviceModel(deviceObj);
    await newDevice.save();

    //Save the device copy in Master db device collection
    const mDeviceObj = {
      //tenantDbName = tenantId
      tenantId,
      deviceId,
      app: appId,
      gateway,
      mfrId,
      name: req.body.name,
      macAddress: req.body.macAddress,
      protocolType: req.body.protocolType,
      uniqueKeyB64,
    };

    //Create object and save device - in master db
    const mDevice = new MDeviceModel(mDeviceObj);
    await mDevice.save();
    // try {
    //   //DB Logger
    //   const logged = await DbLogger(
    //     user,
    //     tenantId,
    //     req.metaObj.tenantDbName,
    //     req.metaObj.tenantName,
    //     logTypes.device.added,
    //     true,
    //     {
    //       deviceName: mDeviceObj.name,
    //       deviceId: mDeviceObj.deviceId,
    //       macAddress: mDeviceObj.macAddress,
    //       protocolType: mDeviceObj.protocolType,
    //       msg: "Device Added!",
    //     }
    //   );
    //   if (logged) {
    //     console.log("Data logged !");
    //   }
    // } catch (e) {
    //   console.log("Data could not logged !", e);
    // }
    //Format response
    let response = {
      success: true,
      data: {
        code: 21,
        msg: "Device Added !",
        results: {},
      },
    };
    //Send response
    return res.status(201).json(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
