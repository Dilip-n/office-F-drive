"use strict";
//Import Schema
const Schema = require("./Schema");
module.exports = (sequelize, DataTypes) => {
  const ruleSchema = Schema(DataTypes).Schema.Rule;
  const Rule = sequelize.define("rule", ruleSchema);
  Rule.associate = function (models) {
    // associations can be defined here
    Rule.belongsTo(models.device, {
      foreignKey: {
        name: "deviceId",
      },
      targetKey: "deviceId",
    });
  };
  return Rule;
};
