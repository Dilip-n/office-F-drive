"use strict";
//Import Axios
const Axios = require("axios");
//Import Joi
const Joi = require("@hapi/joi");
//Import Sequelize
const { Sequelize, Op, QueryTypes } = require("sequelize");
//Import PG Models
const DB = require("./../db/models/pg");
//Import Response Util
const Response = require("./../utils/response");
//Device Schema
const Schema = require("./../db/models/Schema");
//Import lodash
const _ = require("lodash");
//Import traverse
const Traverse = require("traverse");
const { func } = require("@hapi/joi");
//Auth Controller
module.exports = class DataHandler {
  constructor() {}

  //All Device
  static getAllDevices = async (ctx, next) => {
    let selectFields = [];
    //Get Device Schema
    const schemaObj = Schema().DeviceSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    // Find all Device
    try {
      // Device List
      const devices = await DB.device.findAll(
        {
          attributes: selectFields,
          include: [
            {
              attributes: [
                [DB.sequelize.literal(`data->'data'->'aqi'`), "aqi"],
                "time",
              ],
              model: DB.raw_data,
              as: "data",
              limit: 1,
              order: [["time", "desc"]],
            },
          ],
        },
        { raw: true }
      );

      if (devices.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: devices.map((device) => {
            return {
              ...device.dataValues,
              data: device.data.length > 0 ? device.data[0].dataValues : null,
            };
          }),
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //One Device
  static getOneDevices = async (ctx, next) => {
    const deviceId = ctx.params.deviceId;
    if (!deviceId) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    let selectFields = [];
    //Get Device Schema
    const schemaObj = Schema().DeviceSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    // Find one Device
    try {
      // Device List
      const device = await DB.device.findOne({
        attributes: selectFields,
        where: {
          deviceId,
        },
        include: [
          {
            attributes: [
              [DB.sequelize.literal(`data->'data'`), "data"],
              "time",
            ],
            model: DB.raw_data,
            as: "data",
            limit: 1,
            order: [["time", "desc"]],
          },
        ],
      });
      //Null formatter
      function nullValueFormatter(input) {
        for (const prop in input.data) {
          if (input.data[prop] === null) {
            input.data[prop] = "-";
          }
        }
        return input;
      }
      if (device) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: {
            ...device.dataValues,
            data:
              device.data.length > 0
                ? nullValueFormatter(device.data[0].dataValues)
                : null,
          },
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //All Sites
  static getAllSites = async (ctx, next) => {
    let selectFields = [];
    //Get Site Schema
    const schemaObj = Schema().SiteSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    // Find all sites
    try {
      // Site List
      const sites = await DB.site.findAll({
        attributes: selectFields,
      });

      if (sites.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: sites,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Get single Site devices
  static getSitesDevices = async (ctx, next) => {
    //Get site ID
    const siteId = ctx.params.siteId;
    let selectFields = [];

    //Get Device Schema
    const schemaObj = Schema().DeviceSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }

    try {
      let devices = [];
      // Site Check
      const siteCheck = await DB.site.findOne({
        raw: true,
        where: {
          siteId,
        },
      });
      if (siteCheck) {
        // Device List
        const deviceCheck = await DB.device.findAll({
          raw: true,
          attributes: selectFields,
          where: {
            site: siteId,
          },
        });
        if (deviceCheck.length > 0) {
          devices = [...deviceCheck];
        }
      }

      if (devices.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: devices,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Reports
  static getReports = async (ctx, next) => {
    //Get date range
    const fromDate = ctx.query.fromDate;
    const toDate = ctx.query.toDate;

    //Get report type
    const reportType = ctx.query.type;

    //All devices
    let devices = [];
    //Get device from query
    const device = ctx.query.deviceId;
    const site = ctx.query.siteId;
    try {
      // Reports
      //If device level report
      //Push this device to devices array
      if (device) {
        devices.push(device);
      }
      //If site level report
      if (!device && site) {
        // Site
        const siteCheck = await DB.site.findOne({
          raw: true,
          where: {
            siteId: site,
          },
        });
        if (siteCheck) {
          // Device List
          const deviceCheck = await DB.device.findAll({
            raw: true,
            attributes: ["deviceId"],
            where: {
              site,
            },
          });
          if (deviceCheck.length > 0) {
            deviceCheck.map((device) => devices.push(device.deviceId));
          }
        }
      }
      //If no devices
      if (devices.length == 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }

      let selectFields = [];
      let rawDataFields = [];
      //Final data and column
      let data = [];
      let columns = [];
      // Alert - Report
      if (reportType === "alert") {
        //If no field provided
        if (selectFields.length < 1) {
          //Get Alter Schema
          const schemaObj = Schema().AlertSchema;
          for (const property in schemaObj) {
            if (property != "data") selectFields.push(property);
          }
        }
        // Data
        const rawData = await DB.alert.findAll({
          where: {
            [Op.and]: [
              { deviceId: devices },
              Sequelize.where(
                Sequelize.literal("extract(epoch FROM time)"),
                ">=",
                fromDate
              ),
              Sequelize.where(
                Sequelize.literal("extract(epoch FROM time)"),
                "<=",
                toDate
              ),
            ],
          },
        });
        if (rawData.length > 0) {
          columns = [...selectFields, ...rawDataFields];
          //Format the response
          rawData.map((row) => {
            let oneSet = [];
            selectFields.map((column) => {
              oneSet.push(row[column]);
            });
            rawDataFields.map((col) => {
              oneSet.push(row["data"]["data"][col]);
            });
            data.push(oneSet);
          });
        }
      } else {
        //Raq data report type
        //If no field provided
        if (selectFields.length < 1) {
          //Get Data Schema
          const schemaObj = Schema().RawDataSchema;
          const rawDataDataSchema = Schema().RawDataData;
          // const finalSchemaObj = { ...schemaObj, ...rawDataDataSchema };
          for (const property in schemaObj) {
            if (property != "data") selectFields.push(property);
          }
          for (const property in rawDataDataSchema) {
            rawDataFields.push(property);
          }
        }
        // Data
        const rawData = await DB.raw_data.findAll({
          where: {
            [Op.and]: [
              { deviceId: devices },
              Sequelize.where(
                Sequelize.literal("extract(epoch FROM time)"),
                ">=",
                fromDate
              ),
              Sequelize.where(
                Sequelize.literal("extract(epoch FROM time)"),
                "<=",
                toDate
              ),
            ],
          },
        });

        if (rawData.length > 0) {
          columns = [...selectFields, ...rawDataFields];
          //Format the response
          rawData.map((row) => {
            let oneSet = [];
            selectFields.map((column) => {
              oneSet.push(row[column]);
            });
            rawDataFields.map((col) => {
              oneSet.push(row["data"]["data"][col]);
            });
            data.push(oneSet);
          });
        }
      }
      //Response
      if (data.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: {
            columns,
            data,
          },
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //All Units
  static getUnits = async (ctx, next) => {
    // Find all units
    try {
      // Units
      const units = await DB.unit.findAll({
        raw: true,
      });

      if (units.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: units,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get All report Schedules
  static getReportSchdls = async (ctx, next) => {
    try {
      // Report Schedules
      const rSchdls = await DB.report_schedules.findAll({
        raw: true,
        attributes: { exclude: ["device"] },
        include: [
          {
            model: DB.device,
            as: "deviceName",
            attributes: ["name"],
          },
          {
            model: DB.site,
            as: "siteName",
            attributes: ["name"],
          },
          {
            model: DB.user,
            as: "userName",
            attributes: ["name"],
          },
        ],
      });

      if (rSchdls.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: rSchdls.map((row) => {
            return {
              ...row,
              user: row["userName.name"],
              device: row["deviceName.name"],
              site: row["siteName.name"],
            };
          }),
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Add Report Schedules
  static AddReportSchdls = async (ctx, next) => {
    //Get Input
    const {
      name,
      frequency,
      format,
      site,
      device,
      lastSentAt,
    } = ctx.request.body;
    if (!name || !frequency || !format || !site || !device) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      //Get User
      const user = ctx.state.user;
      if (!user || !user.id) {
        return Response.unauthorized(ctx, {
          statusCode: 401,
          code: 41,
          msg: "Unauthorized",
        });
      }
      // Create a new report schedule
      const newRSchdl = await DB.report_schedules.create({
        name,
        frequency,
        format,
        site,
        device,
        user: user.id,
        lastSentAt,
      });
      return Response.created(ctx, {
        statusCode: 201,
        code: 20,
        msg: "Report Schedule Added!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Delete Report Schedules
  static deleteReportSchdls = async (ctx, next) => {
    //Get report schedule ID
    const id = ctx.params.id;
    if (!id) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Check if report schedules
      const checkRSchdl = await DB.report_schedules.findAll({
        where: {
          id,
        },
      });
      if (checkRSchdl.length == 1) {
        const deleteRSchdl = await DB.report_schedules.destroy({
          where: {
            id,
          },
        });
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Report Schedule Removed!",
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Report Schedule does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Graphs
  static getGraphs = async (ctx, next) => {
    //Get date range
    const fromDate = ctx.query.fromDate;
    const toDate = ctx.query.toDate;
    const interval = ctx.query.interval;
    //All devices
    let devices = [];
    //Get device from query
    const device = ctx.query.deviceId;
    const site = ctx.query.siteId;

    let selectFields = [];
    //Query field implementation
    const rawDataDataSchema = Schema().RawDataData;

    //If select fields is there
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in rawDataDataSchema) {
          let str = `avg(CAST(data->'data'->>'${tmpFields[
            i
          ].trim()}' AS FLOAT)) as ${tmpFields[i].trim()}`;
          selectFields.push(str);
        }
      }
      selectFields.toString();
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in rawDataDataSchema) {
        let str = `avg(CAST(data->'data'->>'${property}' AS FLOAT)) as ${property}`;
        selectFields.push(str);
      }
      selectFields.toString();
    }
    // return;
    try {
      //If device level report
      //Push this device to devices array
      if (device) {
        devices.push(device);
      }
      //If site level report
      if (!device && site) {
        let sites = [];
        // Site
        const siteCheck = await DB.site.findAll({
          raw: true,
          attributes: [["siteId", "id"], "parentId"],
        });
        //If sites exists
        if (siteCheck.length > 0) {
          //Nest function
          const nest = (
            items,
            id = site === "null" ? "" : site,
            link = "parentId"
          ) =>
            items
              .filter((item) => item[link] === id)
              .map((item) => ({ ...item, children: nest(items, item.id) }));
          //Get hierarchical sites
          const hierarchicalSites = nest(siteCheck);
          if (hierarchicalSites.length > 0) {
            //Traverse it to
            let leaves = Traverse(hierarchicalSites).reduce(function (acc, x) {
              if (this.isLeaf) acc.push(x);
              return acc;
            }, []);
            if (leaves.length > 0) {
              //Get unique leaves
              leaves = _.uniq(leaves);
              leaves.map((str) => {
                if (str.length > 1) {
                  sites.push(str);
                }
              });
            }
          } else {
            const onesiteCheck = await DB.site.findOne({
              raw: true,
              where: {
                siteId: site,
              },
            });
            if (onesiteCheck) {
              sites.push(site);
            }
          }
        }
        if (sites) {
          // Device List
          const deviceCheck = await DB.device.findAll({
            raw: true,
            attributes: ["deviceId"],
            where: {
              site: sites,
            },
          });
          if (deviceCheck.length > 0) {
            deviceCheck.map((device) => devices.push(device.deviceId));
          }
        }
      }
      //If no devices
      if (devices.length == 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
      // Reports
      //Query
      const graphData = await DB.sequelize.query(
        `SELECT time_bucket_gapfill(:interval, time) AS date, ${selectFields}
        FROM raw_data WHERE "deviceId" IN (:deviceIds) AND time >= :fromDate AND time <= :toDate GROUP BY date ORDER BY date DESC `,
        {
          replacements: { interval, deviceIds: devices, fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );
      if (graphData.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: graphData,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Add rules
  static AddRules = async (ctx, next) => {
    //Get Input
    const {
      name,
      deviceId,
      desc,
      dataPath,
      operator,
      value,
      severity,
      statement,
      incharge,
    } = ctx.request.body;
    
    // dataPath = dataPath.toLowerCase();
    // statement = statement.toLowerCase();


    try {
      // Add new rule
      const newRule = await DB.rule.create({
        name,
        deviceId,
        desc,
        dataPath : dataPath.toLowerCase(),
        operator,
        value,
        severity,
        statement : statement.toLowerCase(),
        incharge,
      });
      return Response.created(ctx, {
        code: 20,
        msg: "Rule Added!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get rules
  static getRules = async (ctx, next) => {
    try {
      // Get all the rules
      const rules = await DB.rule.findAll({
        raw: true,
        include: [
          {
            model: DB.device,
            attributes: ["name"],
          },
        ],
      });

      if (rules.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: rules,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      // console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Delete rules
  static deleteRules = async (ctx, next) => {
    const ruleId = ctx.params.ruleId;
    if (!ruleId) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Check if rule exists
      const checkRule = await DB.user.findAll({
        where: {
          id: ruleId,
        },
      });
      if (checkRule.length == 1) {
        const deleteRule = await DB.rule.destroy({
          where: {
            id: ruleId,
          },
        });
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Rule Removed!",
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Rule does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get alerts
  static getAlerts = async (ctx, next) => {
    try {
      //Get resolved true/false
      const resolved = ctx.query.resolved;
      let query = {};
      if (resolved == "true" || resolved == "false") {
        query.where = { resolved: JSON.parse(resolved) };
      }

      // Get all the alerts
      const alerts = await DB.alert.findAll({
        raw: true,
        ...query,
        attributes: { exclude: ["resolvedBy", "rule"] },
        include: [
          {
            model: DB.user,
            attributes: {
              exclude: ["isAdmin", "password", "createdAt", "updatedAt"],
            },
          },
          {
            model: DB.device,
            attributes: ["name"],
          },
          {
            model: DB.rule,
            as: "rules",
            attributes: ["name", "desc"],
          },
        ],
      });

      if (alerts.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: alerts,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Update Alert - mark as resolved
  static updateAlert = async (ctx, next) => {
    const alertId = ctx.params.alertId;
    const { desc } = ctx.request.body;
    if (!alertId) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Check if alert exists
      const checkAlert = await DB.alert.findOne({
        where: {
          id: alertId,
        },
      });
      if (checkAlert) {
        //Get logged in User
        const user = ctx.state.user;

        const updateAlert = await DB.alert.update(
          { resolvedAt: new Date(), resolved: true, resolvedBy: user.id, desc },
          {
            where: { id: alertId },
          }
        );
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Alert Details updated!",
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Alert does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get raw data schema
  static getRawDataSchema = async (ctx, next) => {
    try {
      //Get Raw data data Schema
      const schemaObj = Schema().RawDataData;
      const schema = [];
      //If not empty
      if (!_.isEmpty(schemaObj)) for (const key in schemaObj) schema.push(key);
      //Return
      if (schema) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: schema,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Get alerts - severity
  static getAlertsSeverity = async (ctx, next) => {
    try {
      //Query
      let alertGraphData = await DB.sequelize.query(
        `SELECT time_bucket_gapfill('1 Day', time) as date, COUNT(severity), severity
        FROM alerts where time >= now() - INTERVAL '1 week' AND time < now() GROUP BY date, severity`,
        {
          type: QueryTypes.SELECT,
        }
      );
      //New Array of dates and severity
      let newArray = [];

      alertGraphData.map((a) => {
        const found = newArray.some((b) => `${b.date}` == `${a.date}`);
        if (!found) {
          newArray.push({ date: a.date, s1: 0, s2: 0, s3: 0 });
        }
      });
      alertGraphData.map((a) => {
        if (a.severity === 1) {
          newArray.map((b) => {
            if (`${a.date}` == `${b.date}`) {
              b.s1 = +a.count;
            }
          });
        }
        if (a.severity === 2) {
          newArray.map((b) => {
            if (`${a.date}` == `${b.date}`) {
              b.s2 = +a.count;
            }
          });
        }
        if (a.severity === 3) {
          newArray.map((b) => {
            if (`${a.date}` == `${b.date}`) {
              b.s3 = +a.count;
            }
          });
        }
      });
      //Return
      if (newArray.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: newArray,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get Rule wise - alerts count
  static getRulesAlertsCount = async (ctx, next) => {
    try {
      // Get all the rules
      let rules = await DB.rule.findAll({
        raw: true,
        attributes: ["id", "name"],
      });
      let ruleIds;
      //New Array of rule vs alerts
      let newArray = [];
      //Format rules
      if (rules.length > 0) {
        ruleIds = rules.map((rule) => rule.id);

        //Query
        const rulesAlerts = await DB.sequelize.query(
          `SELECT COUNT(severity), severity, rule FROM alerts where rule IN(:rules) group by severity, rule`,
          {
            replacements: { rules: ruleIds },
            type: QueryTypes.SELECT,
          }
        );

        rulesAlerts.map(async (a) => {
          const found = newArray.some((b) => b.id === a.rule);
          if (!found) {
            const ruleName = rules.find((element) => element.id === a.rule);
            newArray.push({
              id: a.rule,
              value: 0,
              label: ruleName.name,
            });
          }
        });
        rulesAlerts.map((a) => {
          newArray.map((b) => {
            if (`${a.rule}` == `${b.id}`) {
              b.value += +a.count;
            }
          });
        });
      }
      //Return
      if (newArray.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: newArray,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Site Vs AQI
  static getSitesAqi = async (ctx, next) => {
    //Site
    const site = ctx.query.siteId;
    if (!site) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Site
      const siteCheck = await DB.site.findAll({
        raw: true,
        attributes: [["siteId", "id"], "parentId"],
      });
      //Get Leaves
      function getLeaves(arr) {
        //Traverse it to
        let leaves = Traverse(arr).reduce(function (acc, x) {
          if (this.isLeaf) acc.push(x);
          return acc;
        }, []);
        leaves = _.uniq(leaves);
        leaves = leaves.filter((str) => str.length > 1);
        return leaves;
      }
      let dataX = [];
      let dataY = [];
      //If sites exists
      if (siteCheck.length > 0) {
        //Nest function
        const nest = (
          items,
          id = site === "null" ? "" : site,
          link = "parentId"
        ) =>
          items
            .filter((item) => item[link] === id)
            .map((item) => ({ ...item, children: nest(items, item.id) }));
        //Get hierarchical sites
        const hierarchicalSites = nest(siteCheck);
        if (hierarchicalSites.length > 0) {
          for (let i = 0; i < hierarchicalSites.length; i++) {
            dataY = hierarchicalSites.map((row) => {
              //Get Childrens
              let children = getLeaves(row.children);
              return {
                top: row.id,
                children: children.length > 0 ? children : [row.id],
              };
            });
          }
        } else {
          dataY.push({
            top: site,
            children: [site],
          });
        }
        for (let j = 0; j < dataY.length; j++) {
          const topSite = await DB.site.findOne({
            raw: true,
            where: {
              siteId: dataY[j].top,
            },
          });

          const aqiData = await DB.sequelize.query(
            `select d2."deviceId", rd_data.data->'data'->>'aqi' as aqi from devices d2 join ( select distinct on ("deviceId") * from raw_data rd 
            order by "deviceId", "time" desc) as rd_data on 
            d2."deviceId" = rd_data."deviceId" and d2.site IN(:site)
          `,
            {
              replacements: { site: dataY[j].children },
              type: QueryTypes.SELECT,
            }
          );
          //Get AQI Avg
          const aqiAvg =
            aqiData.reduce((total, aqi) => total + +aqi.aqi, 0) /
              aqiData.length || 0;
          dataX.push({ ...topSite, aqiAvg });
        }
      }
      //If some record found
      if (dataX.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: dataX,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Single Site Vs AQI
  static getOneSitesAqi = async (ctx, next) => {
    //Site
    const site = ctx.params.siteId;
    try {
      let selectFields = [];
      //Query field implementation
      const rawDataDataSchema = Schema().RawDataData;

      //If select fields is there
      if (ctx.query && ctx.query.fields) {
        const fields = ctx.query.fields;
        let tmpFields = fields.split(",");
        for (let i = 0; i < tmpFields.length; i++) {
          if (tmpFields[i].trim() in rawDataDataSchema) {
            let str = `avg(CAST(data->'data'->>'${tmpFields[
              i
            ].trim()}' AS FLOAT)) as ${tmpFields[i].trim()}`;
            selectFields.push(str);
          }
        }
        selectFields.toString();
      }
      //If no field provided
      if (selectFields.length < 1) {
        for (const property in rawDataDataSchema) {
          let str = `rd_data.data->'data'->>'${property}' as ${property}`;
          selectFields.push(str);
        }
        selectFields.toString();
      }
      // Site
      const siteCheck = await DB.site.findAll({
        raw: true,
        attributes: [["siteId", "id"], "parentId"],
      });
      //Get Leaves
      function getLeaves(arr) {
        //Traverse it to
        let leaves = Traverse(arr).reduce(function (acc, x) {
          if (this.isLeaf) acc.push(x);
          return acc;
        }, []);
        leaves = _.uniq(leaves);
        leaves = leaves.filter((str) => str.length > 1);
        return leaves;
      }
      let dataX = [];
      let dataY = [];
      //If sites exists
      if (siteCheck.length > 0) {
        //Nest function
        const nest = (
          items,
          id = site === "null" ? "" : site,
          link = "parentId"
        ) =>
          items
            .filter((item) => item[link] === id)
            .map((item) => ({ ...item, children: nest(items, item.id) }));
        //Get hierarchical sites
        const hierarchicalSites = nest(siteCheck);
        if (hierarchicalSites.length > 0) {
          for (let i = 0; i < hierarchicalSites.length; i++) {
            dataY = hierarchicalSites.map((row) => {
              //Get Childrens
              let children = getLeaves(row.children);
              return {
                top: row.id,
                children: children.length > 0 ? children : [row.id],
              };
            });
          }
        } else {
          dataY.push({
            top: site,
            children: [site],
          });
        }
        for (let j = 0; j < dataY.length; j++) {
          const aqiData = await DB.sequelize.query(
            `select d2."deviceId", ${selectFields} from devices d2 join ( select distinct on ("deviceId") * from raw_data rd 
            order by "deviceId", "time" desc) as rd_data on 
            d2."deviceId" = rd_data."deviceId" and d2.site IN(:site)
          `,
            {
              replacements: { site: dataY[j].children },
              type: QueryTypes.SELECT,
            }
          );
          //
          if (aqiData.length > 0) {
            aqiData.map((oneRec) => {
              dataX.push(oneRec);
            });
          }
        }
      }
      //If some record found
      if (dataX.length > 0) {
        let dataZ = {};
        for (const property in rawDataDataSchema) {
          //Get Data Param Avg
          const data =
            dataX.reduce((total, aqi) => total + +aqi[property], 0) /
            dataX.length;
          dataZ[property] = data;
        }

        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: dataZ,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: {},
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
};
