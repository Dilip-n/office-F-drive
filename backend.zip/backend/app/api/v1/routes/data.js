"use strict";
//Import Koa Router
const Router = require("koa-router");
//Instantiate Router
const router = new Router();
//Import Controller
const Controller = require("./../controllers/data");
//Import Auth - Middleware
const Auth = require("./../middlewares/auth");

/*

! Data Routes

*/
//Get devices
router.get("/devices", Auth.jwtAuth, Controller.getAllDevices);

//Get one devices
router.get("/devices/:deviceId", Auth.jwtAuth, Controller.getOneDevices);

//Get sites
router.get("/sites", Auth.jwtAuth, Controller.getAllSites);

//Get sites - AQI
router.get("/sites-aqi", Auth.jwtAuth, Controller.getSitesAqi);

//Get sites - AQI
router.get("/sites-aqi/:siteId", Auth.jwtAuth, Controller.getOneSitesAqi);

//Get single site's devices
router.get("/sites/:siteId", Auth.jwtAuth, Controller.getSitesDevices);

//Get Reports -  Auth.jwtAuth
router.get("/reports", Controller.getReports);

//Get Units
router.get("/units", Auth.jwtAuth, Controller.getUnits);

//Get Report Schedules
router.get("/report-schdls", Auth.jwtAuth, Controller.getReportSchdls);

//Add Report Schedules
router.post("/report-schdls", Auth.jwtAuth, Controller.AddReportSchdls);

//Delete Report Schedules
router.delete(
  "/report-schdls/:id",
  Auth.jwtAuth,
  Controller.deleteReportSchdls
);

//Get Graphs -
router.get("/graphs", Auth.jwtAuth, Controller.getGraphs);

//Add rules
router.post("/rules", Auth.jwtAuth, Controller.AddRules);

//Get rules
router.get("/rules", Auth.jwtAuth, Controller.getRules);

//Delete rules
router.delete("/rules/:ruleId", Auth.jwtAuth, Controller.deleteRules);

//Get resolved/unresolved alerts
router.get("/alerts", Auth.jwtAuth, Controller.getAlerts);

//Mark alert as resolved
router.patch("/alerts/status/:alertId", Auth.jwtAuth, Controller.updateAlert);

//Get Raw Data Data Schema
router.get("/raw-data-shema", Auth.jwtAuth, Controller.getRawDataSchema);

//Get alert severity graph
router.get("/alert-severity", Auth.jwtAuth, Controller.getAlertsSeverity);

//Get alert count - grouped on ruleId
router.get("/rules-alerts", Auth.jwtAuth, Controller.getRulesAlertsCount);

//Export
module.exports = router;
