const getNotes = require('./notes.js')

const msg = getNotes()

console.log(msg)