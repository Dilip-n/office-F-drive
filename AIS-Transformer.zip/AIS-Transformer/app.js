function myFun(inputData) {
  const rawData = inputData.data;

  function getDate(date) {
    mm = date.slice(0, 2);
    dd = date.slice(2, 4);
    yyyy = date.slice(4, 8);
    return `${mm}-${dd}-${yyyy}`;
  }

  function getTime(time) {
    HH = time.slice(0, 2);
    MM = time.slice(2, 4);
    SS = time.slice(4, 6);
    return `${HH}: ${MM}: ${SS}`;
  }
  let data = {};
  let index = 0;

  let dataArray = rawData.split(",");

  let messageId = dataArray[index];

  if (messageId == "$LGN") {
    date = new Date();
    data.packetType = "login";
    data.ts = Math.floor(date.getTime() / 1000);
    data.data = {
      deviceName: dataArray[1],
      deviceId: dataArray[2],
      softwareVersion: dataArray[3],
      lat: parseFloat(dataArray[4]),
      latD: dataArray[5],
      lon: parseFloat(dataArray[6]),
      lonD: dataArray[7],
    };

    return data;
  } else if (messageId == "$HLM") {
    data.packetType = "Health Monitoring Packet";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);
    data.data = {
      packetType: "Health Monitoring Packet",
      vendorId: dataArray[1],
      deviceId: dataArray[3],
      softwareVersion: dataArray[2],
      batteryPercentage: parseInt(dataArray[4]),
      lowBatteryThreshold: parseInt(dataArray[5]),
      memoryPercentage: parseInt(dataArray[6]),
      dataUpdateRateIgnitionOn: parseInt(dataArray[7]),
      dataUpdateRateIgnitionOff: parseInt(dataArray[8]),
      digitalInputStatus: parseInt(dataArray[9]),
      analogInputStatus: parseInt(dataArray[10]),
      endCharacter: dataArray[11],
    };

    return data;
  }
  // Location Information Packet
  else if (messageId == "$NRM") {
    data.packetType = "Location Information Packet";
    date = new Date();

    data.ts = Math.floor(date.getTime() / 1000);
    data.data = {
      vendorId: dataArray[1],
      deviceId: dataArray[6],
      softwareVersion: dataArray[2],
      packetType1: dataArray[3],
      alertId: parseInt(dataArray[4]),
      packetStatus: dataArray[5],
      vehicleRegistrationNo: dataArray[7],
      gpsFix: dataArray[8],
      date: getDate(dataArray[9]),
      Time: getTime(dataArray[10]),
      lat: parseFloat(dataArray[11]).toFixed(6),
      latD: dataArray[12],
      long: parseFloat(dataArray[13]).toFixed(6),
      longD: dataArray[14],
      speed: parseFloat(dataArray[15]).toFixed(1),
      heading: parseFloat(dataArray[16]).toFixed(2),
      noOfSatellites: parseInt(dataArray[17]),
      altitude: parseFloat(dataArray[18]).toFixed(2),
      pdop: dataArray[19],
      hdop: dataArray[20],
      operatorName: dataArray[21],
      ignition: parseInt(dataArray[22]),
      mainPowerStatus: parseInt(dataArray[23]),
      mainInputVoltage: parseFloat(dataArray[24]).toFixed(2),
      internalBatteryVoltage: parseFloat(dataArray[25]).toFixed(1),
      emergencyStatus: parseInt(dataArray[26]),
      temperAlert: dataArray[27],
      gSMStrength: parseInt(dataArray[28]),
      mcc: parseInt(dataArray[29]),
      mnc: parseInt(dataArray[30]),
      lac: dataArray[31],
      cellId: dataArray[32],
      nmr: dataArray[33],
      digitalInputStatus: parseInt(dataArray[34]),
      digitalOutputStatus: parseInt(dataArray[35]),
      analogInput1: parseFloat(dataArray[36]),
      analogInput2: parseFloat(dataArray[37]),
      frameNumber: parseInt(dataArray[38]),
      odometer: parseFloat(dataArray[39]),
      miscField1: dataArray[40],
      miscField2: dataArray[41],
      miscField3: dataArray[42],
      miscField4: dataArray[43],
      debugInformation: dataArray[44],
      Checksum: dataArray[45],
      debugInformation: dataArray[44],
      endCharacter: dataArray[45],
    };

    return data;
  }
  // Alert Information
  else if (messageId == "$ALT") {
    data.packetType = "Alert Information Packet ";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);
    data.data = {
      vendorId: dataArray[1],
      deviceId: dataArray[6],
      softwareVersion: dataArray[2],
      packetType: dataArray[3],
      alertID: dataArray[4],
      packetStatus: dataArray[5],
      vehicleRegistrationNo: dataArray[6],
      gpsFix: parseInt(dataArray[7]),
      date: getDate(dataArray[8]),
      time: getTime(dataArray[9]),
      lat: parseFloat(dataArray[10]).toFixed(6),
      latD: dataArray[11],
      lon: parseFloat(dataArray[12]).toFixed(6),
      longitudeD: dataArray[13],
      Speed: parseFloat(dataArray[14]).toFixed(1),
      heading: parseFloat(dataArray[15]).toFixed(2),
      noOfSatellites: parseInt(dataArray[16]),
      altitude: parseFloat(dataArray[17]).toFixed(1),
      pdop: parseInt(dataArray[18]),
      hdop: parseInt(dataArray[19]),
      operatorName: dataArray[20],
      ignition: parseInt(dataArray[21]),
      mainPowerStatus: parseInt(dataArray[22]),
      mainInputVoltage: parseFloat(dataArray[23]).toFixed(1),
      internalBatteryVoltage: parseFloat(dataArray[24]).toFixed(1),
      emergencyStatus: parseInt(dataArray[25]),
      temperAlert: dataArray[26],
      gsmStrength: parseInt(dataArray[27]),
      mcc: parseInt(dataArray[28]),
      mnc: parseInt(dataArray[29]),
      lac: parseInt(dataArray[30]),
      cellId: dataArray[31],
      nmr: dataArray[32],
      digitalInputStatus: parseInt(dataArray[33]),
      digitalOutputStatus: parseInt(dataArray[34]),
      analogInputpacket1: parseInt(dataArray[35]),
      analogInput2: parseInt(dataArray[36]),
      frameNumber: parseInt(dataArray[37]),
      odometer: parseFloat(dataArray[38]).toFixed(3),
      miscField1: dataArray[39],
      miscField2: dataArray[40],
      miscField3: dataArray[41],
      miscField4: dataArray[42],
      debugInformation: parseInt(dataArray[43]),
      Checksum: dataArray[44],
      endCharacter: dataArray[45],
    };

    return data;
  }
  //Emergency Packe
  else if (messageId == "$EPB") {
    data.packetType = "Emergency Packet";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);
    data.data = {
      packetType: dataArray[1],
      deviceId: dataArray[2],
      packetStatus: dataArray[3],
      date: getDate(dataArray[4]),
      time: getTime(dataArray[5]),
      gpsFix: dataArray[6],
      lat: parseFloat(dataArray[7]).toFixed(6),
      latD: dataArray[8],
      long: parseFloat(dataArray[9]).toFixed(6),
      longD: dataArray[10],
      altitude: parseFloat(dataArray[11]).toFixed(6),
      speed: parseFloat(dataArray[12]).toFixed(1),
      distance: parseFloat(dataArray[13]),
      provider: dataArray[14],
      vehicleRegistrationNo: dataArray[15],
      replyNumber: parseInt(dataArray[16]),
      mcc: parseInt(dataArray[17]),
      mnc: parseInt(dataArray[18]),
      lac: parseInt(dataArray[19]),
      cellId: dataArray[20],
      endCharacter: dataArray[21],
      checksum: dataArray[22],
    };

    return data;
  }

  //OTA ACK Packet
  else if (messageId == "$EPB") {
    data.packetType = "Emergency Packet";
    date = new Date();
    data.ts = Math.floor(date.getTime() / 1000);
    data.data = {
      packetType: dataArray[1],
      deviceId: dataArray[2],
      packetStatus: dataArray[3],
      date: getDate(dataArray[4]),
      time: getTime(dataArray[5]),
      gpsFix: dataArray[6],
      lat: parseFloat(dataArray[7]).toFixed(6),
      latD: dataArray[8],
      long: parseFloat(dataArray[9]).toFixed(6),
      longD: dataArray[10],
      altitude: parseFloat(dataArray[11]).toFixed(6),
      speed: parseFloat(dataArray[12]).toFixed(1),
      distance: parseFloat(dataArray[13]),
      provider: dataArray[14],
      vehicleRegistrationNo: dataArray[15],
      replyNumber: parseInt(dataArray[16]),
      mcc: parseInt(dataArray[17]),
      mnc: parseInt(dataArray[18]),
      lac: parseInt(dataArray[19]),
      cellId: dataArray[20],
      endCharacter: dataArray[21],
      checksum: dataArray[22],
    };

    return data;
  }
}

//Login message Packet

// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "$LGN,abc,58508A880522E0207,3.2AIS,12.36,N,12.36,E",
//   })
// );

//Health Monitoring Packet

// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "$HLM,123,3.2AIS,58508A880522E0207,100,20,0,60,60,0000,00,*",
//   })
// );

//Location Information Packet

// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "$NRM,123,3.2AIS,NR,123,L,58508A880522E0207,XX12XX1234,1,01012019,000000,123,N,123,E,25.1,123.45,10,123.4,123,1232,Airtel,1,1,12.4,4.2,0,C,31,404,98,XXXX,123,4times,0000,00,123,123,000005,123.456,0,0,0,0,0,ABCDABCD,*",
//   })
// );

//Alert Information Packet

// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "$ALT,,3.2AIS,OS,,L,58508A880522E0207,XX12XX1234,1,01012019,000000,,N,,E,25.1,123.45,10,123.4,,,Airtel,1,1,12.4,4.2,0,C,31,404,98,XXXX,4 times,0000,00,,,000005,123.123,,,,,0,ABCDABCD,*",
//   })
// );

//Emergency Packet
// console.log(
//   myFun({
//     cmd: "rx",
//     EUI: "58508A880522E0207",
//     data: "$EPB,EMR,58508A880522E0207,NP,01012019,000000,A,,N,,E,123.4,25.1,,G,XX12XX1234,0,404,98,XXXX,XXXX,*,ABCDABCD",
//   })
// );
