const MenuItems = [
  {
    title: "Home",
    url: "#",
    cName: "nav-links",
  },
  {
    title: "Services",
    url: "#",
    cName: "nav-links",
  },
  {
    title: "Products",
    url: "#",
    cName: "nav-links",
  },
  {
    title: "Contact-Us",
    url: "#",
    cName: "nav-links",
  },
  {
    title: "Sign-Up",
    url: "#",
    cName: "nav-links-mobile",
  },
];
