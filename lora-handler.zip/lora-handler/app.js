//Import Axios
const Axios = require("axios");
//Import Settings
const {
  deviceAPI,
  kafkaPublishTopic,
  loraServer,
  loraServerAuthToken,
  loraServerAppId,
} = require("./config/adaptor");
//Import LokiJs
const Loki = require("lokijs");
//Import Utility functions
const UtilClass = require("./utils");
const Utils = new UtilClass();
//Import Kafka
const { kafkaProducer, kafkaConsumer } = require("./utils/kafka");
//Creating the local db:
const db = new Loki("lora_handler_db_local");
// Add a collection to the database
const lokiDevices = db.addCollection("devices");

module.exports = class APIHandler {
  //Get Lora Device data
  static loraHandler = async (ctx, next) => {
    //Get request body
    const input = ctx.request.body;
    if (input.cmd == "rx" && input.EUI) {
      console.log(input);
      try {
        //Validate Device
        const response = await Utils.main(input, lokiDevices);
        console.log("response", response);
        //Get Device details
        const deviceDetails = response.deviceDetails;
        console.log(deviceDetails.deviceId, input.data);
        //Preapre kafka message
        let kafkaMessages = {
          protocol: deviceDetails.protocolType,
          deviceId: deviceDetails.deviceId,
          tenantId: deviceDetails.tenantId,
          appId: deviceDetails.appId,
          dataFrom: deviceDetails.deviceId,
          ingestTimestamp: new Date().getTime(),
          rawData: input.data,
          mfr: deviceDetails.mfrId,
          //packetSize: input.data.length,
          packetSize: 0,
        };
        // convert JSON object to String
        let jsonKStr = JSON.stringify(kafkaMessages);
        //Pass the data to transformer
        const kafka_data = {
          topic: kafkaPublishTopic,
          messages: jsonKStr,
        };
        //console.log(kafka_data);
        kafkaProducer([kafka_data]);
        //Response
        ctx.status = 200;
        ctx.body = { success: true };
        return ctx.body;
      } catch (err) {
        console.log(err);
      }
    } else {
      //console.log("Skipping____", input);
      //Response
      ctx.status = 200;
      ctx.body = {
        success: true,
        msg: "Skipped and not included for transformation!",
      };
      return ctx.body;
    }
  };
};
//Consumer
kafkaConsumer.on("message", async function (payload) {
  const input = JSON.parse(payload.value);
  console.log(input);
  // Check if the device is present in Loki
  const deviceInLoki = lokiDevices.findOne({ deviceId: input.deviceId });
  if (!deviceInLoki) {
    console.error(
      `Sending command to ${input.deviceId} failed, device not connected`
    );
    return;
  }
  /*

  */
  // Buzzer On/Off
  let cmdStr = "";
  if (input.payload.type === "buzzer") cmdStr = "8101";
  //Preapre command request body
  const requestBody = {
    cmd: "tx",
    EUI: input.deviceId,
    port: deviceInLoki.devicePort,
    appid: loraServerAppId,
    data: `${cmdStr}${input.payload.cmd}`,
    confirmed: true,
  };
  try {
    //Validate Device
    const response = await Axios({
      method: "POST",
      url: `${loraServer}1/rest`,
      headers: {
        Authorization: `Bearer ${loraServerAuthToken}`,
      },
      data: requestBody,
    });
    console.log(response.data);
    //Response
    console.log(`Command Sent to ${input.deviceId}!`, response.data);
  } catch (err) {
    console.log(
      `Command Seding to ${input.deviceId} failed!`,
      err.response.data
    );
  }
});
