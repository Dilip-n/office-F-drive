//Import Axios
const Axios = require("axios");
//Import Configs
const { deviceAPI } = require("../config/adaptor");

//All Utils
class Utils {
  getDeviceDetails(macAddress) {
    let url = `${deviceAPI}${macAddress}`;
    return new Promise(function (resolve, reject) {
      Axios.get(url, {
        headers: {
          authorization:
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIxNjksIm9yZ0lkIjoiSFQyMDIwMDIwMSIsInVzZXJFbWFpbCI6Imh0MjAyMDAyMDFAb2l6b20uY29tIiwiaWF0IjoxNjQyNDQ1MTk5LCJleHAiOjE2NzM5ODExOTksImlzcyI6Ik9NTlRLVXdXbGIzdFhUVTY3Qlo3ZHllekJpNzlHYnBQIn0.TH7IIaZKV3N2MbMqpE2NwKosbbazCjRONNiz7bzAO1s",
        },
      }).then(
        (res) => {
          if (res.data.data.code == 20) {
            let response = res.data.data.results;
            resolve(response);
          } else {
            reject("Device api response parse error");
          }
        },
        (err) => {
          console.log("Error: ", err.data);

          reject("Device API fetch error!");
        }
      );
    });
  }
  main(data, devicesCol) {
    let macAddress = data.EUI;
    console.log("macAddress", macAddress);
    //Find this device in Loki
    let deviceInLoki = devicesCol.findOne({ macAddress });

    //Get Device Details
    return this.getDeviceDetails(macAddress).then(
      function (deviceDetails) {
        if (deviceDetails) {
          const dDetails = {
            deviceAddress: macAddress,
            macAddress: deviceDetails.macAddress,
            deviceId: deviceDetails.deviceId,
            tenantId: deviceDetails.tenantId,
            appId: deviceDetails.app,
            mfrId: deviceDetails.mfrId,
            devicePort: data.port,
            uniqueKey: deviceDetails.uniqueKeyB64,
          };
          if (deviceInLoki) {
            //console.log(deviceInLoki);
            //Update existing
            //devicesCol.update(dDetails);
            return { deviceDetails: dDetails };
          } else {
            //insert into  db
            devicesCol.insert(dDetails);
            console.info(`Cached ${dDetails.deviceId}!`);
            return { deviceDetails: dDetails };
          }
        } else {
          console.info(`DeviceId:${deviceId} not found`);
        }
      },
      function (err) {
        console.error(err);
      }
    );
  }
}
module.exports = Utils;
