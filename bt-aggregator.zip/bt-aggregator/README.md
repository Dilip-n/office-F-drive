## To run in docker

```
docker run --restart=always \
-d \
--name bt-data-handler \
-eBT_HANDLER_PORT=7002 \
-eBT_HANDLER_IOTPF_API=http://10.218.218.2:17024/api/v1/rest-api-handler \
-eBT_HANDLER_TIMEZONE=Asia/Kolkata \

registry.gitlab.com/hyperthingsiot/iot-platform/applications/bin-tracking/bt-aggregator
```

## Environment variables

| Parameter | Application specific | default                                             |
| --------- | -------------------- | --------------------------------------------------- |
| port      | BT_HANDLER_PORT      | 7002                                                |
| iotpfAPI  | BT_HANDLER_IOTPF_API | `http://10.218.218.2:17024/api/v1/rest-api-handler` |
| timezone  | BT_HANDLER_TIMEZONE  | Asia/Kolkata                                        |
|           |
