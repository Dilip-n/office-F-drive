//TCP ================================================================
const net = require('net');
const tcpClient = new net.Socket();

// const config = require('../config');

let count = 0;
const port = 7002;
// 7062; // config.tcpServerPort;
const host = 'localhost';
// '183.82.119.101'; //config.ServerHost;

tcpClient
    .connect(port, host, function () {
        console.log('TCP Client Connected');
    })
    .on('error', (err) => {
        if (err.errno === 'ECONNREFUSED') {
            console.log('Connection refused from TCP Data Handler server');
            tcpClient.on('close', function () {
                console.log('TCP Connection closed');
            });
        }
        if (err.errno === 'ECONNRESET') {
            console.log('Connection reset from TCP Data Handler server');
            tcpClient.connect(port, host, function () {
                console.log('TCP Client Connected');
            });
        }
    })
    .on('data', function (data) {
        console.log('Received: ' + data);
    });

//Defining Feedback Values
const packets = [
    `$HLM,123,3.2AIS,58508A880522E0207,100,20,0,60,60,0000,00,*`,
    `$NRM,123,3.2AIS,NR,123,L,58508A880522E0207,XX12XX1234,1,01012019,000000,123,N,123,E,25.1,123.45,10,123.4,123,1232,Airtel,1,1,12.4,4.2,0,C,31,404,98,XXXX,123,4 times,0000,00,123,123,000005,123.456,0,0,0,0,0,ABCDABCD,*`,
    `$ALT,,3.2AIS,OS,,L,58508A880522E0207,XX12XX1234,1,01012019,000000,,N,,E,25.1,123.45,10,123.4,,,Airtel,1,1,12.4,4.2,0,C,31,404,98,XXXX,4 times,0000,00,,,000005,123.123,,,,,,ABCDABCD,*`,
    `$EPB,EMR,58508A880522E0207,NP,01012019,000000,A,,N,,E123.4,25.1,,G,XX12XX1234,0,404,98,XXXX,XXXX,*,ABCDABCD`,
    `HCHKR,123456,,3.2AIS,58508A880522E0207,1,12.345678,N,123.456789,E,1,DDMMYYYY HHMMSS,123.45,12.3,12,404,4,XXXX,1,1,12.3,000001,0`,
];

// console.log(packets[0]);

//Getting Random Feedback's
function getRandom() {
    function randomInRange(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }
    const rndInt = randomInRange(0, packets.length - 1);
    return packets[rndInt];
}
// console.log(getRandom());
setInterval(function () {
    // Get some random device
    let currentDevice = '419470116217270';

    let json;
    if (count == 0) {
        json = `$LGN,abc,58508A880522E0207,3.2AIS,12.36,N,12.36,E`;
        count++;
    } else {
        //console.log("sending main message....")
        json = getRandom();
        count++;
    }
    // Send data to TCP server
    tcpClient.write(json);
    console.log(`TCP data published ${count}: ${json}`);
}, 5000);
