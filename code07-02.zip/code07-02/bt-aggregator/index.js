const config = require("./config");
const fetch = require("node-fetch");
const http = require("http");
const { DateTime } = require("luxon");
const logger = require("pino-http")({
  redact: ["req.headers", "req.headers.authorization"],
  name: "BT-Aggregator",
});

const hostname = "0.0.0.0";
const tenant = "5e99a9031421ff001996cfe4";
const port = config.port;

const server = http.createServer(async (req, res) => {
  let data = "";
  req.on("data", (chunk) => {
    data += chunk;
    logger(req, res);
    req.log.info({ tenant, data }, "raw packet recived");
    console.log("Raw Packet ->", decodeURIComponent(data));
  });
  req.on("end", () => {
    try {
      data = decodeURIComponent(data);

      let [
        time_sno,
        bfp,
        ,
        ,
        bp,
        gld,
        ,
        poi,
        tbh,
        ufl,
        lfl,
        tsai,
        ltt,
        lgt,
        temp,
        ts,
        hbi,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        ,
      ] = data.split("=")[1].split(";");
      let [timestamp, sno] = time_sno.split("$");
      const decoded = decodeURIComponent(timestamp).split(" ");
      timestamp = DateTime.fromFormat(
        `${decoded[0]} ${decoded[1]} ${config.timezone}`,
        "yyyyLLdd HHmmss z"
      );

      const parsedData = {
        deviceId: sno,
        ts: timestamp.toSeconds(),
        fill: parseFloat(bfp),
        battery: 100,
        bp: 1024,
        gld: parseFloat(gld),
        poi: parseFloat(poi),
        tbh: parseFloat(tbh),
        ufl: parseFloat(ufl),
        lfl: parseFloat(lfl),
        alert: parseFloat(tsai),
        lat: parseFloat(ltt),
        lng: parseFloat(lgt),
        temp: parseFloat(temp),
        tamper: parseFloat(ts),
        hbi: parseFloat(hbi),
        raw: data,
      };
      if (parsedData.fill > 100) {
        parsedData.fill = 100;
      } else {
        parsedData.fill;
      }
      // Saving Tranform data to DB
      fetch(config.iotpfAPI, {
        method: "POST",
        body: JSON.stringify(parsedData),
        headers: {
          "Content-Type": "application/json",
        },
      }).then((res) => res.json()); // expecting a json response
      logger(req, res);
      req.log.info({ tenant, parsedData }, "passing the Input");
    } catch (error) {
      console.log(error);
      logger(req, res);
      req.log.info("Invalid");
      res.statusCode = 400;
      res.setHeader("Content-Type", "text/plain");
      res.end("Invalid");
    }
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
