module.exports = {
  port: process.env.BT_HANDLER_PORT || 7006,
  iotpfAPI:
    process.env.BT_HANDLER_IOTPF_API ||
    "http://10.67.170.253:7004/api/v1/data/push-raw-data",
  timezone: process.env.BT_HANDLER_TIMEZONE || "Asia/Kolkata",
  trinityAPI:
    process.env.BT_HANDLER_TRINITY_API ||
    "http://103.116.27.151:6465/HTTPProtAdaptorService",
  trinityAuth:
    process.env.BT_HANDLER_TRINITY_AUTH ||
    "Basic dHJpbml0eS1jbGllbnQ6dHJpbml0eS1zZWNyZXQ=",
  trinityUsername: process.env.BT_HANDLER_TRINITY_USERNAME || "trinity",
  trinityPassword: process.env.BT_HANDLER_TRINITY_PASSWORD || "trinity@123",

  trinityMQTTTopic: process.env.BT_TRINITY_MQTT_TOPIC || "trinitySWM",
  trinityMQTTHOST:
    process.env.BT_TRINITY_MQTT_HOST || "mqtt://test.mosquitto.org",
};
