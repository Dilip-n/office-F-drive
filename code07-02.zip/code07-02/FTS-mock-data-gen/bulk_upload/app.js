// raw_data Table

"use strict";

// Import Config
const config = require("./config");
// Import PostgreSQL
const { Pool } = require("pg");
//Import CSV Parser
const parse = require("csv-parser");
//Import fs
const fs = require("fs");
// Import Node-Cron
const cron = require("node-cron");
//Import Pg format
const pgFormat = require("pg-format");
//Import Moment
const Moment = require("moment");
// const jsonData = require(config.filePath);

(async () => {
  const pool = new Pool({
    host: config.dbHost,
    user: config.dbUser,
    password: config.dbPassword,
    database: config.dbName,
    port: config.dbPort,
  });
  try {
    await pool.connect();
    console.log("Database connected!");
  } catch (err) {
    console.log("DB Conn error:", err);
  }

  const mockData = async (deviceId, filePath) => {
    try {
      // cron.schedule("*/" + config.dbInterval + " * * * *", () => {
      // Fetching CSV Data
      // let csvData = [];
      filePath = "./" + filePath;
      const jsonData = require(filePath);
      const coordinatesArray = jsonData["coordinates"][0];
      let newDataArray = [];
      for (let i = 0; i < coordinatesArray.length; i++) {
        let packetType = "nr";
        let newDate1 = Moment().tz("GMT").format("YYYY-MM-DDTHH:mm:ss");
        // subtract time
        let subTractInterval = parseInt(config.dbInterval) * i;
        let startDate = Moment(newDate1)
          .subtract(subTractInterval, "seconds")
          .format("YYYY-MM-DDTHH:mm:ss");

        let startTime = startDate.slice(11, 19);

        if (i === 20 || i === 40 || i === 60 || i === 80) packetType = "hb";

        let updData = {
          ts: Moment(startDate).unix(),
          data: {
            gf: "3D",
            a01: 48,
            lac: null,
            lat: parseFloat(coordinatesArray[i][1]),
            lon: parseFloat(coordinatesArray[i][0]),
            nfs: 9,
            pgn: null,
            sig: 13,
            spd: 0.001,
            tas: null,
            date: startDate,
            di01: null,
            di02: null,
            di03: null,
            di04: null,
            di05: null,
            di06: null,
            do01: null,
            do02: null,
            fspd: null,
            hdop: 0.72,
            imei: deviceId,
            ispd: null,
            latD: "N",
            lonD: "E",
            pdop: 1.1,
            rfid: null,
            stat: 1010,
            temp: 32,
            time: startTime,
            vdop: 0.69,
            engOn: 1,
            seqNo: null,
            Others: {
              lac: null,
              mcc: null,
              mnc: null,
              firstNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
              thirdNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
              fourthNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
              secondNeighbour: {
                lac: null,
                cellId: null,
                gsmStrength: null,
              },
            },
            batCur: 50,
            batPer: 40,
            cellId: null,
            gpsAvi: 1,
            digInp1: 0,
            mileage: 2265,
            roamAct: 0,
            datafrom: "gps",
            distance: null,
            duration: null,
            direction: 65,
            packetType: packetType,
            packetStatus: "h",
          },
          deviceId: deviceId,
          deviceType: null,
        };
        newDataArray.push([
          startDate,
          config.dbSize,
          deviceId,
          updData,
          deviceId,
          startDate,
        ]);
      }
      return newDataArray;
    } catch (err) {
      console.log("Error: ", err);
    }
  };

  const insertMockData = async (deviceId, filePath) => {
    try {
      let data = [];
      console.log(filePath);
      data = await mockData(deviceId, filePath);
      // console.log(data);
      if (data.length > 0) {
        //Bulk Insert
        const query = pgFormat(
          'INSERT INTO raw_data("time", "size", "deviceId", "data", "dataFrom", "ingestTime") VALUES %L',
          data
        );
        pool.query(query, (err, res) => {
          if (err) {
            console.log("Error: ", err.stack);
          } else {
            console.log(`${res.rowCount} Data inserted`);
          }
        });
      } else {
        console.log("No data");
      }
    } catch (error) {
      console.log("Error: ", err);
    }
  };

  const deviceIds = config.dbDeviceId;
  const filePaths = config.filePath;

  for (let i = 0; i < deviceIds.length; i++) {
    await insertMockData(deviceIds[i], filePaths[i]);
  }
})();
