// raw_data Table

"use strict";

// Import Config
const config = require("./config");
// Import PostgreSQL
const { Pool } = require("pg");
//Import CSV Parser
const parse = require("csv-parser");
//Import fs
const fs = require("fs");
// Import Node-Cron
const cron = require("node-cron");
//Import Pg format
const pgFormat = require("pg-format");
//Import Moment
const Moment = require("moment");
// const hToE = require("./routes/australia.json");
const hToE = require("./routes/btoc.json");

(async () => {
  const pool = new Pool({
    host: config.dbHost,
    user: config.dbUser,
    password: config.dbPassword,
    database: config.dbName,
    port: config.dbPort,
  });
  try {
    await pool.connect();
    console.log("Database connected!");
  } catch (err) {
    console.log("DB Conn error:", err);
  }

  const mockDatad1 = async () => {
    try {
      let i = 0;
      let packetType = "nr";
      cron.schedule("* * * * *", () => {
        let Array = [];
        if (i < hToE.coordinates[0].length) {
          // let newDate = Moment().format("YYYY-MM-DDTHH:mm:ss");
          let today = Moment().format("YYYY-MM-DDTHH:mm:ss");

          if (i == 21 || i == 41 || i == 61 || i == 71) {
            packetType = "hb";
          }

          let updData = {
            ts: Moment(today).unix(),
            data: {
              gf: "3D",
              a01: 48,
              lac: null,
              lat: hToE.coordinates[0][i][1],
              lon: hToE.coordinates[0][i][0],
              nfs: 9,
              pgn: null,
              sig: 13,
              spd: 1.36,
              //   csvData[i].Speed,
              tas: null,
              date: today,
              di01: null,
              di02: null,
              di03: null,
              di04: null,
              di05: null,
              di06: null,
              do01: null,
              do02: null,
              fspd: null,
              hdop: 0.76,
              //   parseFloat(csvData[i].HDOP),
              imei: config.dbDeviceId[0],
              ispd: null,
              latD: "N",
              lonD: "E",
              pdop: 1.1,
              rfid: null,
              stat: 1010,
              temp: 32,
              time: today,
              //   csvtime,
              vdop: 0.69,
              //   parseFloat(csvData[i].VDOP),
              engOn: 1,
              seqNo: null,
              Others: {
                lac: null,
                mcc: null,
                mnc: null,
                firstNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
                thirdNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
                fourthNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
                secondNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
              },
              batCur: 50,
              batPer: 40,
              cellId: null,
              gpsAvi: 1,
              digInp1: 0,
              mileage: 2265,
              roamAct: 0,
              datafrom: "gps",
              distance: null,
              duration: null,
              direction: 65,
              packetType: packetType,
              packetStatus: "h",
            },
            deviceId: config.dbDeviceId[0],
            deviceType: null,
          };

          Array.push([
            // today,
            config.dbSize,
            config.dbDeviceId[0],
            updData,
            config.dbDeviceId[0],
            // today,
          ]);
        }

        const text = `INSERT INTO raw_data("size", "deviceId", "data", "dataFrom") VALUES($1,$2,$3,$4) RETURNING *`;
        const values = Array[0];
        pool
          .query(text, values)
          .then((res) => {
            console.log(`Row no ${res.rowCount} Inserted!`);
          })
          .catch((e) => console.error(e.stack));

        //Bulk Insert
        // const query = pgFormat(
        //   'INSERT INTO raw_data("size", "deviceId", "data", "dataFrom",) VALUES %L',
        //   Array
        // );
        // pool.query(query, (err, res) => {
        //   if (err) {
        //     console.log("Error: ", err.stack);
        //   } else {
        //     console.log(`${res.rowCount} Data inserted`);
        //   }
        // });

        i = i + 1;
      });
    } catch (err) {
      console.log("Error: ", err);
    }
  };
  mockDatad1();

  const mockDatad2 = async () => {
    try {
      let i = 0;
      let packetType = "nr";
      cron.schedule("* * * * * *", () => {
        let Array = [];
        if (i < btoc.coordinates[0].length) {
          // let newDate = Moment().format("YYYY-MM-DDTHH:mm:ss");
          let today = Moment().format("YYYY-MM-DDTHH:mm:ss");

          if (i == 11 || i == 22 || i == 33 || i == 77) {
            packetType = "hb";
          }

          let updData = {
            ts: Moment(today).unix(),
            data: {
              gf: "3D",
              a01: 48,
              lac: null,
              lat: btoc.coordinates[0][i][1],
              lon: btoc.coordinates[0][i][0],
              nfs: 9,
              pgn: null,
              sig: 13,
              spd: 1.36,
              //   csvData[i].Speed,
              tas: null,
              date: today,
              di01: null,
              di02: null,
              di03: null,
              di04: null,
              di05: null,
              di06: null,
              do01: null,
              do02: null,
              fspd: null,
              hdop: 0.76,
              //   parseFloat(csvData[i].HDOP),
              imei: config.dbDeviceId[1],
              ispd: null,
              latD: "N",
              lonD: "E",
              pdop: 1.1,
              rfid: null,
              stat: 1010,
              temp: 32,
              time: today,
              //   csvtime,
              vdop: 0.69,
              //   parseFloat(csvData[i].VDOP),
              engOn: 1,
              seqNo: null,
              Others: {
                lac: null,
                mcc: null,
                mnc: null,
                firstNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
                thirdNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
                fourthNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
                secondNeighbour: {
                  lac: null,
                  cellId: null,
                  gsmStrength: null,
                },
              },
              batCur: 50,
              batPer: 40,
              cellId: null,
              gpsAvi: 1,
              digInp1: 0,
              mileage: 2265,
              roamAct: 0,
              datafrom: "gps",
              distance: null,
              duration: null,
              direction: 65,
              packetType: packetType,
              packetStatus: "h",
            },
            deviceId: config.dbDeviceId[1],
            deviceType: null,
          };

          Array.push([
            // today,
            config.dbSize,
            config.dbDeviceId[1],
            updData,
            config.dbDeviceId[1],
            // today,
          ]);
        }

        const text = `INSERT INTO raw_data("size", "deviceId", "data", "dataFrom") VALUES($1,$2,$3,$4) RETURNING *`;
        const values = Array[0];
        pool
          .query(text, values)
          .then((res) => {
            console.log(`Row no1 ${res.rowCount} Inserted!`);
          })
          .catch((e) => console.error(e.stack));

        //Bulk Insert
        // const query = pgFormat(
        //   'INSERT INTO raw_data("size", "deviceId", "data", "dataFrom",) VALUES %L',
        //   Array
        // );
        // pool.query(query, (err, res) => {
        //   if (err) {
        //     console.log("Error: ", err.stack);
        //   } else {
        //     console.log(`${res.rowCount} Data inserted`);
        //   }
        // });

        i = i + 1;
      });
    } catch (err) {
      console.log("Error: ", err);
    }
  };
  mockDatad2();
})();
