//Import kafka
const Kafka = require("kafka-node");
//Import Config
const {
  kafkaHost,
  kafkaPort,
  kafkaCommandSubTopic,
} = require("./../config/adaptor");
const Producer = Kafka.Producer;
const Consumer = Kafka.Consumer;
const kafkaClient = new Kafka.KafkaClient({
  kafkaHost: `${kafkaHost}:${kafkaPort}`,
  requestTimeout: 50000,
});

const kafkaProducer = new Producer(kafkaClient);

const kafkaConsumer = new Consumer(
  kafkaClient,
  [{ topic: kafkaCommandSubTopic, partition: 0, offset: -1 }],
  {
    fromOffset: false,
  }
);

kafkaProducer.on("ready", function () {
  console.info("Kafka is ready");
  kafkaReady = true;
});
//Send
function produce(payloads) {
  if (!kafkaProducer.ready) {
    return;
  }
  kafkaProducer.send(payloads, function (err, data) {
    if (err) {
      console.error(err);
    }
    console.info("Data successfully Sent to transformer!", data);
  });
}

//Error
kafkaProducer.on("error", function (err) {
  console.log("Crashed 2", err);
  process.exit(-1);
});
module.exports = {
  kafkaProducer: produce,
  kafkaConsumer,
};
