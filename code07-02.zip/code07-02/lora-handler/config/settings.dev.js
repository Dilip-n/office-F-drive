module.exports = {
  appEnv: process.env.NODE_ENV || "dev",
  appLog: process.env.APP_LOG || "dev",
  appPort: process.env.SSSS_LORA_HANDLER || 3047,
  appHost: "0.0.0.0",

  deviceAPI:
    process.env.DATA_HANDLER_DEVICE_IDENTITY_API ||
    "http://192.168.10.26:17012/device/",
  kafkaHost:
    process.env.DATA_HANDLER_KAFKA_HOST ||
    process.env.KAFKA_HOST ||
    "192.168.10.26",
  kafkaPort:
    process.env.DATA_HANDLER_KAFKA_PORT || process.env.KAFKA_PORT || "29092",
  kafkaPublishTopic:
    process.env.DATA_HANDLER_KAFKA_TOPIC_PUB || "dataHandlerData",
  kafkaStatusPublishTopic:
    process.env.DATA_HANDLER_KAFKA_STATUS_TOPIC_PUB || "statusData",
  kafkaCommandSubTopic:
    process.env.DATA_HANDLER_LORA_KAFKA_COMMAND_TOPIC_SUB || "loraCommandData",
  loraServer: process.env.SSSS_LORA_SERVER || "https://eu2.loriot.io/",
  loraServerAppId: process.env.SSSS_LORA_APPID || "BE010329",
  loraServerAuthToken:
    process.env.SSSS_LORA_SERVER_AUTH_TOKEN ||
    "vgEDKQAAAA1ldTIubG9yaW90Lmlv_470HKfRKxdrw7dm_4R9hg==",
};
