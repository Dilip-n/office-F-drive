# BMS APIs

( Bin Monitoring Backend )

## NPM Library Used

- Koa
- Postgres + Sequelizer
- Jsonwebtoken, Bcrypt, Koa-Cors,
- Asynchronous Functions (Async/Await)

## Getting Started

```shell
$ git clone git@gitlab.com:hyperthingsiot/iot-platform/applications/fms/backend.git
$ cd fms-apis
```

## Project structure

Here's the default structure for your project files.

- **server**
  - **config**
    - adaptor.js (Config Adaptor)
  - **api**
    - **v1**
      - **controllers**
      - **routes**
      - **services**
      - **db**
      - **utils**
- server.js (Server Configuration)
- index.js (Server Configuration)

# Environment variables

(To begin with, we have to define some environment variables)

| Name           | App Specific      | Default | Required | Description | Valid | Notes |
| -------------- | ----------------- | ------- | :------: | ----------- | :---: | ----- |
| PGDB_HOST      | FMS_PGDB_HOST     |         |   Yes    |             |       |       |
| PGDB_PORT      | FMS_PGDB_PORT     |         |   Yes    |             |       |       |
| PGDB_IS_AUTH   | FMS_PGDB_IS_AUTH  |         |   Yes    |             |       |       |
| PGDB_USERNAME  | FMS_PGDB_USERNAME |         |   Yes    |             |       |       |
| PGDB_PASSWORD  | FMS_PGDB_PASSWORD |         |   Yes    |             |       |       |
| PGDB_NAME      |                   |         |   Yes    |             |       |       |
|                | FMS_API_PORT      |         |   Yes    |             |       |       |
|                | DS_API            |         |   Yes    |             |       |       |
| FMS_DS_API_KEY |                   |         |   Yes    |             |       |       |

## Running

Install dependencies

```
npm install
```

Run Application in Development Env

```
$ npm run start:dev
```

Run Application in Production Env

```
$ npm start
```
