//Utils

class Utils {
  constructor() {}
}
//Export
module.exports = Utils;
