const MongoClient = require("mongodb").MongoClient;
const config = require("../config");
const logger = require("./logHandler");

// Connection URL
let url = "";

if (config.mongodbIsAuth === "true") {
  url = `mongodb://${encodeURIComponent(
    config.mongodbUsername
  )}:${encodeURIComponent(config.mongodbPassword)}@${config.mongodbHost}:${
    config.mongodbPort
  }?authSource=admin`;
} else {
  url = `mongodb://${config.mongodbHost}:${config.mongodbPort}`;
}

// Create a new MongoClient
const client = new MongoClient(url, { useUnifiedTopology: true });

module.exports = client;
