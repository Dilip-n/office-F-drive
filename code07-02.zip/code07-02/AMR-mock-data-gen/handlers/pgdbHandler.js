const { Pool } = require("pg");
const config = require("../config");
const logger = require("./logHandler");
const moment = require("moment");

let url = "";

let tenantPools = {};

if (config.pgdbIsAuth === "true") {
  url = `postgres://${encodeURIComponent(
    config.pgdbUsername
  )}:${encodeURIComponent(config.pgdbPassword)}@${config.pgdbHost}:${
    config.pgdbPort
  }`;
} else {
  url = `postgres://${config.pgdbHost}:${config.pgdbPort}`;
}

function getTenantPool(tenantId) {
  if (tenantId in tenantPools) {
    // already a pool is present
    return tenantPools[tenantId];
  } else {
    tenantPools[tenantId] = new Pool({
      connectionString: `${url}/${tenantId}`,
      max: 6,
    });
    tenantPools[tenantId].on("error", (err, client) => {
      logger.error(
        `Unexpected error on idle client of tenantId:${tenantId}`,
        err
      );
    });
    return tenantPools[tenantId];
  }
}

function writeTsData(task, error = false) {
  try {
    let now = moment();
    let currentDate = moment(now, "YYYY-MM-DD");
    let table1 = "ts_device_data";
    let table2 = "ts_data_consumptions";
    let query1 = `INSERT INTO ${table1}(time, "macAddress", "deviceType", data, "dataFrom", "ingestTime", size)
  VALUES (to_timestamp($1), $2, $3, $4, $5, to_timestamp($6), $7);`;
    let query2 = `select * from ts_data_consumption where date(time) = '${currentDate}';`;
    //console.log(query2);
    const pool = new Pool({
      connectionString: `${url}/cfgtyj-amr-app`,
      max: 6,
    });
    const values1 = [
      task.ts,
      task.deviceId,
      task.deviceTypeId,
      JSON.stringify(task),
      task.deviceId,
      task.ts,
      10,
    ];
    pool.query(query1, values1).then(
      (res) => {
        logger.info(
          `Inserted ${task.ts}:${task.deviceId}:${task.deviceTypeId}:${task.ts}`
        );
      },
      (err) => console.log(err)
    );

    let consumpQuery = `INSERT INTO ${table2}(time,"macAddress", "deviceType", units, wh)
  VALUES (to_timestamp($1), $2, $3, $4, $5);`;
    let wh = parseFloat(task.wh);
    let unit = parseFloat(wh / 1000).toFixed(2);

    pool
      .query(consumpQuery, [
        task.ts,
        task.deviceId,
        task.deviceTypeId,
        unit,
        wh,
      ])
      .then(
        (res) => {
          logger.info(`Inserted ${task.ts}:${task.deviceId} data consumption`);
        },
        (err) => console.log(err)
      );
  } catch (error) {
    console.log(error);
  }
}

async function calculate() {
  try {
    console.log("Started ...........");
    //========================================================================================
    const pool = new Pool({
      connectionString: `${url}/cfgtyj-amr-app`,
      max: 6,
    });
    let now = moment();
    let currentDate = moment(now, "YYYY-MM-DD");
    let end = moment(currentDate).format("YYYY-MM-DD");
    let start = moment(end).add(-30, "days").format("YYYY-MM-DD"); //Set range

    console.log("start date ", start);
    console.log("end end ", end);

    function enumerateDaysBetweenDates(startDate, endDate) {
      let date = [];
      while (moment(startDate) <= moment(endDate)) {
        date.push(startDate);
        startDate = moment(startDate).add(1, "day").format("YYYY-MM-DD");
      }
      return date;
    }
    let dateArr = await enumerateDaysBetweenDates(start, end);
    // console.log("dateArr ", dateArr);

    let map1 = await dateArr.map(async (date) => {
      let query2 = `select * from ts_device_data where date(time) = '${date}';`;
      let query3 = `select * from ts_data_consumption where date(time) = '${date}';`;
      // console.log("query2 ", query2);
      // console.log("query3 ", query3);
      let device_data = await pool.query(query2);
      console.log("device_data ", device_data.rows.length);

      if (device_data.rows.length > 0) {
        let allData = device_data.rows;
        let map1 = await allData.map(async (data) => {
          // console.log(data);

          let query = `INSERT INTO ts_data_consumption (time, "meterId", units, wh)
  VALUES (to_timestamp($1), $2, $3, $4);`;
          let wh = parseFloat(data.data.Wh.value);
          let unit = parseFloat(wh / 1000);
          let values = [data.data.ts, data.data.deviceId, unit, wh];
          await pool.query(query, values).then(
            (res) => {
              logger.info(
                `Inserted ${data.data.ts}:${data.data.deviceId} data consumption`
              );
            },
            (err) => console.log(err)
          );
        });
      } else {
        console.log("No data found for ", date);
      }

      console.log("Data consumption data inserted  ");
    });
    await Promise.all(map1);
  } catch (err) {
    console.log(err.message);
    console.log("============ERROR IN CLACULATE ==============");
  }
}

module.exports = {
  writeTsData,
  calculate,
};
