var mongoose = require("mongoose");

var ModelSchema = mongoose.Schema({
  temp: {
    type: Number,
    index: true,
  },
  created_date: {
    type: Date,
    default: Date.now,
  },
});

//------------------------------------------Model---------------------------------------------------------------------------

let device_data = (module.exports = mongoose.model("device_data", ModelSchema));
