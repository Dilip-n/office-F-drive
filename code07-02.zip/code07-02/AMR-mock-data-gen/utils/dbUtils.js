const mongo = require("mongodb");

function getOID(_id) {
  return new mongo.ObjectID(_id);
}

module.exports = {
  getOID
};
