module.exports = {
  appName: "transformer"
};
