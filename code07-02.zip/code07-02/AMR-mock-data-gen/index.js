// MQTT subscriber
const mqtt = require("mqtt");
const logger = require("./handlers/logHandler");
//const dbClient = require("./handlers/dbHandler");
const pgdbClient = require("./handlers/pgdbHandler");
const { writeTsData, calculate } = pgdbClient;

function dataFilter(data) {
  let filteredData = {};

  filteredData.ts = data.ts;
  filteredData.gatwayType = data.GatwayType;
  filteredData.deviceId = data.deviceId;
  filteredData.deviceTypeId = data.deviceTypeId;
  filteredData.frequency = data.Frequency.value;
  filteredData.wh = data.Wh.value;
  filteredData.pf = data.PF.value;
  filteredData.pfr = data.PF_R.value;
  filteredData.pfy = data.PF_Y.value;
  filteredData.pfb = data.PF_B.value;
  filteredData.vll = data.VLL.value;
  filteredData.vry = data.Vry.value;
  filteredData.vyb = data.Vyb.value;
  filteredData.vbr = data.Vbr.value;
  filteredData.current = data.Current.value;
  filteredData.currentR = data.Current_R.value;
  filteredData.currentY = data.Current_Y.value;
  filteredData.currentB = data.Current_B.value;
  filteredData.watts = data.Watts.value;
  filteredData.wattsR = data.WattsR.value;
  filteredData.wattsY = data.WattsY.value;
  filteredData.wattsB = data.WattsB.value;
  filteredData.vln = data.VLN.value;
  filteredData.vr = data.V_R.value;
  filteredData.vy = data.V_Y.value;
  filteredData.vb = data.V_B.value;
  filteredData.loadHrr = data.Load_Hr_R.value;

  return filteredData;
}

const client = mqtt.connect(`mqtt://iot2.hyperthings.in`, {
  username: "htsuser",
  password: "hts@123",
});

const topic = "IntelHWCS/NX100100/EMETER/PERIODIC";
const topic1 = "IntelHWCS/NX100101/EMETER/PERIODIC";

client.on("connect", () => {
  console.log("MQTT connected");
  //calculate();
  client.subscribe(topic);
  client.subscribe(topic1);
  console.log("<----------------------------------------------->");
  console.log("MQTT connected and subscribed to topic: ", topic);
  console.log("MQTT connected and subscribed to topic: ", topic1);
});

client.on("message", (topic, message) => {
  console.log("MQTT message from topic: ", topic);
  message = message.toString();
  let filteredData = dataFilter(JSON.parse(message));
  if (filteredData.wh == 0) {
    console.log("Dont insert data....:)");
  } else {
    //console.log(filteredData);
    writeTsData(filteredData);
  }
});

client.on("message", (topic1, message) => {
  console.log("MQTT message from topic: ", topic1);
  message = message.toString();
  let filteredData = dataFilter(JSON.parse(message));
  if (filteredData.wh == 0) {
    console.log("Dont insert data....:)");
  } else {
    //console.log(filteredData);
    writeTsData(filteredData);
  }
});

// let data = {
//   ts: 1608540654,
//   GatwayType: "NODEX",
//   deviceId: "NX100100",
//   deviceTypeId: "EMETER1",
//   Frequency: { value: 50.26, status: 1 },
//   Wh: { value: 2963.63, status: 1 },
//   PF: { value: -0.58, status: 1 },
//   PF_R: { value: -0.87, status: 1 },
//   PF_Y: { value: -0.77, status: 1 },
//   PF_B: { value: 0, status: 1 },
//   VLL: { value: 412.78, status: 1 },
//   Vry: { value: 412.21, status: 1 },
//   Vyb: { value: 413.56, status: 1 },
//   Vbr: { value: 412.57, status: 1 },
//   Current: { value: 1.23, status: 1 },
//   Current_R: { value: 1.21, status: 1 },
//   Current_Y: { value: 1.21, status: 1 },
//   Current_B: { value: 1.27, status: 1 },
//   Watts: { value: 23.81, status: 1 },
//   WattsR: { value: 5.37, status: 1 },
//   WattsY: { value: 16.85, status: 1 },
//   WattsB: { value: 1.59, status: 1 },
//   VLN: { value: 238.34, status: 1 },
//   V_R: { value: 237.1, status: 1 },
//   V_Y: { value: 239.02, status: 1 },
//   V_B: { value: 238.89, status: 1 },
//   Load_Hr_R: { value: 19420308, status: 1 },
// };
