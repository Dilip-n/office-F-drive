module.exports = {
  mongodbHost:
    process.env.TRANSFORMER_MONGODB_HOST ||
    process.env.MONGODB_HOST ||
    "192.168.0.188",
  mongodbPort:
    process.env.TRANSFORMER_MONGODB_PORT || process.env.MONGODB_PORT || "27011",
  mongodbIsAuth:
    process.env.TRANSFORMER_MONGODB_IS_AUTH ||
    process.env.MONGODB_IS_AUTH ||
    "true",
  mongodbUsername:
    process.env.TRANSFORMER_MONGODB_USERNAME ||
    process.env.MONGODB_USERNAME ||
    "root",
  mongodbPassword:
    process.env.TRANSFORMER_MONGODB_PASSWORD ||
    process.env.MONGODB_PASSWORD ||
    "20374u2op232314",

  pgdbHost:
    process.env.TRANSFORMER_PGDB_HOST || process.env.PGDB_HOST || "localhost",
  pgdbPort:
    process.env.TRANSFORMER_PGDB_PORT || process.env.PGDB_PORT || "54323",
  pgdbIsAuth:
    process.env.TRANSFORMER_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || "true",
  pgdbUsername:
    process.env.TRANSFORMER_PGDB_USERNAME ||
    process.env.PGDB_USERNAME ||
    "master",
  pgdbPassword:
    process.env.TRANSFORMER_PGDB_PASSWORD ||
    process.env.PGDB_PASSWORD ||
    "DHNNOQIYWMDZZPOQ",
};
