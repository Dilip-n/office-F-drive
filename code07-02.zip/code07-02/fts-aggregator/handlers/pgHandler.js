const { Pool } = require("pg");
const config = require("../config");
const logger = require("./logHandler");

let url = "";

if (config.pgdbIsAuth === "true") {
  url = `postgres://${encodeURIComponent(
    config.pgdbUsername
  )}:${encodeURIComponent(config.pgdbPassword)}@${config.pgdbHost}:${
    config.pgdbPort
  }`;
} else {
  url = `postgres://${config.pgdbHost}:${config.pgdbPort}`;
}

let pool = new Pool({
  connectionString: `${url}/${config.pgdbName}`,
  max: 6,
});

module.exports = pool;
