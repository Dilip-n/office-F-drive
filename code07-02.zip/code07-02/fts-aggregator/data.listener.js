"use strict";
//Import Koa
const Koa = require("koa");
//Import Koa Body Parser
const BodyParser = require("koa-bodyparser");
//Import Koa Cors
const Cors = require("@koa/cors");
//Import Koa Morgan - Logger
const Morgan = require("koa-morgan");
//Import Koa Router
const Router = require("koa-router");
//Import PG Pool
const PGPool = require("./handlers/pgHandler");
//Import Settings
const { appPort, appHost, appName, appEnv } = require("./config");
//Controllers
const saveData = async (ctx, next) => {
  //Get Input
  const input = ctx.request.body;
  //Format
  const data = {
    time: input.ingestTimestamp,
    packetSize: input.packetSize,
    deviceId: input.deviceId,
    data: input.data,
    dataFrom: input.dataFrom,
    ingestTimestamp: input.ingestTimestamp,
  };
  //Validate
  try {
    //Query
    //Save it to raw_data
    const query = `Insert into raw_data
      ("time", "size", "deviceId", "data", "dataFrom", "ingestTime")
      VALUES($1, $2, $3, $4, $5, $6) returning id
      `;
    const result = await PGPool.query(query, [
      new Date(data.time),
      data.packetSize,
      data.deviceId,
      JSON.stringify(data.data),
      data.dataFrom,
      new Date(data.ingestTimestamp),
    ]);
    //Done
    console.log("Data saved", result.rows);
    //Check Packet Type and save alert
    let packetType = JSON.stringify(data.data.data.packetType);
    if (packetType === '"nr"') {
      console.log("Normal data");
    } else {
      //Save it to alerts
      const query = `Insert into alerts
           ("time", "alertType", "deviceId", "data", "severity")
           VALUES($1, $2, $3, $4, $5) returning id
           `;
      const result1 = await PGPool.query(query, [
        new Date(data.time),
        data.data.data.packetType,
        data.deviceId,
        JSON.stringify(data.data),
        1,
      ]);
      console.log("Alert Saved", result1.rows);
    }
    //Response
    ctx.status = 200;
    ctx.body = { msg: "Done" };
  } catch (e) {
    console.log(e);
    ctx.status = 500;
    ctx.body = { msg: "Internal Error" };
  }
};

//Koa
class App extends Koa {
  constructor(...params) {
    super(...params);
    this._setMiddlewares();
    this._setRoutes();
  }
  _setMiddlewares() {
    //Body Parser
    this.use(
      BodyParser({
        enableTypes: ["json"],
        jsonLimit: "10mb",
      })
    );
    //CORS
    this.use(Cors());
    //Morgan - Request Logger
    this.use(Morgan("combined"));
  }

  _setRoutes() {
    const router = new Router({
      prefix: "/api/v1",
    });
    //Test Route
    router.get("/status", (ctx, next) => {
      ctx.body = "Running!";
    });
    //Data
    router.post("/data", saveData);
    // Application router
    this.use(router.routes());
    this.use(router.allowedMethods());
  }
  //Server listen
  listen(...args) {
    const server = super.listen(...args);
    return server;
  }
}

//Instantiate App
const app = new App();
// Start server
const server = app.listen(appPort, appHost, () => {
  console.log(
    `\n-------\n${appName} listening on ${appHost}:${appPort}, in ${appEnv}\n-------`
  );
});
