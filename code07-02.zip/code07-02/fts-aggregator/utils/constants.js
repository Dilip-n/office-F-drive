module.exports = {
  appName: "aggregator",
};
