module.exports = {
  pgdbHost:
    process.env.FTS_AGG_PGDB_HOST || process.env.PGDB_HOST || "localhost",
  pgdbPort: process.env.FTS_AGG_PGDB_PORT || process.env.PGDB_PORT || "17047",
  pgdbIsAuth:
    process.env.FTS_AGG_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || "true",
  pgdbUsername:
    process.env.FTS_AGG_PGDB_USERNAME ||
    process.env.PGDB_USERNAME ||
    "postgres",
  pgdbPassword:
    process.env.FTS_AGG_PGDB_PASSWORD ||
    process.env.PGDB_PASSWORD ||
    "password",
  pgdbName: process.env.FTS_AGG_PGDB_NAME || process.env.PGDB_NAME || "fts-app",
  appPort: process.env.APP_PORT || 3035,
  appHost: process.env.FTS_AGG_HOST || "0.0.0.0",
  appName: "FTS-Aggregator",
  appEnv: process.env.FTS_AGG_ENV || "dev",
  iotpfDsApi:
    process.env.FTS_AGG_DS_API ||
    process.env.DS_API ||
    "http://10.20.20.102:3002/api/v1",
  iotpfDsApiKey:
    process.env.FTS_AGG_DS_API_KEY ||
    process.env.DS_API_KEY ||
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRJZCI6IjVlOTlhOTAzMTQyMWZmMDAxOTk2Y2ZlNCIsImFwcElkIjoiMzg3ODg2MTg3MzE3MDQzNiIsImlhdCI6MTU4OTk3Mjg0N30.hW3rTqFZZJWpYO1F2tlNSkexVF4ba7uhGMgW2V_RjRg",
  refreshInterval: process.env.FTS_AGG_REFRESH_INTERVAL || "20",
};
