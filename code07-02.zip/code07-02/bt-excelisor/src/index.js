const { default: axios } = require("axios");
const express = require("express");
var cors = require("cors");
const excel = require("exceljs");
const moment = require("moment");
const constants = require("./constants");
const clientUrl = process.env.CLIENT_URL || "https://ibin.hyperthings.in";
const baseUrl = process.env.BASE_URL || "http://localhost:3037/api/v1";
const port = process.env.PORT || 3333;
const host = process.env.HOST || '0.0.0.0';
const app = express();

var corsOptions = {
  origin: `${constants.CLIENT_URL}`,
  optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
};

app.use(cors(corsOptions));

app.listen(constants.PORT, host, () => {
  console.log(`🚀 Server is running on http://localhost:${constants.PORT}`);
});

app.get("/", (req, res) => {
  res.send("Working");
});

app.get("/download/", async (req, res) => {
  const token = req.query.token;
  if (!token) {
    return res.status(403).send("A token is required for authentication");
  }

  // there are two type
  // 1. raw
  // 2. rawLogs

  try {
    const url = `/data/reports?deviceId=${
      req.query?.deviceId ? req.query?.deviceId : ""
    }&siteId=${req.query?.siteId ? req.query?.siteId : ""}&fromDate=${
      req.query?.fromDate ? req.query?.fromDate : ""
    }&toDate=${req.query?.toDate ? req.query?.toDate : ""}&type=${
      req.query?.type
    }`;

    const { data } = await axios({
      method: "get",
      baseURL: constants.BASE_URL,
      url,
      headers: {
        Authorization: `Bearer ${token}`,
      },
      timeout: 5000,
    });

    if (!data.data) return res.send(data.msg);

    let formatedData = [...data.data.data];

    // console.log(moment(formatedData[0][0]).format("MMM Do YYYY, h:mm:ss a"));
    formatedData.forEach((value) => {
      // console.log(v[0]);
      value[0] = moment(value[0]).format("MMM Do YYYY, h:mm:ss a");
    });

    console.log(formatedData[0][0]);

    let workbook = new excel.Workbook();
    let worksheet;

    if (req.query?.type === "raw") {
      await workbook.xlsx.readFile("src/assets/raw_data.xlsx");
      worksheet = workbook.getWorksheet("raw_data");
    } else {
      await workbook.xlsx.readFile("src/assets/raw_packet_logs.xlsx");
      worksheet = workbook.getWorksheet("raw_packet_logs");
    }

    // setting date to cells
    let cell = worksheet.getCell("D2");
    cell.value = req.query?.fromDate;
    cell = worksheet.getCell("D3");
    cell.value = req.query?.toDate;

    // adding data
    worksheet.addRows(formatedData);

    // adding logo
    let logo = workbook.addImage({
      filename: "src/assets/logo.png",
      extension: "png",
    });

    worksheet.addImage(logo, "B1:B3");

    logo = workbook.addImage({
      filename: "src/assets/bmc_logo.png",
      extension: "png",
    });

    worksheet.addImage(logo, "A1:A3");

    // res is a Stream object
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${
        req.query?.type === "raw" ? "Raw Data" : "Raw Packet Logs"
      } ${new Date().toLocaleString()}.xlsx"`
    );

    return workbook.xlsx.write(res).then(() => {
      res.status(200).end();
    });
  } catch (err) {
    console.log(err);
    res.status(500).json(err);
  }
});
