module.exports = {
  BASE_URL: process.env.BTEXCEL_BTAPI_URL || "http://localhost:17299/api/v1",
  CLIENT_URL: process.env.BTEXCEL_CLIENT_URL || "https://ibin.hyperthings.in",
  PORT: process.env.BTEXCEL_PORT || 3333,
};

// http://iot.hyperthings.in:7003/download
