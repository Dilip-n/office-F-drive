"use strict";
//Import App
const App = require("./app");
//Import Settings
const { ip, port, name, env } = require("./config/adaptor");
//Instantiate App
const app = new App();
// Start server
const server = app.listen(port, ip, () => {
  console.log(
    `\n-------\n${name} listening on ${ip}:${port}, in ${env}\n-------`
  );
});
// server.on("error", handleError);

// const errors = ["unhandledRejection", "uncaughtException"];
// errors.map((error) => {
//   process.on(error, handleError);
// });

// Expose app
module.exports = app;
