//Import settings
const { rawDataSchema } = require("./../../../../config/adaptor");

module.exports = (input = {}) => {
  const Schema = {
    User: {
      id: {
        type: input.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      name: input.STRING,
      email: input.STRING,
      mobile: input.STRING,
      password: input.STRING,
      address: input.STRING,
      isAdmin: input.STRING,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    Device: {
      id: {
        type: input.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
      isActive: input.BOOLEAN,
      state: input.BOOLEAN,
      deviceId: input.BIGINT,
      name: input.STRING,
      macAddress: input.STRING,
      gateway: input.BOOLEAN,
      mfrId: input.STRING,
      addedBy: input.STRING,
      protocolType: input.STRING,
      lat: input.STRING,
      lng: input.STRING,
      address: input.STRING,
      site: input.STRING,
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },

    Site: {
      id: {
        type: input.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      name: {
        type: input.STRING,
        allowNull: false,
      },
      siteId: {
        type: input.STRING,
        allowNull: false,
      },
      lat: {
        type: input.DOUBLE,
        allowNull: false,
      },
      lng: {
        type: input.DOUBLE,
        allowNull: false,
      },
      address: {
        type: input.STRING,
        allowNull: false,
      },
      parentId: {
        type: input.STRING,
        allowNull: true,
      },
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    RawData: {
      time: {
        type: input.DATE,
        allowNull: false,
      },
      id: {
        type: input.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      deviceId: {
        type: input.STRING,
        allowNull: false,
      },
      data: {
        type: input.JSONB,
        allowNull: false,
      },
    },
    Unit: {
      id: {
        type: input.INTEGER,
        allowNull: false,
        primaryKey: true,
      },
      name: {
        type: input.STRING,
        allowNull: true,
      },
      ref: {
        type: input.STRING,
        allowNull: false,
      },
      uom: {
        type: input.STRING,
        allowNull: true,
      },
      format: {
        type: input.STRING,
        allowNull: true,
      },
    },
    ReportSchdl: {
      name: {
        type: input.STRING,
        allowNull: false,
      },
      frequency: {
        type: input.INTEGER,
        allowNull: false,
      },
      format: {
        type: input.STRING,
        allowNull: false,
      },
      site: {
        type: input.STRING,
        allowNull: false,
      },
      device: {
        type: input.STRING,
        allowNull: false,
      },
      user: {
        type: input.INTEGER,
        allowNull: false,
      },
      lastSentAt: {
        type: input.DATE,
        allowNull: true,
      },
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    RawDataData: rawDataSchema,
    Rule: {
      name: {
        type: input.STRING,
        allowNull: false,
      },
      deviceId: {
        type: input.STRING,
        allowNull: false,
      },
      desc: {
        type: input.STRING,
        allowNull: true,
      },
      dataPath: {
        type: input.STRING,
        allowNull: false,
      },
      operator: {
        type: input.STRING,
        allowNull: false,
      },
      value: {
        type: input.INTEGER,
        allowNull: false,
      },
      severity: {
        type: input.INTEGER,
        allowNull: false,
      },
      statement: {
        type: input.STRING,
        allowNull: false,
      },
      incharge: {
        type: input.JSONB,
        allowNull: false,
      },
      createdAt: {
        type: input.DATE,
        allowNull: false,
      },
      updatedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
    Alert: {
      time: {
        type: input.DATE,
        allowNull: false,
      },
      alertType: {
        type: input.STRING,
        allowNull: false,
      },
      alertLevel: {
        type: input.INTEGER,
        allowNull: false,
      },
      deviceId: {
        type: input.STRING,
        allowNull: false,
      },
      rule: {
        type: input.INTEGER,
        allowNull: false,
      },
      value: {
        type: input.STRING,
        allowNull: false,
      },
      severity: {
        type: input.INTEGER,
        allowNull: false,
      },
      resolved: {
        type: input.BOOLEAN,
        allowNull: false,
      },
      resolvedBy: {
        type: input.INTEGER,
        allowNull: false,
      },
      desc: {
        type: input.STRING,
        allowNull: true,
      },
      resolvedAt: {
        type: input.DATE,
        allowNull: false,
      },
    },
  };
  //User Schema final
  const { password, ...UserSchema } = Schema.User;
  //Device Schema final
  const { isActive, ...DeviceSchema } = Schema.Device;
  //Raw data Schema final
  const { ...RawDataSchema } = Schema.RawData;
  //Raw Site Schema final
  const { ...SiteSchema } = Schema.Site;
  //Rule Schema
  const { ...RuleSchema } = Schema.Rule;
  //Alert Schema
  const { ...AlertSchema } = Schema.Alert;
  //Return
  return {
    Schema,
    UserSchema,
    DeviceSchema,
    RawDataSchema,
    SiteSchema,
    RawDataData: Schema.RawDataData,
    RuleSchema,
    AlertSchema,
  };
};
