/*jshint esversion: 8 */
const Sequelize = require("sequelize");
const chalk = require("chalk");

module.exports = {
  connectDb: async (uri) => {
    try {
      // Option 1: Passing parameters separately
      //{ logging: true } - it will print the query which is being executed
      const sequelize = new Sequelize(uri, { logging: console.log });
      await sequelize.authenticate();
      // Success
      console.log(chalk.greenBright(`PGSQL-> Connected \n-------`));

      return sequelize;
    } catch (err) {
      //Error
      console.log(chalk.redBright(`PGSQL-> Connection error details->${err}`));
      process.exit(-1);
    }
  },
};
