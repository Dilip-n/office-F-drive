/*jshint esversion: 8 */
const express = require("express");

const morgan = require("morgan");

const { mongoDb } = require("../constants");

//Require Routes
const v1Routes = require("../api/v1/routes");

//Mongoose connection
const mongooseConn = require("./mongoose.config");
/**
 * Express instance
 * @public
 */
const app = express();

// request logging. dev: console | production: file
morgan.format(
  "devFormat",
  ':date ":remote-addr" ":method :url" :status :res[content-length] - :response-time ms'
);
app.use(morgan("devFormat"));

//CORS Configuration
//allowing cross domain access
//app.use(cors());
var allowCrossDomain = function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Methods",
    "GET,PUT,POST,PATCH, DELETE,OPTIONS"
  );
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, Content-Type,auth-token, Authorization, Accept,Content-Length, X-Requested-With, X-PINGOTHER"
  );
  res.header("Access-Control-Expose-Headers", "auth-token");
  if ("OPTIONS" === req.method) {
    res.sendStatus(200);
  } else {
    next();
  }
};
app.use(allowCrossDomain);
//swagger
app.set("view engine", "html");
let swaggerUi = require("swagger-ui-express"),
  swaggerDocument = require("../api/v1/api_doc/coreApiDoc.json");

app.use("/core-api-doc", swaggerUi.serve, swaggerUi.setup(swaggerDocument));
// parse body params
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);
/**
 * Database Connection
 */
// Mongoose
(async () => {
  console.log("inside mongo", mongoDb.uri);
  const conn = await mongooseConn.connectDb(mongoDb.uri, mongoDb.options);
  // console.log(conn);
  if ("success" in conn) {
    console.log("inside mongo", conn);
  } else {
    return (exports.mongoDbConn = conn);
  }
})();
// const mongoCheck = async (req, res, next) => {
//   const conn = await mongooseConn.connectDb(mongoDb.uri, mongoDb.options);
//   if ("success" in conn) {
//     return res.status(400).json({
//       success: false,
//       error: {
//         code: 40,
//         msg: "Unable to connect to DB Server !"
//       }
//     });
//   } else {
//     return conn;
//   }
// };
// app.use(mongoCheck);
// exports.mongoDbConn = mongoCheck;

/**
 * App Configurations
 */

// mount api v1 routes
app.use("/api/v1", v1Routes);
/**
 *Error handling
 */
//Handle not found endpoints
app.use((req, res, next) => {
  const err = new Error("Requested Endpoint not found !");
  err.status = 404;
  err.code = 40;
  next(err);
});
//Format all the errors
app.use((err, req, res, next) => {
  res.status(err.status || 500);
  res.json({
    success: false,
    error: {
      code: err.code,
      msg: err.message,
    },
  });
});
module.exports = app;
