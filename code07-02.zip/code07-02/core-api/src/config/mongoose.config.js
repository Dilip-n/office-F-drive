/*jshint esversion: 8 */
const mongoose = require("mongoose");
const chalk = require("chalk");

module.exports = {
  connectDb: async (uri, options) => {
    try {
      mongoose.set("useCreateIndex", true);
      const conn = await mongoose.createConnection(uri, options);
      // Success
      console.log(chalk.greenBright(`MongoDB-> Connected on \n-------`));
      return conn;
    } catch (err) {
      //console.log(err);
      //Error
      console.log(
        chalk.redBright(`MongoDB-> Connection error:  details->${err}`)
      );
      process.exit(-1);
    }
  },
  disconnectDb: async (uri) => {
    try {
      const conn = await mongoose.disconnect();
      // Disconnected
      console.log(
        chalk.greenBright(`-------\nMongoDB-> Disconnected on \n-------`)
      );
    } catch (err) {
      console.log(
        chalk.redBright(`MongoDB-> Connection error:  details->${err}`)
      );
      process.exit(-1);
    }
  },
};
