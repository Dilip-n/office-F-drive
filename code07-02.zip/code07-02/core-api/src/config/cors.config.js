/*jshint esversion: 6 */
const cors = require("cors");
var whitelist = [
  "http://example1.com",
  "http://example2.com",
  "http://192.168.1.155:6030",
  "http://192.168.0.149:5555",
  "http://192.168.1.29:5555"
];
var options = {
  origin: function(origin, callback) {
    if (whitelist.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  methods: ["GET", "PUT", "POST", "DELETE", "PATCH"],
  allowedHeaders: "Content-Type",
  exposedHeaders: ["auth-token"]
};

module.exports = () => cors(options);
