module.exports = {
  mongodbHost:
    process.env.CORE_API_MONGODB_HOST ||
    process.env.MONGODB_HOST ||
    "localhost",
  mongodbPort:
    process.env.CORE_API_MONGODB_PORT || process.env.MONGODB_PORT || "54324",
  mongodbIsAuth:
    process.env.CORE_API_MONGODB_IS_AUTH ||
    process.env.MONGODB_IS_AUTH ||
    "true",
  mongodbUsername:
    process.env.CORE_API_MONGODB_USERNAME ||
    process.env.MONGODB_USERNAME ||
    "newmaster",
  mongodbPassword:
    process.env.CORE_API_MONGODB_PASSWORD ||
    process.env.MONGODB_PASSWORD ||
    "DHNNOQIYWMDZZPOQ",
  mongoDbName: "hts-iot-platform-v1",
  pgdbHost:
    process.env.CORE_API_PGDB_HOST || process.env.PGDB_HOST || "localhost",
  pgdbPort: process.env.CORE_API_PGDB_PORT || process.env.PGDB_PORT || "54323",
  pgdbIsAuth:
    process.env.CORE_API_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || "true",
  pgdbUsername:
    process.env.CORE_API_PGDB_USERNAME || process.env.PGDB_USERNAME || "master",
  pgdbPassword:
    process.env.CORE_API_PGDB_PASSWORD ||
    process.env.PGDB_PASSWORD ||
    "DHNNOQIYWMDZZPOQ",
  pgDbName:
    process.env.CORE_API_PGDB_NAME || process.env.PGDB_NAME || "postgres",

  appPort: process.env.CORE_API_PORT || "3003",
  appHost: process.env.CORE_API_HOST || "0.0.0.0",

  dataSharingPort: process.env.DS_API_PORT || "3002",

  appEnv: process.env.CORE_API_ENV || "dev",
  appLog: process.env.CORE_API_LOG || "dev",

  accessTokenSecret:
    process.env.CORE_API_ACCESS_TOKEN_SECRET ||
    "26650cca716068b75147b27e257360ff1a836738025722893d2034d74351f2f4c08ce9ccb60fec689f3ccf2ab7700886b58024fa92122bad9cdfe4cf9ed7e041",
  refreshTokenSecret:
    process.env.CORE_API_REFRESH_TOKEN_SECRET ||
    "adce7e6d7c01c6dddf1d1b8be9b4d04cfe25e9abb8d1496cc7ab20f89755554f7e2af557fae48f6b6344ec3a9d300d1c211881d3d70416fa1b81c36cf2db89f2",
  dataHandlerAccessTokenSecret:
    process.env.DATA_HANDLER_ACCESS_TOKEN_SECRET ||
    "34vhs7jh348lkgsadhg62bq84u48jbndu27dskjdfh2grsd512ndjkhdgahgds62w3ve623gjhe3287jheiih286ujhe28732hg32376ug",

  tokenSecret:
    process.env.TOKEN_SECRET ||
    "K4Ps9XDVJpjxo1yuOkFOIf3HMM1ThwyW6H3rI4SbHvOwLARZ5sP9jvx33wMrgiJ",

  loraHost:
    process.env.CORE_API_LORA_HOST ||
    process.env.LORA_HOST ||
    "http://192.168.1.220:8080",

  licensingServer: "http://0.0.0.0:3009/hts/api",

  loraUsername:
    process.env.CORE_API_LORA_USERNAME || process.env.LORA_USERNAME || "admin",
  loraPassword:
    process.env.CORE_API_LORA_PASSWORD || process.env.LORA_PASSWORD || "admin",

  dataHandlerHost:
    process.env.CORE_API_DATA_HANDLER_HOST ||
    process.env.DATA_HANDLER_HOST ||
    "http://iot.hyperthings.in",

  emqxHost:
    process.env.CORE_API_EMQX_HOST ||
    process.env.EMQX_HOST ||
    "http:///49.205.218.202:31773",

  promEndpoint:
    process.env.CORE_API_PROM_API ||
    process.env.PROM_API ||
    "http://10.218.218.2:17018/api/v1",

  sendCommandEndPoint:
    process.env.CORE_API_COMMAND_HANDLER_API ||
    process.env.COMMAND_HANDLER_API ||
    "http://localhost:3001",

  minioHost:
    process.env.CORE_API_MINIO_HOST ||
    process.env.MINIO_HOST ||
    "192.168.99.100",
  minioPort:
    process.env.CORE_API_MINIO_PORT || process.env.MINIO_PORT || "9001",
  minioUsername:
    process.env.CORE_API_MINIO_ACCESS_KEY ||
    process.env.MINIO_ACCESS_KEY ||
    "minioadmin",
  minioPassword:
    process.env.CORE_API_MINIO_ACCESS_KEY ||
    process.env.MINIO_SECRET_KEY ||
    "minioadmin",

  kafkaHost:
    process.env.CORE_API_KAFKA_HOST || process.env.KAFKA_HOST || "localhost",
  kafkaPort:
    process.env.CORE_API_KAFKA_PORT || process.env.KAFKA_PORT || "29092",
  kafkaPublishTopic: process.env.CORE_API_KAFKA_TOPIC_PUB || "addDeviceData",

  minioAppLogoBucket: process.env.CORE_API_MINIO_APP_BUCKET || "hts-apps",
};
