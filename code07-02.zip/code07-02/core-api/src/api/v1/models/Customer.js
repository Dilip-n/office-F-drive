/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      name: String,
      is_active: {
        type: Boolean,
        default: true
      }
    },
    {
      timestamps: true,
      strict: false
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
