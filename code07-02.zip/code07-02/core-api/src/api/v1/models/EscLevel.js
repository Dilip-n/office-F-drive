/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      level: {
        type: Number
      },
      name: {
        type: String
      },
      desc: {
        type: String
      },
      triggerTime: {
        type: String
      }
    },
    {
      timestamps: true,
      strict: false
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
