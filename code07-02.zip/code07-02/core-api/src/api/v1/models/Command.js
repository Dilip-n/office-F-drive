/*jshint esversion: 8 */
const mongoose = require("mongoose");
function model(db, collection) {
  const schema = mongoose.Schema(
    {
      tenantId: { type: String },
      deviceId: { type: String },

      payload: {
        type: Object,
      },
      protocol: { type: String },
      from: { type: String },
      by: { type: String },
      ts: { type: String },
    },
    {
      timestamps: true,
      strict: false,
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
