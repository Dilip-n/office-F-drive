/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      for: {
        type: String,
        require: true
      },
      fnCode: {
        type: String,
        require: true
      },
      dataSchema: {
        type: Object
      }
    },
    {
      timestamps: true,
      strict: false
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
