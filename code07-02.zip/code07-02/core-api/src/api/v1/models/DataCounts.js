const mongoose = require('mongoose');

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      _id: mongoose.Schema.Types.ObjectId,
      type: String,
      data: Object
    },
    { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } },
    { strict: false }
  );
  return db.model(collection, schema);
}
exports.model = model;
