/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      deviceId: {
        type: String,
        require: true
      },
      name: {
        type: String,
        require: true
      },
      macAddress: {
        type: String,
        require: true
      },
      lat: {
        type: Number,
        require: true
      },
      lng: {
        type: Number,
        require: true
      },
      address: {
        type: String,
        require: true
      },
      gateway: {
        type: Boolean,
        require: true
      },
      protocolType: {
        type: String,
        require: true
      },
      protocolInfo: Object,
      mfrId: {
        type: mongoose.Schema.Types.ObjectId,
        require: true
      },
      app: {
        type: mongoose.Schema.Types.ObjectId,
        require: true
      },
      addedBy: {
        type: mongoose.Schema.Types.ObjectId
        // ref: "User"
      },
      site: {
        type: mongoose.Schema.Types.ObjectId
      },
      is_active: {
        type: Boolean,
        default: false
      },
      state: {
        type: Boolean,
        default: false
      },
      lastStateChangeAt: {
        type: Date
      }
    },
    {
      toJSON: { virtuals: true },
      toObject: { virtuals: true },
      timestamps: true,
      strict: false
    }
  );
  schema.virtual("rule", {
    ref: "rules",
    localField: "deviceId",
    foreignField: "deviceId",
    justOne: true
  });
  return db.model(collection, schema);
}
exports.model = model;
