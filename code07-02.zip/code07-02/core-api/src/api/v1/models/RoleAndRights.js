/*jshint esversion: 8 */
const mongoose = require("mongoose");

function model(db, collection) {
  const schema = mongoose.Schema(
    {
      role: {
        //Kind of Name like "Developer/Manger/Admin"
        type: String,
        require: true
      },
      level: {
        type: String,
        require: true
      },
      alias: {
        type: String
      },
      rights: {
        type: Array,
        default: true
      }
    },
    {
      timestamps: true,
      strict: false
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
