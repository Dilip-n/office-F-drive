/*jshint esversion: 8 */
const mongoose = require("mongoose");
function model(db, collection) {
  const schema = mongoose.Schema(
    {
      name: { type: String, require: true },
      siteId: { type: String, require: true },
      lat: { type: String, require: true },
      lng: { type: String, require: true },
      address: { type: String, require: true },
      app: { type: mongoose.Schema.Types.ObjectId, require: false },
      metadata: { type: Object },
      parentId: { type: String }
      //deviceId: { type: mongoose.Schema.Types.ObjectId, require: false }
    },
    { timestamps: true, strict: false }
  );
  return db.model(collection, schema);
}
exports.model = model;
