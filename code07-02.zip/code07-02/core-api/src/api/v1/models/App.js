/*jshint esversion: 8 */
const mongoose = require("mongoose");
function model(db, collection) {
  const schema = mongoose.Schema(
    {
      name: { type: String, required: true },
      address: String,
      desc: String,
      solution: {
        _id: {
          type: mongoose.Schema.Types.ObjectId,
          require: true,
        },
        name: {
          type: String,
          require: true,
        },
      },
      metaData: {
        type: Object,
      },
      appId: {
        type: String,
        require: true,
      },
      internalId: {
        type: String,
        require: true,
      },
      addedBy: {
        type: mongoose.Schema.Types.ObjectId,
        // ref: "User"
      },
      customer: {
        type: mongoose.Schema.Types.ObjectId,
        // ref: "Customer"
      },
      url: String,
      status: {
        type: String,
        default: "Down",
      },
    },
    {
      timestamps: true,
      strict: false,
    }
  );
  return db.model(collection, schema);
}
exports.model = model;
