const kafka = require("kafka-node");
const config = require("../../../config");
const logger = require("./../utils/logger");

const client = new kafka.KafkaClient({
  kafkaHost: `${config.kafkaHost}:${config.kafkaPort}`,
});

const producer = new kafka.Producer(client);
//console.log("kafka producer ", producer);
producer.on("ready", function () {
  logger.info("Kafka is ready");
  kafkaReady = true;
});

producer.on("error", function (err) {
  logger.error("kafka error ", err);
});

function produce(payloads) {
  if (!producer.ready) {
    return;
  }
  producer.send(payloads, function (err, data) {
    //console.log("kafka payloads ", payloads);
    // logger.info("kafka inserted by data handler", data);
    if (err) {
      logger.error("Kafka error in data handler", err);
    }
    logger.info({
      type: "task successfully added by data handler",
      task_details: data,
    });
  });
}

module.exports = {
  produce,
};
