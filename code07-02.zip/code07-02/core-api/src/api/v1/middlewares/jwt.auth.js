/*jshint esversion: 8 */
const jwt = require("jsonwebtoken");
//Get JWT Signature
const jwtSignature = require("./../../../constants").jwtSecrets;

module.exports = function (resourceCode) {
  return function (req, res, next) {
    try {
      const token = req.header("auth-token");
      if (!token) {
        return res.status(401).json({
          success: false,
          error: {
            code: 41,
            msg: "No Token Provided",
          },
        });
      }
      //Verify JWT
      jwt.verify(token, jwtSignature.accessSecret, (err, user) => {
        if (err) {
          return res.status(403).json({
            success: false,
            error: {
              code: 41,
              msg: "Invalid token",
            },
          });
        }
        console.log("here");
        //Get rights
        const rights = user.rights;
        //Check if this user has the right to access this resource
        if (rights.includes(resourceCode)) {
          //Valid token and user also has rights
          req.user = user;
          next();
        } else {
          return res.status(401).json({
            success: false,
            error: {
              code: 41,
              msg: "Unauthorized Access!",
            },
          });
        }
      });
    } catch (err) {
      return res.status(401).json({
        success: false,
        error: {
          code: 41,
          msg: "Unable to verify your credentials.",
        },
      });
    }
  };
};
