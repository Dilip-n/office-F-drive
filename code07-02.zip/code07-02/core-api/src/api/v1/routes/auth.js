/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/auth.controller");

const router = express.Router();
const VerifyUser = require("../middlewares/jwt.auth");
router.route("/token").post(controller.getToken);
router.route("/logout").delete(controller.getLogout);
module.exports = router;
