/*jshint esversion: 8 */
const express = require("express");
const router = express.Router();

// import all the routes here
const ruleRoutes = require("./rule");
const customerRoutes = require("./customer");
const manufacturerRoutes = require("./manufacturer");
const userRoutes = require("./user");
const solutionRoutes = require("./solution");
const appRoutes = require("./app");
const siteRoutes = require("./site");
const deviceRoutes = require("./device");
const alertsRoutes = require("./alerts");
const keyRoutes = require("./key");
const userRolesRoutes = require("./user.roles");
const dataRoutes = require("./device.data");
const authRoutes = require("./auth");

//Index Status Check
router.get("/", (req, res, next) => {
  res.status(200).json({
    code: 20,
    msg: "Running",
  });
});

/**
 * Mount all the routes
 */
router.use("/rules", ruleRoutes);
router.use("/users", userRoutes);
router.use("/solutions", solutionRoutes);
router.use("/apps", appRoutes);
router.use("/sites", siteRoutes);
router.use("/devices", deviceRoutes);
router.use("/alerts", alertsRoutes);
router.use("/keys", keyRoutes);
router.use("/user-management", userRolesRoutes);
router.use("/data", dataRoutes);
router.use("/auth", authRoutes);
router.use("/customers", customerRoutes);
router.use("/manufacturers", manufacturerRoutes);

module.exports = router;
