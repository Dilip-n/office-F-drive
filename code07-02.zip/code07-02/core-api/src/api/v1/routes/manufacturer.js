/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/mfr.controller");
const router = express.Router();
//JWT and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
const { getMetaInfo } = require("../middlewares/user.auth");

//Get Manufacturer list - Resource ID - 101 (Same as CREATE APP as this will be used only then for now )
router
  .route("/?")
  .get(
    verifyUserAndCheckRights(101),
    getMetaInfo,
    controller.getAllManufacturers
  );
//Get Manufacturer's Model list - Resource ID - 101 (Same as CREATE APP as this will be used only then for now )
router
  .route("/:name/model?")
  .get(
    verifyUserAndCheckRights(101),
    getMetaInfo,
    controller.getAllManufacturerModels
  );
module.exports = router;
