/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/app.controller");
const router = express.Router();

//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo } = require("../middlewares/user.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
//Check License
const { checkLicense } = require("../middlewares/license.check");

//Routes
//Add Solutions - Resource ID - 102 - Not implemented
router.route("/").post(verifyUserAndCheckRights(102), controller.addSolution);

//Routes
//Add Solutions - Resource ID - 102 - Not implemented
router
  .route("/")
  .get(verifyUserAndCheckRights(102), getMetaInfo, controller.getSolution);

module.exports = router;
