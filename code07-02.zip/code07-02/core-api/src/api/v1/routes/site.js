/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/site.controller");

//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo } = require("../middlewares/user.auth");

const router = express.Router();
//Add site
router
  .route("/")
  .post(verifyUserAndCheckRights(301), getMetaInfo, controller.addSite); //Rajesh

//Get all Sites
router
  .route("/")
  .get(verifyUserAndCheckRights(302), getMetaInfo, controller.getAllSites); //Rajesh

//Get all Parent-child Sites
router
  .route("/parent-child")
  .get(
    verifyUserAndCheckRights(302),
    getMetaInfo,
    controller.getAllParentChildSites
  ); //Rajesh

//Get all Sites with out pagination
router
  .route("/all")
  .get(
    verifyUserAndCheckRights(302),
    getMetaInfo,
    controller.getAllSitesWithOutPagination
  ); //Rajesh

//Search Site
router.route("/search?").get(
  verifyUserAndCheckRights(302),
  getMetaInfo,
  controller.getSitesForSearch //Rajesh
);

//Update - Resource ID - 303
router
  .route("/:siteId")
  .patch(verifyUserAndCheckRights(303), getMetaInfo, controller.updateSite); //Rajesh

//Delete Site - Resource ID - 304
router
  .route("/:siteId")
  .delete(verifyUserAndCheckRights(304), getMetaInfo, controller.deleteSite); //Rajesh
module.exports = router;

//Get all child Sites for parentId
router
  .route("/childSites/:parentId")
  .get(verifyUserAndCheckRights(302), getMetaInfo, controller.getAllChildSites); //Rajesh
