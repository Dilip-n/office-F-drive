/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/device.controller");
const router = express.Router();

//JWT and user rights/apps check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
const { getMetaInfo, pgInfo } = require("../middlewares/user.auth");
//Check License
const { checkLicense } = require("../middlewares/license.check");

//Routes
//Save device - Resource ID - 201
router
  .route("/")
  .post(
    verifyUserAndCheckRights(201),
    getMetaInfo,
    checkLicense("device"),
    controller.addDevice
  );

//Get All devices - Resource ID - 202
router
  .route("/?")
  .get(verifyUserAndCheckRights(202), getMetaInfo, controller.getAllDevices);

//Delete One device - Resource ID - 204
router
  .route("/:deviceId")
  .delete(verifyUserAndCheckRights(204), getMetaInfo, controller.deleteDevice);

//Get one device info
router
  .route("/info/:deviceId")
  .get(
    verifyUserAndCheckRights(202),
    getMetaInfo,
    pgInfo,
    controller.getOneDevice
  );

router.route("/device-function-parser").post(controller.devicesFunction);

router
  .route("/to-site")
  .post(verifyUserAndCheckRights(201), getMetaInfo, controller.addDeviceToSite);
router
  .route("/search?")
  .get(
    verifyUserAndCheckRights(202),
    getMetaInfo,
    controller.getDevicesForSearch
  ); //Rajesh
router
  .route("/:deviceId/live-data")
  .get(verifyUserAndCheckRights(), controller.getDeviceLiveData);

//Search Mac Address - Resource Id - 201
router
  .route("/search/mac/:macAddress")
  .get(verifyUserAndCheckRights(201), getMetaInfo, controller.searchMac);

router
  .route("/:deviceId")
  .patch(verifyUserAndCheckRights(201), getMetaInfo, controller.updateDevice); //Auth Rajesh - 12-June-2020

router
  .route("/send-command")
  .post(verifyUserAndCheckRights(201), getMetaInfo, controller.sendCommand); //Auth Rajesh - 18-June-2020

router
  .route("/app/:appId/deviceType/:deviceType")
  .get(
    verifyUserAndCheckRights(201),
    getMetaInfo,
    controller.getAllDevicesForAppAndDeviceType
  );

// router.route('/test/one').get(verifyUserAndCheckRights(), controller.saveTOTSDB);

//Save device - Resource ID - 201
router
  .route("/bulk-upload")
  .post(verifyUserAndCheckRights(201), getMetaInfo, controller.addBulkDevice);

router
  .route("/commands/:deviceId")
  .get(
    verifyUserAndCheckRights(202),
    getMetaInfo,
    pgInfo,
    controller.getDeviceCommands
  ); //Auth Rajesh - 22-June-2020
module.exports = router;
