/*jshint esversion: 8 */
const express = require("express");
const controller = require("../controllers/alerts.controller");
const router = express.Router();

//Routes
//JWT Auth and user rights check
const verifyUserAndCheckRights = require("../middlewares/jwt.auth");
//After JWT Auth get the metaInfo like tenantDB, tenantID, apps etc
const { getMetaInfo, pgInfo } = require("../middlewares/user.auth");

//Get All the un-resolved alerts - Resource ID - 702
router
  .route("/")
  .get(
    verifyUserAndCheckRights(702),
    getMetaInfo,
    pgInfo,
    controller.getAllAlerts
  );

//Get All the resolved alerts - Resource ID - 702
router
  .route("/resolved")
  .get(
    verifyUserAndCheckRights(702),
    getMetaInfo,
    pgInfo,
    controller.getAllResolvedAlerts
  );

//Get graph data - Resource ID - 702
router
  .route("/graph-data")
  .get(
    verifyUserAndCheckRights(702),
    getMetaInfo,
    pgInfo,
    controller.getDataForAlertGraph
  );
//Get graph data - Resource ID - 702
router
  .route("/status/:alarmId")
  .patch(
    verifyUserAndCheckRights(702),
    getMetaInfo,
    pgInfo,
    controller.updateAlertStatus
  );
//Get search unresolved alerts - Resource ID - 702
router
  .route("/unresolved/search?")
  .get(
    verifyUserAndCheckRights(702),
    getMetaInfo,
    pgInfo,
    controller.getUnResolvedAlertsSearch
  );

//Get search resolved alerts - Resource ID - 702
router
  .route("/resolved/search?")
  .get(
    verifyUserAndCheckRights(702),
    getMetaInfo,
    pgInfo,
    controller.getResolvedAlertsSearch
  );
//Get search alerts - Resource ID - 702
router
  .route("/devices/:deviceId")
  .get(
    verifyUserAndCheckRights(702),
    getMetaInfo,
    pgInfo,
    controller.getDeviceAlerts
  );
module.exports = router;
