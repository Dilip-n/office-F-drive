/*jshint esversion: 8 */
'use strict';
const nodemailer = require('nodemailer');
class Mailers {
  constructor() {}
  async sendDBDownMail(data) {
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: 'mail.hyperthings.in',
      port: 465,
      secure: true, // true for 465, false for other ports
      auth: {
        user: 'nikhil@hyperthings.in', //
        pass: 'Nikhil@007' //
      }
    });
    // send mail with defined transport object
    let info = await transporter.sendMail({
      from: 'Nikhil Vats <nikhil@hyperthings.in>', // sender address
      to: 'nikhil@hyperthings.in', // list of receivers
      subject: 'MongoDB Server Down', // Subject line
      //text: "Mongo DB running at {port} on {server} is down.Please look into it.", // plain text body
      html: `<b>Mongo DB running at "PORT - ${data.port}" on "IP - ${data.ip}" is down. Please look into it.</b>` // html body
    });
    //console.log("Message sent: %s", info.messageId);
    return info;
  }
}
module.exports.Mailers = Mailers;
