/*jshint esversion: 8 */
const mongoose = require("mongoose");
const moment = require("moment");
require("moment-timezone");
const today = moment().tz("Asia/Kolkata").format();
const { tenantDbSuffix, pgdb } = require("./../../../constants");
//Require Util
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();
//PG DB connection
const pgConn = require("./../../../config/pgsql.config");

exports.DbLogger = async (
  user,
  tenantId,
  tenantDbName,
  tenantName,
  type,
  success,
  data
) => {
  try {
    //Get this tenant db - PGSQL
    const dbName = UtilFunctions.tenantPgDbName(tenantDbName);
    //Pg Connect
    const uri = `postgres://${pgdb.username}:${pgdb.password}@${pgdb.host}:${pgdb.port}/${dbName}`;
    const pgDbConn = await pgConn.connectDb(uri);

    try {
      //Add log
      const log = await pgDbConn.query(
        `INSERT INTO logs("userId", "userName", "tenantId", "tenantName", "type", "success", "data") VALUES($1, $2, $3, $4, $5, $6, $7)`,
        {
          bind: [
            user.userId,
            user.name,
            tenantId,
            tenantName,
            type,
            success,
            data,
          ],
        }
      );
      return true;
    } catch (err) {
      console.log(err);
      return false;
    }
  } catch (err) {
    return false;
  }
};
