/*jshint esversion: 8 */
const mongoose = require("mongoose");
const moment = require("moment");
require("moment-timezone");
const today = moment().tz("Asia/Kolkata").format();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { tenantDbSuffix, mongoDb } = require("./../../../constants");
const masterDb = mongoDb.masterDb;
//Mongo DB connection
const dbConn = require("./../../../config/express.config");
//Require User Model
const User = require("./../models/User");
//Require Auth Model
const Auth = require("./../models/Auth");
//Get JWT Signature
const jwtSignature = require("./../../../constants").jwtSecrets;
class AuthUtil {
  constructor() {}
  //JWT generate - accessToken
  generateAccessToken(user) {
    const accessToken = jwt.sign(user, jwtSignature.accessSecret, {
      expiresIn: "7d",
    });
    return accessToken;
  }
  //Generate refreshToken
  async generateRefreshToken(user) {
    const refreshToken = jwt.sign(user, jwtSignature.refreshSecret, {
      expiresIn: "7d",
    });
    const db = await dbConn.mongoDbConn.useDb("hts-iot-platform-v1");
    const AuthModel = await Auth.model(db, "auth");
    const token = new AuthModel({
      _id: new mongoose.Types.ObjectId(),
      token: refreshToken,
    });
    const tokenSaved = token
      .save()
      .then((result) => {
        return refreshToken;
      })
      .catch((err) => {
        return false;
      });
    return tokenSaved;
  }
  //JWT Verify - accessToken
  verifyAccessToken() {
    return true;
  }
  //JWT Verify - refreshToken
  verifyRefreshToken(refreshToken) {
    return jwt.verify(refreshToken, jwtSignature.refreshSecret, (err, user) => {
      if (err) {
        return {
          status: 403,
          msg: {
            success: false,
            error: {
              code: 43,
              msg: "Invalid token",
            },
          },
        };
      }
      //Get user's data from token, that will hepl in generating accessToken
      const userDetails = {
        email: user.email,
        userId: user.userId,
        type: user.type,
        name: user.name,
      };
      return {
        success: true,
        data: userDetails,
      };
    });
  }
  //Generate all JWT token
  async generateToken(data) {
    const token = jwt.sign(data, jwtSignature.tokenSecret);
    return token;
  }
}
// const fun = new Auth();
// console.log(fun.hello());
module.exports.AuthUtils = AuthUtil;
