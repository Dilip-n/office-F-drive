/*jshint esversion: 8 */
const mongoose = require("mongoose");
const moment = require("moment");
require("moment-timezone");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { mongoDb } = require("./../../../constants");
const masterDb = mongoDb.masterDb;
//Require User Model
const User = require("./../models/User");
//Require Auth Model
const Auth = require("./../models/Auth");
let { AuthUtils } = require("./../utils/auth");
AuthUtils = new AuthUtils();
//Token generation
exports.getToken = async (req, res) => {
  //Get refreshToken
  const refreshToken = req.body.token;
  const db = await dbConn.mongoDbConn.useDb("hts-iot-platform-v1");
  const AuthModel = await Auth.model(db, "auth");
  AuthModel.find({
    token: refreshToken
  })
    .exec()
    .then(authToken => {
      if (!authToken.length > 0) {
        return res.status(403).json({
          success: false,
          error: {
            code: 43,
            msg: "Invalid token !"
          }
        });
      } else {
        //Verify refreshToken
        const verify = AuthUtils.verifyRefreshToken(refreshToken);
        //If Verified
        if (verify.success) {
          const accessToken = AuthUtils.generateAccessToken(verify.data);
          return (
            res
              .status(200)
              //access-token
              .header("auth-token", accessToken)
              .json({
                success: true,
                data: {
                  code: 20,
                  msg: "Token",
                  results: {}
                }
              })
          );
        } else {
          return res.status(verify.status).json(verify.msg);
        }
      }
    })
    .catch(err => {
      console.log(err);
      return res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: err
        }
      });
    });
};

//Logout
exports.getLogout = async (req, res) => {
  try {
    //Get refreshToken
    const refreshToken = req.body.token;
    const db = await dbConn.mongoDbConn.useDb("hts-iot-platform-v1");
    const AuthModel = await Auth.model(db, "auth");
    const tokenFound = AuthModel.findOne({
      token: refreshToken
    })
      .then(async authToken => {
        if (authToken) {
          const deleted = await authToken.deleteOne();
          if (deleted) {
            //We can just send 204 status or
            return res.status(200).json({
              suceess: true,
              data: {
                code: 20,
                msg: "Logout Successfully!"
              }
            });
          }
        } else {
          return res.status(403).json({
            success: false,
            error: {
              code: 43,
              msg: "Invalid token !"
            }
          });
        }
      })
      .catch(err => {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error",
            error: err
          }
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err
      }
    });
  }
};
