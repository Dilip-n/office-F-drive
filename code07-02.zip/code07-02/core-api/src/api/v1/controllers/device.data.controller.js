/*jshint esversion: 8 */
const mongoose = require("mongoose");
const Sequelize = require("sequelize");
const moment = require("moment");
const underscore = require("underscore");
const Axios = require("axios");
require("moment-timezone");
const { mongoDb, promEndpoint } = require("./../../../constants");
//Get master db name
const masterDb = mongoDb.masterDb;
//Require App Model
const App = require("../models/App");
//Require User Model
const User = require("../models/User");
//Require Site Model
const Site = require("../models/Site");
//Require Device Model
const Device = require("../models/Device");
//Require Rule Model
const Rule = require("../models/Rule");
//Require DeviceProfile Model
const DeviceProfile = require("./../models/DeviceProfile");
//Require Device Manufacturer Model
const DeviceMfr = require("./../models/Manufacturer");
//Require Data Model
const DeviceData = require("../models/PgDeviceData");
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();

//Get latest one live data for each site of an App
exports.getAppLiveData = async (req, res) => {
  const db = await dbConn.mongoDbConn.useDb("FF7JnP-tenant-db");
  let DataModel;
  let lookup;
  //For E Metering App
  if (req.params.appId && req.params.appId === "5d91a407a606d2461d304974") {
    DataModel = Data.model(db, "f72tkx.device.livedatas");
    lookup = {
      from: "f72tkx.sites",
      localField: "siteId",
      foreignField: "_id",
      as: "site",
    };
  } else {
    //For Condition monitoring
    DataModel = Data.model(db, "t7gca9.device.livedatas");
    lookup = {
      from: "t7gca9.sites",
      localField: "siteId",
      foreignField: "_id",
      as: "site",
    };
  }

  const pipeline = [
    {
      $sort: {
        updatedAt: -1,
      },
    },
    {
      $group: {
        _id: "$site_id",
        data: {
          $push: {
            appId: "$app_id",
            siteId: "$site_id",
            deviceId: "$device_id",
            data: "$data",
            updatedAt: "$updatedAt",
            createdAt: "$createdAt",
          },
        },
      },
    },
    {
      $replaceRoot: {
        newRoot: {
          $arrayElemAt: ["$data", 0],
        },
      },
    },
    {
      $sort: {
        updatedAt: -1,
      },
    },
    {
      $lookup: lookup,
    },
    {
      $project: {
        appId: 1,
        deviceId: 1,
        data: 1,
        site: {
          $arrayElemAt: ["$site", 0],
        },
        updatedAt: 1,
        createdAt: 1,
      },
    },
  ];
  const data = await DataModel.aggregate(pipeline);
  const results = {
    count: data.length,
    records: data,
  };
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results,
    },
  };
  return res.status(200).send(response);
};
//Get all live data for each site of an App
exports.getAppSiteLiveData = async (req, res) => {
  let DataModel;
  let SiteModel;
  let appId;
  const db = await dbConn.mongoDbConn.useDb("FF7JnP-tenant-db");
  //For E Metering App
  if (req.params.appId && req.params.appId === "5d91a407a606d2461d304974") {
    DataModel = Data.model(db, "f72tkx.device.livedatas");
    SiteModel = Site.model(db, "f72tkx.sites");
    appId = "5d91a407a606d2461d304974";
  } else {
    DataModel = Data.model(db, "t7gca9.device.livedatas");
    SiteModel = Site.model(db, "t7gca9.sites");
    appId = "5d65149ac073600a98827377";
  }

  //Get site data
  const siteData = await SiteModel.findOne({
    _id: mongoose.Types.ObjectId(req.params.siteId),
  });
  const data = await DataModel.find({
    site_id: mongoose.Types.ObjectId(req.params.siteId),
  }).select("-site_id -app_id");

  const results = {
    count: data.length,
    appId: appId,
    site: siteData,
    deviceDatas: data.map((doc) => {
      return {
        _id: doc._id,
        deviceId: doc.device_id,
        data: doc.data,
        updatedAt: doc.updatedAt,
        createdAt: doc.createdAt,
      };
    }),
  };
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results,
    },
  };
  return res.status(200).send(response);
};
//Get todays date having device parameter formatted in array
exports.getAppSiteDeviceData = async (req, res) => {
  let DataModel;
  let SiteModel;
  let pipeline;
  //Get Query string
  let date = req.query.date;
  const db = await dbConn.mongoDbConn.useDb("FF7JnP-tenant-db");
  //For E Metering App
  if (req.params.appId && req.params.appId === "5d91a407a606d2461d304974") {
    DataModel = Data.model(db, "f72tkx.device.datas");
    SiteModel = Site.model(db, "f72tkx.sites");
    pipeline = [
      {
        $sort: {
          updatedAt: -1,
        },
      },
      {
        $project: {
          date: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$updatedAt",
            },
          },
          document: "$$ROOT",
        },
      },
      {
        $match: {
          date: today,
        },
      },
      {
        $project: {
          frequency: "$document.data.Frequency",
          current: "$document.data.Current",
          voltage: "$document.data.VLN",
          powerFactor: "$document.data.PF",
          energy: "$document.data.Wh_received",
          runHour: "$document.data.VAh_received",
          updatedAt: "$document.updatedAt",
        },
      },
      {
        $group: {
          _id: null,
          frequency: {
            $push: "$frequency",
          },
          current: {
            $push: "$current",
          },
          voltage: {
            $push: "$voltage",
          },
          powerFactor: {
            $push: "$powerFactor",
          },
          energy: {
            $push: "$energy",
          },
          runHour: {
            $push: "$runHour",
          },
          updatedAt: {
            $push: "$updatedAt",
          },
        },
      },
      {
        $project: {
          _id: 0,
          frequency: 1,
          current: 1,
          voltage: 1,
          powerFactor: 1,
          energy: 1,
          runHour: 1,
          updatedAt: 1,
        },
      },
    ];
  } else {
    DataModel = Data.model(db, "t7gca9.device.datas");
    SiteModel = Site.model(db, "t7gca9.sites");
    appId = "5d65149ac073600a98827377";
    pipeline = [
      {
        $sort: {
          updatedAt: -1,
        },
      },
      {
        $project: {
          date: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$updatedAt",
            },
          },
          document: "$$ROOT",
        },
      },
      {
        $match: {
          date: "2019-09-27",
        },
      },
      {
        $project: {
          temp: "$document.data.temp",
          vd: "$document.data.vd",
          humidity: "$document.data.humidity",
          pressure: "$document.data.pressure",
          velocity: "$document.data.velocity",
          gyro: "$document.data.gyro",
          updatedAt: "$document.updatedAt",
        },
      },
      {
        $group: {
          _id: null,
          temp: {
            $push: "$temp",
          },
          vd: {
            $push: "$vd",
          },
          humidity: {
            $push: "$humidity",
          },
          pressure: {
            $push: "$pressure",
          },
          velocity: {
            $push: "$velocity",
          },
          gyro: {
            $push: "$gyro",
          },
          updatedAt: {
            $push: "$updatedAt",
          },
        },
      },
      {
        $project: {
          _id: 0,
          temp: 1,
          vd: 1,
          humidity: 1,
          pressure: 1,
          velocity: 1,
          gyro: 1,
          updatedAt: 1,
        },
      },
    ];
  }

  const data = await DataModel.aggregate(pipeline);
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results: data,
    },
  };
  return res.status(200).send(response);
};
//Get history of data
exports.getData = async (req, res) => {
  //Check if query string exists
  const input = underscore.isEmpty(req.query);
  if (input) {
    return res.status(409).json({
      success: false,
      error: {
        code: 51,
        msg: "Something went wrong !",
      },
    });
  }
  //Check site and device details from query string
  const sites = req.query.sites;
  const devices = req.query.devices;
  //Get start and end date from query string
  const startDate = req.query.from;
  const endDate = req.query.to;
  let DataModel;
  //For Condition monitoring and E metering db configuration is static
  const db = await dbConn.mongoDbConn.useDb("FF7JnP-tenant-db");
  //For E Metering App
  if (req.params.appId && req.params.appId === "5d91a407a606d2461d304974") {
    DataModel = Data.model(db, "f72tkx.device.datas");
  } else {
    DataModel = Data.model(db, "t7gca9.device.datas");
    // const SiteModel = Data.model(db, 't7gca9.sites');
    //Get site data
    // const siteData = await SiteModel.findOne({
    //   _id: mongoose.Types.ObjectId(req.params.siteId)
    // });
  }

  const pipeline = [
    {
      $sort: {
        updatedAt: -1,
      },
    },
    {
      $project: {
        date: {
          $dateToString: {
            format: "%Y-%m-%d",
            date: "$updatedAt",
          },
        },
        document: "$$ROOT",
      },
    },
    {
      $match: {
        date: {
          $gte: startDate,
          $lte: endDate,
        },
      },
    },
    {
      $project: {
        data: "$document",
      },
    },
  ];

  const data = await DataModel.aggregate(pipeline);
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results: data,
    },
  };
  return res.status(200).send(response);
};
//Generate last 3 month data
exports.generateThreeMData = async (req, res) => {
  //const currentDate = moment().unix();
  // const x = moment()
  //   .subtract(1, 'months')
  //   .format();
  // console.log(currentDate);
  // console.log(x);
  // let i = 3;
  // while (
  //   currentDate >
  //   moment()
  //     .add(i, 'months')
  //     .unix()
  // ) {
  //   console.log(i);
  //   i++;
  // }
  try {
    const db = await dbConn.mongoDbConn.useDb(masterDb);
    const UserModel = await User.model(db, "user");
    //Get user id
    const user = req.user;
    //Add Custom App schema in user model for tenant type
    UserModel.schema.add({
      applications: [mongoose.Schema.Types.ObjectId],
    });
    //Format result
    let data = [];
    //Check if user exists
    UserModel.findOne({
      _id: user.userId,
    })
      .then(async (user) => {
        if (!user) {
          return res.status(404).json({
            success: false,
            error: {
              code: 44,
              msg: "User does not exists !",
            },
          });
        }
        //Check if this user has some assigned App
        if (!user.applications.length > 0) {
          return res.status(200).json({
            success: false,
            data: {
              code: 49,
              msg: "User has no App assigned !",
              results: [],
            },
          });
        }
        //Get this tenant db
        const dbName = UtilFunctions.tenantDbName(
          user.username,
          tenantDbSuffix
        );
        if (!dbName) {
          return res.status(400).json({
            success: false,
            error: {
              code: 40,
              msg: "Something went wrong !",
            },
          });
        }
        //Use tenant db
        const db1 = await dbConn.mongoDbConn.useDb(dbName);
        //Get all the app details form tenant db
        const ApplicationModel = App.model(db1, "app");
        const apps = await ApplicationModel.find({
          _id: {
            $in: user.applications,
          },
        }).select("internal_id app_id name");

        /* Promise all promises*/
        const promises = apps.map(async (val, idx) => {
          //Get collection name for the device
          const collection = UtilFunctions.collectionName(
            val.internal_id,
            "device"
          );
          //Get device Model
          const DeviceModel = await Device.model(db1, collection);
          //Laste 7 days
          const range = moment().subtract(7, "days").format("YYYY-MM-DD");
          //Using query
          // const devices = await DeviceModel.find({
          //   created_at: { $gte: range }
          // }).select('-__v');

          //Using aggregate
          const pipeline = [
            {
              $project: {
                date: {
                  $dateToString: {
                    format: "%Y-%m-%d",
                    date: "$created_at",
                  },
                },
                year: {
                  $year: "$created_at",
                },
                document: "$$ROOT",
              },
            },
            {
              $match: {
                date: {
                  $gte: range,
                },
              },
            },
            {
              $group: {
                _id: {
                  year: {
                    $year: "$document.created_at",
                  },
                  month: {
                    $month: "$document.created_at",
                  },
                  day: {
                    $dayOfMonth: "$document.created_at",
                  },
                },
                count: {
                  $sum: 1,
                },
              },
            },
            {
              $project: {
                date: {
                  $dateFromParts: {
                    year: "$_id.year",
                    month: "$_id.month",
                    day: "$_id.day",
                  },
                },
                count: 1,
                _id: 0,
              },
            },
          ];

          const deviceCount = await DeviceModel.aggregate(pipeline);
          // return res.send(data);
          //Push the device data to data array
          data.push({
            deviceCount,
          });
        });

        await Promise.all(promises);
        return data;
      })
      .then((result) => {
        //If there is no device
        if (!result.length > 0) {
          const response = {
            success: false,
            data: {
              code: 20,
              msg: "No device found !",
              results: [],
            },
          };
          return res.status(200).send(response);
        }

        //If some device found
        const results = {
          device: result,
        };
        const response = {
          success: true,
          data: {
            code: 20,
            msg: "Devices found",
            results,
          },
        };
        return res.status(200).send(response);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error",
            error: err,
          },
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get data consumption of last 6 month data
exports.getDataConsumption = async (req, res) => {
  /*Static datas
   */
  //Month array
  let months = [];
  //Last 6 months
  for (let index = 1; index < 7; index++) {
    const month = moment().subtract(index, "months").format("MMMM");
    months.push(month);
  }

  const data = {
    transmitted: [36, 12, 5, 25, 36, 24],
    received: [19, 80, 67, 45, 79, 65],
    months: months,
  };
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results: data,
    },
  };
  return res.status(200).send(response);
  /*Realtime data

*/
};
//Get recently addeed devices
exports.getRecentAddedDev = async (req, res) => {
  /*Static datas
   */
  //Date array
  let days = [];
  //Last 7 days
  for (let index = 1; index < 8; index++) {
    const day = moment().subtract(index, "days").format("dddd");
    days.push(day);
  }

  const data = {
    devices: [36, 12, 5, 25, 36, 24, 8],
    days: days.reverse(),
  };
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results: data,
    },
  };
  return res.status(200).send(response);

  /*Realtime data

*/
};
//Get login users
exports.getLoginUsers = async (req, res) => {
  /*Static datas
   */
  //Date array
  let days = [];
  //Last 7 days
  for (let index = 1; index < 8; index++) {
    const day = moment().subtract(index, "days").format("dddd");
    days.push(day);
  }

  const data = {
    users: [10, 2, 5, 1, 6, 7, 5],
    admin: [1, 0, 7, 1, 3, 8, 1],
    superAdmin: [1, 3, 4, 1, 2, 8, 1],
    days: days.reverse(),
  };
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results: data,
    },
  };
  return res.status(200).send(response);

  /*Realtime data

*/
};
//Get most logged in users
exports.getMostLoggedinUsers = async (req, res) => {
  /*Static datas
   */
  //Month array
  let months = [];
  //Last 6 months
  for (let index = 1; index < 7; index++) {
    const month = moment().subtract(index, "months").format("MMMM");
    months.push(month);
  }

  const data = {
    users: [63, 70, 25, 18, 36, 39],
    admin: [1, 12, 7, 12, 34, 8, 1],
    superAdmin: [19, 30, 4, 9, 24, 18, 10],
    months: months,
  };
  const response = {
    success: true,
    data: {
      code: 20,
      msg: "Records found",
      results: data,
    },
  };
  return res.status(200).send(response);
  /*Realtime data

*/
};

//Get reports
exports.getReports = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    //Get appId, deviceId, deviceType, dateRanges
    const appId = req.params.appId;
    const deviceId = req.params.deviceId;
    const deviceType = req.query.deviceType;
    const fromDate = req.query.fromDate;
    const toDate = req.query.toDate;
    //Get report type
    const reportType = req.query.reportType;
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    //Get DeviceData Model
    const DeviceDataModel = DeviceData.model(pgConn, "device_data");
    //Check if user has this app
    let appCheck = false;
    if (appIds.some((item) => item._id == appId)) {
      appCheck = true;
    }
    if (!appCheck) {
      //App does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "App does not exists !",
        },
      });
    }
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Device Profile Model
    const DeviceProfileModel = await DeviceProfile.model(
      tenantDb,
      "device.profiles"
    );
    //Device Manufacturer Model
    const DeviceMfrModel = await DeviceMfr.model(tenantDb, "mfr.models");
    //Check if device ID exists - in tenant DB
    const deviceCheck = await DeviceModel.findOne({
      _id: deviceId,
      app: appId,
    }).populate({
      path: "mfrId",
      select: "deviceProfiles",
      model: DeviceMfrModel,
    });

    //Check for valid deviceId
    if (
      !deviceCheck ||
      !deviceCheck.mfrId ||
      !deviceCheck.mfrId.deviceProfiles ||
      deviceType in deviceCheck.mfrId.deviceProfiles === false
    ) {
      //App does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Device or DeviceType does not exists !",
        },
      });
    }

    //Get deviceId - numeric - for Postgres
    const pgDeviceId = deviceCheck.deviceId;

    //Define data and column
    let columns = [];
    let data = [];

    /*
    ! Raw data report function
    */
    getRawDataReport = async () => {
      //Check if deviceType available
      let rawDataSchema = {};

      const profileId = deviceCheck.mfrId.deviceProfiles[deviceType];

      const profileCheck = await DeviceProfileModel.findById(profileId);
      //Check for valid deviceProfileId
      if (!profileCheck || !profileCheck.dataSchema) {
        //Schema does not exists
        return res.status(404).json({
          success: false,
          error: {
            code: 44,
            msg: "Data schema not available for given device type !",
          },
        });
      }
      //Set dataSchema
      rawDataSchema = profileCheck.dataSchema;

      //Get attributes - call `flatten` helper method from UtilFunctions
      getAttributes = (schema, otherSchema = {}, time = { time: "" }) => {
        let attributes = [];
        Object.keys(UtilFunctions.flatten(schema)).map((attribute) => {
          attributes.push([
            Sequelize.literal(attribute),
            attribute.replace(/->/g, ".").replace(/'/g, ""),
          ]);
        });
        //If other fileds are provided
        Object.keys(otherSchema).map((attribute) => {
          attributes.push([
            Sequelize.literal(attribute),
            attribute.replace(/->/g, ".").replace(/'/g, ""),
          ]);
        });
        Object.keys(time).map((attribute) => {
          attributes.push([
            Sequelize.fn(
              "to_char",
              Sequelize.col("time"),
              "DD-MON-YYYY HH24:MI:SS AM"
            ),
            "time",
          ]);
        });
        return attributes;
      };

      //Add other columns of device_data table
      let otherFields = {
        //time column is being passed directy in funciton
        id: "",
        time: "",
        device_id: "",
        device_type: "",
        size: "",
        data_from: "",
      };

      const { and } = Sequelize.Op;
      //Run the query
      const rawData = await DeviceDataModel.findAll({
        raw: true,
        attributes: getAttributes(rawDataSchema, otherFields),
        where: {
          [and]: [
            { device_type: deviceType },
            { device_id: pgDeviceId },
            Sequelize.where(
              Sequelize.fn("date", Sequelize.col("time")),
              ">=",
              fromDate
            ),
            Sequelize.where(
              Sequelize.fn("date", Sequelize.col("time")),
              "<=",
              toDate
            ),
          ],
        },
      });
      //Get columns - form Util function
      columns = UtilFunctions.getColumns(rawDataSchema, otherFields);

      //Format the response
      if (rawData.length > 0) {
        console.log(rawData);
        rawData.map((row) => {
          let oneSet = [];

          columns.map((column) => {
            oneSet.push(row[column]);
          });
          data.push(oneSet);
        });
      } else {
        columns = [];
      }
      //return data and schema
      // return { data, columns };
    };

    /*
    ! Rule event report function
    */
    getRuleEventReport = async () => {
      //Rule Model
      const RuleModel = await Rule.model(tenantDb, "rules");
      //Find rules
      const rules = await RuleModel.find({
        app: appId,
        deviceId: pgDeviceId,
        deviceType: deviceType,
      }).select("_id");

      //When no alerts
      if (rules.length < 1) {
        return res.status(200).send({
          success: false,
          data: {
            code: 20,
            msg: "No Rules found !",
            results: [],
          },
        });
      }
      let ruleIds = [];
      rules.map((id) => {
        //Convert the mongo _id type to string
        ruleIds.push(id._id.toString());
      });

      //Get PG Connection
      const pgConn = req.metaPgObj.tenantDb;
      const alerts = await pgConn.query(
        "SELECT *, to_char(time, :timeFormat) as time FROM device_events where event_type=:event_type and rule_id IN(:ids) and Date(time) >= :fromDate and Date(time) <= :toDate ORDER BY to_char(time, :timeFormat) DESC",
        {
          replacements: {
            event_type: "RULE_VALUE",
            ids: ruleIds,
            timeFormat: "DD-MON-YYYY HH24:MI:SS AM",
            fromDate,
            toDate,
          },
          type: pgConn.QueryTypes.SELECT,
        }
      );

      /*
        Query to get column names of a table
        "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'device_events'",
      */
      //Add columns of device_events table
      let fields = {
        id: "",
        time: "",
        device_id: "",
        device_type: "",
        event_type: "",
        rule_id: "",
        value: "",
        severity: "",
      };
      //Get columns - form Util function
      columns = UtilFunctions.getColumns({}, fields);

      //Format the response
      if (alerts.length > 0) {
        alerts.map((row) => {
          let oneSet = [];

          columns.map((column) => {
            oneSet.push(row[column]);
          });
          data.push(oneSet);
        });
      } else {
        columns = [];
      }
    };

    /*
    ! Rule event report function
    */
    getStatusEventReport = async () => {
      //Get PG Connection
      const pgConn = req.metaPgObj.tenantDb;
      const alerts = await pgConn.query(
        "SELECT *, to_char(time, :timeFormat) as time FROM device_events where device_id=:deviceId and device_type=:deviceType and event_type IN(:connTypes) and Date(time) >= :fromDate and Date(time) <= :toDate ORDER BY to_char(time, :timeFormat) DESC",
        {
          replacements: {
            connTypes: ["CONNECT", "DISCONNECT"],
            deviceId: pgDeviceId,
            deviceType,
            timeFormat: "DD-MON-YYYY HH24:MI:SS AM",
            fromDate,
            toDate,
          },
          type: pgConn.QueryTypes.SELECT,
        }
      );

      /*
        Query to get column names of a table
        "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'device_events'",
      */
      //Add columns of device_events table
      let fields = {
        id: "",
        time: "",
        device_id: "",
        device_type: "",
        event_type: "",
      };
      //Get columns - form Util function
      columns = UtilFunctions.getColumns({}, fields);

      //Format the response
      if (alerts.length > 0) {
        alerts.map((row) => {
          let oneSet = [];

          columns.map((column) => {
            oneSet.push(row[column]);
          });
          data.push(oneSet);
        });
      } else {
        columns = [];
      }
    };

    /*

    !Based on reportType execute diffrent type of query and fetch from respective collection
  

    */
    //If reportType is raw data
    if (reportType === "rawData") {
      await getRawDataReport();
    } else if (reportType === "ruleEvent") {
      await getRuleEventReport();
    } else if (reportType === "statusEvent") {
      await getStatusEventReport();
    }

    //Send response
    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        results: {
          columns,
          data,
        },
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get device messages count to graph for current month
//Author - Rajesh
//Editor - Nikhil
exports.deviceMessagesCountGraph = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");

    //Get all the deviceId for appId
    const devices = await DeviceModel.find({ app: appIds });
    if (devices.length < 1) {
      return res.status(404).json({
        success: false,
        data: {
          code: 50,
          msg: "Devices not found",
        },
      });
    }
    let deviceIds = [];
    devices.map(async (device) => {
      //Push
      deviceIds.push(device.deviceId);
    });

    //Get all dates in current month
    //let startDateOfMonth = moment().startOf("month").format("YYYY-MM-DD");
    //let endDateOfMonth = moment().endOf("month").format("YYYY-MM-DD");
    let queryDays = 6;
    let days = req.query.days;

    if (days) {
      queryDays = parseInt(days) - 1;
    }

    let now = moment();
    let currentDate = moment(now, "YYYY-MM-DD");
    let end = moment(currentDate).format("YYYY-MM-DD");
    let start = moment(end).add(-`${queryDays}`, "days").format("YYYY-MM-DD"); //Set range

    console.log("start date ", start);
    console.log("end end ", end);

    function enumerateDaysBetweenDates(startDate, endDate) {
      let date = [];
      while (moment(startDate) <= moment(endDate)) {
        date.push(startDate);
        startDate = moment(startDate).add(1, "days").format("YYYY-MM-DD");
      }
      return date;
    }

    const datesList = enumerateDaysBetweenDates(start, end);

    let deviceMessages = await pgConn.query(
      `select count(size), Date(time) from device_data where device_id IN(:deviceIds) and Date(time) >=:start  AND Date(time) <=:end  GROUP BY Date(time) ORDER By Date(time)`,
      {
        replacements: {
          deviceIds,
          start: start,
          end: end,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    let result = {};
    let dataMessages = [];

    deviceMessages.map(async (data) => {
      let obj = {
        count: parseInt(data.count),
        date: data.date,
      };
      dataMessages.push(obj);
    });
    //map data for date mis match
    datesList.map(async (data) => {
      const found = dataMessages.some((el) => el.date === data);
      if (!found) {
        dataMessages.push({ count: 0, date: data });
      }
    });
    //Sort by date
    dataMessages = dataMessages.sort(function (a, b) {
      return Number(new Date(a.date)) - Number(new Date(b.date));
    });
    //=========================================================================

    result.datesList = datesList;
    result.messages = dataMessages;

    return res.status(200).json({
      success: deviceMessages.length > 0 ? true : false,
      data: {
        code: 20,
        msg: deviceMessages.length > 0 ? "Records found" : "No records found",
        results: result,
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get device messages sum to graph for current month
//Auth - Rajesh
exports.deviceMessagesSumGraph = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");

    //Get all the deviceId for appId
    const devices = await DeviceModel.find({ app: appIds });
    if (devices.length < 1) {
      return res.status(404).json({
        success: false,
        data: {
          code: 50,
          msg: "Devices not found",
        },
      });
    }
    let deviceIds = [];
    devices.map(async (device) => {
      //Push
      deviceIds.push(device.deviceId);
    });

    //Get all dates in current month
    //let startDateOfMonth = moment().startOf("month").format("YYYY-MM-DD");
    //let endDateOfMonth = moment().endOf("month").format("YYYY-MM-DD");

    let queryDays = 6;
    let days = req.query.days;

    if (days) {
      queryDays = parseInt(days) - 1;
    }

    let now = moment();
    let currentDate = moment(now, "YYYY-MM-DD");
    let end = moment(currentDate).format("YYYY-MM-DD");
    let start = moment(end).add(-`${queryDays}`, "days").format("YYYY-MM-DD"); //Set range

    console.log("start date ", start);
    console.log("end end ", end);

    function enumerateDaysBetweenDates(startDate, endDate) {
      let date = [];
      while (moment(startDate) <= moment(endDate)) {
        date.push(startDate);
        startDate = moment(startDate).add(1, "days").format("YYYY-MM-DD");
      }
      return date;
    }

    const datesList = enumerateDaysBetweenDates(start, end);

    let deviceMessagesSize = await pgConn.query(
      `select sum(size), Date(time) from device_data where device_id IN(:deviceIds) and Date(time) >=:start  AND Date(time) <=:end GROUP BY Date(time) ORDER By Date(time)`,
      {
        replacements: {
          deviceIds,
          start: start,
          end: end,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    let result = {};
    let dataMessagesSize = [];

    deviceMessagesSize.map(async (data) => {
      let obj = {
        size: parseInt(data.sum),
        date: data.date,
      };
      dataMessagesSize.push(obj);
    });
    //map data for date mis match
    datesList.map(async (data) => {
      const found = dataMessagesSize.some((el) => el.date === data);
      if (!found) {
        dataMessagesSize.push({ size: 0, date: data });
      }
    });
    //Sort by date
    dataMessagesSize = dataMessagesSize.sort(function (a, b) {
      return Number(new Date(a.date)) - Number(new Date(b.date));
    });
    //=========================================================================

    result.datesList = datesList;
    result.size = dataMessagesSize;

    return res.status(200).json({
      success: deviceMessagesSize.length > 0 ? true : false,
      data: {
        code: 20,
        msg:
          deviceMessagesSize.length > 0 ? "Records found" : "No records found",
        results: result,
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get no of alerts/day for current month to graph
//Auth - Rajesh
exports.alertsPerDayGraph = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");

    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    console.log("ruleIds ", ruleIds);

    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");

    //Get all the deviceId for appId
    const devices = await DeviceModel.find({ app: appIds });
    if (devices.length < 1) {
      return res.status(404).json({
        success: false,
        data: {
          code: 50,
          msg: "Devices not found",
        },
      });
    }
    let deviceIds = [];
    devices.map(async (device) => {
      //Push
      deviceIds.push(device.deviceId);
    });
    //Get all dates in current month
    let startDateOfMonth = moment().startOf("month").format("YYYY-MM-DD");
    let endDateOfMonth = moment().endOf("month").format("YYYY-MM-DD");

    function enumerateDaysBetweenDates(startDate, endDate) {
      let date = [];
      while (moment(startDate) <= moment(endDate)) {
        date.push(startDate);
        startDate = moment(startDate).add(1, "days").format("YYYY-MM-DD");
      }
      return date;
    }

    const datesList = enumerateDaysBetweenDates(
      startDateOfMonth,
      endDateOfMonth
    );

    let deviceAlerts = await pgConn.query(
      `select count(time), Date(time) from device_events where event_type=:event_type and device_id IN(:deviceIds) and rule_id IN(:ids) and  Date(time) >=:start  AND Date(time) <=:end GROUP BY Date(time) ORDER By Date(time)`,
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
          deviceIds,
          start: startDateOfMonth,
          end: endDateOfMonth,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    let result = {};

    let deviceAlertsCounts = [];

    deviceAlerts.map(async (data) => {
      let obj = {
        count: parseInt(data.count),
        date: data.date,
      };
      deviceAlertsCounts.push(obj);
    });
    //Map the quired data, and fill the arry with dates not matching
    datesList.map(async (data) => {
      const found = deviceAlertsCounts.some((el) => el.date === data);
      if (!found) {
        deviceAlertsCounts.push({ count: 0, date: data });
      }
    });
    //Sort by date
    deviceAlertsCounts = deviceAlertsCounts.sort(function (a, b) {
      return Number(new Date(a.date)) - Number(new Date(b.date));
    });
    //=========================================================================

    result.datesList = datesList;
    result.alerts = deviceAlertsCounts;

    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: deviceAlerts.length > 0 ? "Records found" : "No records found",
        results: result,
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get get events count (resolved and un-resolved)
//Auth - Rajesh
exports.eventStatusCount = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");

    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });

    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;

    let unResolvedAlerts = await pgConn.query(
      `select count(resolved) from device_events where resolved ='false' and rule_id IN(:ids) and event_type=:event_type`,
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    let resolvedAlerts = await pgConn.query(
      `select count(resolved) from device_events where resolved ='true' and rule_id IN(:ids) and event_type=:event_type`,
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    let result = {};

    result.unresolved = parseInt(unResolvedAlerts[0].count);
    result.resolved = parseInt(resolvedAlerts[0].count);
    result.total = result.unresolved + result.resolved;
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: result ? "Records found" : "No records found",
        results: result,
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get events severity (high, medium and low) count of current month Dashboard Graph -Auth Rajesh
exports.severityDashboardGraph = async (req, res) => {
  try {
    /*

    */

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");

    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    console.log("ruleIds ", ruleIds);
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    //Common function to query
    async function getSeverity(query, level, startDateOfMonth, endDateOfMonth) {
      let severityData = await pgConn.query(query, {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
          level: level,
          start: startDateOfMonth,
          end: endDateOfMonth,
        },
        type: pgConn.QueryTypes.SELECT,
      });
      return severityData;
    }

    //let startDateOfMonth = moment().startOf("month").format("YYYY-MM-DD");
    //let endDateOfMonth = moment().endOf("month").format("YYYY-MM-DD");

    let queryDays = 6;
    let days = req.query.days;

    if (days) {
      queryDays = parseInt(days) - 1;
    }

    let now = moment();
    let currentDate = moment(now, "YYYY-MM-DD");
    let end = moment(currentDate).format("YYYY-MM-DD");
    let start = moment(end).add(-`${queryDays}`, "days").format("YYYY-MM-DD"); //Set range

    console.log("start date ", start);
    console.log("end end ", end);

    function enumerateDaysBetweenDates(startDate, endDate) {
      let date = [];
      while (moment(startDate) <= moment(endDate)) {
        date.push(startDate);
        startDate = moment(startDate).add(1, "days").format("YYYY-MM-DD");
      }
      return date;
    }

    const datesList = enumerateDaysBetweenDates(start, end);

    let q =
      "SELECT count(severity), Date(time) FROM device_events where event_type=:event_type and rule_id IN(:ids) and  Date(time) >=:start  AND Date(time) <=:end and severity=:level GROUP BY Date(time)";
    //
    const high = await getSeverity(q, 3, start, end);
    const medium = await getSeverity(q, 2, start, end);
    const low = await getSeverity(q, 1, start, end);
    const nill = await getSeverity(q, 0, start, end);

    let highDataCounts = [];
    let mediumDataCounts = [];
    let lowDataCounts = [];
    let nillDataCounts = [];

    high.map(async (data) => {
      let obj = {
        count: parseInt(data.count),
        date: data.date,
      };
      highDataCounts.push(obj);
    });
    //map data to date mismatch
    datesList.map(async (data) => {
      const found = highDataCounts.some((el) => el.date === data);
      if (!found) {
        highDataCounts.push({ count: 0, date: data });
      }
    });
    //Sort by date
    highDataCounts = highDataCounts.sort(function (a, b) {
      return Number(new Date(a.date)) - Number(new Date(b.date));
    });

    //highDataCounts = highDataCounts.map(a => a.count);
    //=========================================================================
    medium.map(async (data) => {
      let obj = {
        count: parseInt(data.count),
        date: data.date,
      };
      mediumDataCounts.push(obj);
    });
    //map data for date mis match
    datesList.map(async (data) => {
      const found = mediumDataCounts.some((el) => el.date === data);
      if (!found) {
        mediumDataCounts.push({ count: 0, date: data });
      }
    });
    //Sort by date
    mediumDataCounts = mediumDataCounts.sort(function (a, b) {
      return Number(new Date(a.date)) - Number(new Date(b.date));
    });
    //=========================================================================

    low.map(async (data) => {
      let obj = {
        count: parseInt(data.count),
        date: data.date,
      };
      lowDataCounts.push(obj);
    });
    // map data for date mis match
    datesList.map(async (data) => {
      const found = lowDataCounts.some((el) => el.date === data);
      if (!found) {
        lowDataCounts.push({ count: 0, date: data });
      }
    });
    //Sort by date
    lowDataCounts = lowDataCounts.sort(function (a, b) {
      return Number(new Date(a.date)) - Number(new Date(b.date));
    });
    //=========================================================================

    nill.map(async (data) => {
      let obj = {
        count: parseInt(data.count),
        date: data.date,
      };
      nillDataCounts.push(obj);
    });
    //map data for date mis match
    datesList.map(async (data) => {
      const found = nillDataCounts.some((el) => el.date === data);
      if (!found) {
        nillDataCounts.push({ count: 0, date: data });
      }
    });
    //Sort by date
    nillDataCounts = nillDataCounts.sort(function (a, b) {
      return Number(new Date(a.date)) - Number(new Date(b.date));
    });
    //=========================================================================

    //Send response
    const response = {
      success: true,
      data: {
        code: 20,
        msg: "Records found",
        results: {
          datesList,
          highDataCounts,
          mediumDataCounts,
          lowDataCounts,
          notSevere: nillDataCounts,
        },
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get resource usage from prometheus
exports.resourceUsageGraph = async (req, res) => {
  try {
    /*

    */

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    const tenantId = req.metaObj.tenantId;
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;

    //Check
    if (!tenantDb || !appIds || !mongooseTAppIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      {
        $match: {
          _id: {
            $in: mongooseTAppIds,
          },
        },
      },
      {
        $project: {
          name: 1,
        },
      },
    ];

    const apps = await tenantDb.models.app.aggregate(pipeline);

    //App names
    let appNames = [];
    //CPU Usage
    let cpuUsage = [];
    //RAM Usage
    let ramUsage = [];
    //Network inbound
    let nInboundUsage = [];
    if (apps.length > 0) {
      //Push all the appNames
      apps.map((app) => appNames.push(app.name));
      //Get Data from prometheus
      //CPU Usage
      const cpuPromQuery = await Axios({
        method: "GET",
        url: `${promEndpoint}/query?query=(avg(node_load5{tenantId="${tenantId}"}) /  count(count(node_cpu_seconds_total{tenantId="${tenantId}"}) by (cpu)) * 100)`,
      });
      //Ram Usage
      const ramPromQuery = await Axios({
        method: "GET",
        url: `${promEndpoint}/query?query=100 - (node_memory_MemAvailable_bytes{ tenantId="${tenantId}" }* 100) / node_memory_MemTotal_bytes{ tenantId="${tenantId}"}`,
      });
      //Network Inbound Usage
      const nIPromQuery = await Axios({
        method: "GET",
        url: `${promEndpoint}/query?query=irate(node_network_receive_bytes_total{tenantId="${tenantId}"}[5m])`,
      });

      //Map all the apps anf get the respective CPU Usage
      apps.map((app) => {
        //Push the value or zero to cpuUsage
        cpuUsage.push("0");
        //Push the value or zero ramUsage
        ramUsage.push("0");
        //Push the value or zero
        nInboundUsage.push("0");
        //CPU Usage
        if (cpuPromQuery.data.data.result.length > 0) {
          //Remove the last zero
          cpuUsage.pop();
          cpuUsage.push(cpuPromQuery.data.data.result[0].value[1]);
        }
        //RAM Usage
        if (ramPromQuery.data.data.result.length > 0) {
          ramPromQuery.data.data.result.map((oneRec) => {
            if (app._id == oneRec.metric.appId) {
              //Remove the last zero
              ramUsage.pop();
              ramUsage.push(oneRec.value[1]);
            }
          });
        }
        //Network Inbound Usage
        if (nIPromQuery.data.data.result.length > 0) {
          nIPromQuery.data.data.result.map((oneRec) => {
            if (app._id == oneRec.metric.appId) {
              //Remove the last zero
              nInboundUsage.pop();
              nInboundUsage.push(oneRec.value[1]);
            }
          });
        }
      });
    }

    //Send response
    const response = {
      success: true,
      data: {
        code: 20,
        msg: "Records found",
        results: {
          app: appNames,
          cpuUsage,
          ramUsage,
          nInboundUsage,
        },
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get last latest 10 messages of the device

exports.getDeviceMessages = async (req, res) => {
  try {
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    const deviceId = req.params.deviceId;
    let condition = `device_id`;
    let query = `SELECT * FROM device_data where ${condition}=:deviceId ORDER BY to_char(time, :timeFormat) DESC LIMIT 10`;

    const deviceMessages = await pgConn.query(query, {
      replacements: {
        deviceId: deviceId,
        timeFormat: "DD-MON-YYYY HH24:MI:SS AM",
      },
      type: pgConn.QueryTypes.SELECT,
    });

    if (deviceMessages.length > 0) {
      let response = {
        success: true,
        data: {
          code: 20,
          msg: "Records found",
          results: deviceMessages,
        },
      };
      //Send response
      return res.status(200).json(response);
    } else {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Records not found",
          results: [],
        },
      };
      //Send response
      return res.status(200).json(response);
    }
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
