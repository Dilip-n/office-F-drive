/*jshint esversion: 8 */
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const logger = require("./../utils/logger");
const underscore = require("underscore");
const { mongoDb, logTypes } = require("./../../../constants");
const masterDb = mongoDb.masterDb;
//Require User Model
const User = require("./../models/User");
//Require Site Model
const Site = require("./../models/Site");
//Require App Model
const App = require("../models/App");
//Require Util module
const Keys = require("./../utils/keys");
//Require Device Model
const Device = require("./../models/Device");
//Require DeviceProfile Model
const DeviceProfile = require("./../models/DeviceProfile");
//Require Device Manufacturer Model
const DeviceMfr = require("./../models/Manufacturer");
//Require Rule Model
const Rule = require("../models/Rule");
//Require escalation.level Model
//const EL = require("./../models/escalation.level");
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();
//Import Joi
const Joi = require("@hapi/joi");
//Db logger
let { DbLogger } = require("./../utils/dbLogger");
//Add rule - Author Rajesh
// exports.addRule = async (req, res) => {
//   console.log("body ===", req.body);
//   //validation
//   const schema = Joi.object().keys({
//     app: Joi.required(),
//     deviceId: Joi.string().required(),
//     deviceType: Joi.string().required(),
//     name: Joi.string().required(),
//     desc: Joi.string(),
//     dataPath: Joi.string().required(),
//     operator: Joi.string().required(),
//     value: Joi.string().required(),
//     severity: Joi.number().required(),
//     statement: Joi.string().required(),
//     incharge: Joi.required(),
//   });

//   //Generate ruleId
//   const ruleId = await Keys.getDeviceId();
//   const appId = req.body.appId;
//   const deviceId = req.body.deviceId;
//   const ruleName = req.body.name;

//   const checkDetails = {
//     app: req.body.appId,
//     deviceId: req.body.deviceId,
//     deviceType: req.body.deviceType, //Parameter
//     name: req.body.name,
//     desc: req.body.desc,
//     dataPath: req.body.dataPath, //helperId
//     operator: req.body.operator,
//     value: req.body.value,
//     severity: req.body.severity,
//     statement: req.body.statement,
//     incharge: req.body.incharge,
//   };

//   Joi.validate(checkDetails, schema, async (err, value) => {
//     if (err) {
//       // send a 422 error response if validation fails
//       console.log("error", err.details[0].message);
//       return res.status(422).json({
//         success: false,
//         error: {
//           code: 42,
//           msg: err.details[0].message,
//         },
//       });
//     } else {
//       try {
//         //Get tenant DB and apps
//         const tenantDb = req.metaObj.tenantDb;
//         const appIds = req.metaObj.apps;
//         if (!tenantDb || !appIds) {
//           return res.status(400).json({
//             success: false,
//             error: {
//               code: 40,
//               msg: "Something went wrong !",
//             },
//           });
//         }
//         const apps = await tenantDb.models.app.find({ _id: appId });
//         if (apps.length > 0) {
//           //Application  exists check device for this app
//           //Device Model
//           const deviceColl = "device";
//           const DeviceModel = await Device.model(tenantDb, deviceColl);
//           const devices = await DeviceModel.find({ deviceId: deviceId });
//           if (devices.length > 0) {
//             //Devices  exists , add site

//             //Check for duplicate rule name for app and device
//             //Rule Model
//             const ruleColl = "rule";
//             const RuleModel = await Rule.model(tenantDb, ruleColl);
//             const ruleFound = await RuleModel.find({
//               name: ruleName,
//               app: appId,
//               deviceId: deviceId,
//             });
//             if (ruleFound.length > 0) {
//               return res.status(409).json({
//                 success: false,
//                 data: {
//                   code: 40,
//                   msg: "Rule name already exists for this app and device  ",
//                   results: ruleName,
//                 },
//               });
//             } else {
//               try {
//                 const tenantRule = new RuleModel({
//                   _id: new mongoose.Types.ObjectId(),
//                   ruleId: ruleId,
//                   app: req.body.appId,
//                   deviceId: req.body.deviceId,
//                   deviceType: req.body.deviceType, //Parameter
//                   name: req.body.name,
//                   desc: req.body.desc,
//                   dataPath: req.body.dataPath, //helperId
//                   operator: req.body.operator,
//                   value: req.body.value,
//                   severity: req.body.severity,
//                   statement: req.body.statement,
//                   incharge: req.body.incharge,
//                 });
//                 const RuleDetails = await tenantRule.save();
//                 console.log("RuleDetails ", RuleDetails);
//                 if (RuleDetails) {
//                   return res.status(201).json({
//                     success: true,
//                     data: {
//                       code: 20,
//                       msg: "Rule added successfully",
//                       results: RuleDetails,
//                     },
//                   });
//                 } else {
//                   return res.status(200).json({
//                     success: false,
//                     data: {
//                       code: 20,
//                       msg: "Rule not added",
//                       results: RuleDetails,
//                     },
//                   });
//                 }
//               } catch (e) {
//                 console.log(e);
//                 return res.status(500).json({
//                   success: false,
//                   error: {
//                     code: 50,
//                     msg: "Internal error : Error in saving rule details",
//                     data: e,
//                   },
//                 });
//               }
//             }
//           } else {
//             //Application does not exists
//             return res.status(404).json({
//               success: false,
//               error: {
//                 code: 44,
//                 msg: "Device does not exists for this application !",
//                 data: [],
//               },
//             });
//           }
//         } else {
//           //Application does not exists
//           return res.status(404).json({
//             success: false,
//             error: {
//               code: 44,
//               msg: "Application does not exists !",
//               data: [],
//             },
//           });
//         }
//       } catch (err) {
//         console.log(err);
//         return res.status(500).json({
//           success: false,
//           error: {
//             code: 50,
//             msg: "Internal error : DB problem ",
//             error: err,
//           },
//         });
//       }
//     }
//   });
// };

//Get all rules - Author Rajesh
exports.getAllRules = async (req, res) => {
  try {
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const ruleColl = "rule";
    const RuleModel = await Rule.model(tenantDb, ruleColl);
    //const Rules = await RuleModel.find({});
    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $group: {
          _id: "$_id",
          rule: {
            $push: "$$ROOT",
          },
        },
      },
      {
        $project: {
          app: {
            $arrayElemAt: ["$rule.app", 0],
          },
          rule: 1,
        },
      },
      {
        $lookup: {
          from: "apps",
          localField: "app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          rule: 1,
          customer: 1,
          app: {
            $arrayElemAt: ["$app", 0],
          },
        },
      },
      {
        $project: {
          rule: 1,
          customer: 1,
          app: {
            _id: "$app._id",
            name: "$app.name",
          },
        },
      },
      { $unwind: "$rule" },
      {
        $lookup: {
          from: "devices",
          localField: "rule.deviceId",
          foreignField: "deviceId",
          as: "device",
        },
      },
      {
        $project: {
          rule: 1,
          app: 1,
          device: {
            $arrayElemAt: ["$device", 0],
          },
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $lookup: {
          from: "mfr.models",
          localField: "device.mfrId",
          foreignField: "_id",
          as: "manufacturer",
        },
      },
      {
        $project: {
          rule: 1,
          app: 1,
          device: 1,
          customer: 1,
          manufacturer: {
            $arrayElemAt: ["$manufacturer", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          rule: 1,
          app: 1,
          "customer._id": 1,
          "customer.name": 1,
          "device._id": 1,
          "device.name": 1,
          "manufacturer._id": 1,
          "manufacturer.name": 1,
          "manufacturer.helperFn": 1,
          "manufacturer.model": 1,
          "manufacturer.protocolType": 1,
          "manufacturer.deviceProfiles": 1,
        },
      },
    ];
    const Rules = await RuleModel.aggregate(pipeline);
    const response = {
      success: Rules.length > 0 ? true : false,
      data: {
        code: 20,
        msg: Rules.length > 0 ? "Records found" : "No records found",
        count: Rules.length,
        results: Rules,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error : DB problem ",
        error: err,
      },
    });
  }
};

//Update rule - Author Rajesh
exports.updateRule = async (req, res) => {
  try {
    //Get tenant DB
    const tenantDb = req.metaObj.tenantDb;

    const rule_id = req.params.ruleId;
    let update = {};
    //Rule Model
    const ruleColl = "rule";
    const RuleModel = await Rule.model(tenantDb, ruleColl);

    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    if (req.body.name) {
      //Check rule name
      const ruleFound = await RuleModel.find({
        name: req.body.name,
        app: req.body.appId,
        deviceId: req.body.deviceId,
      });

      if (ruleFound.length > 0) {
        return res.status(409).json({
          success: false,
          data: {
            code: 40,
            msg: "Rule name already exists for this app and device  ",
            results: ruleName,
          },
        });
      } else {
        update.name = req.body.name;
      }
    }

    if (req.body.desc) {
      update.desc = req.body.desc;
    }
    if (req.body.operator) {
      update.operator = req.body.operator;
    }
    if (req.body.value) {
      update.value = req.body.value;
    }
    if (req.body.severity) {
      update.severity = req.body.severity;
    }
    if (req.body.statement) {
      update.statement = req.body.statement;
    }
    if (req.body.status) {
      update.status = req.body.status;
    }
    if (req.body.incharge) {
      update.incharge = req.body.incharge;
    }

    //Update
    const updated = await RuleModel.updateOne(
      { _id: rule_id },
      {
        $set: update,
      }
    );
    if (updated.nModified) {
      try {
        //DB Logger
        const logged = await DbLogger(
          req.user,
          req.metaObj.tenantId,
          req.metaObj.tenantDbName,
          req.metaObj.tenantName,
          logTypes.rule.updated,
          true,
          {
            ruleName: updated.name,
            ruleId: updated.ruleId,
            msg: "Rule Updated!",
          }
        );
        if (logged) {
          console.log("Data logged !");
        }
      } catch (e) {
        console.log("Data could not logged !", e);
      }
      //HTTP code can be 204
      return res.status(200).json({
        success: true,
        data: {
          code: 20,
          msg: "Rule details updated",
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Delete rule - Author Rajesh
exports.deleteRule = async (req, res) => {
  try {
    //Get tenant DB
    const tenantDb = req.metaObj.tenantDb;
    const rule_id = req.params.ruleId;

    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const ruleColl = "rule";
    const RuleModel = await Rule.model(tenantDb, ruleColl);
    //Remove this rule from rule collection
    await RuleModel.deleteOne({ _id: rule_id });
    try {
      //DB Logger
      const logged = await DbLogger(
        req.user,
        req.metaObj.tenantId,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.rule.removed,
        true,
        {
          ruleId: rule_id,
          msg: "Rule Removed!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "Rule removed !",
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Search rule - Auth Rajesh
exports.searchRule = async (req, res) => {
  try {
    let prev = 0;
    let next = 10;
    let appName = null;
    let deviceName = null;
    let ruleName = null;
    let matchRegex = {};

    let matchAppRegex = {};
    let matchDeviceRegex = {};
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }

      if (req.query.ruleName) {
        ruleName = req.query.ruleName;
        matchRegex.name = {
          $regex: ruleName,
          $options: "i",
        };
      }

      if (req.query.description) {
        description = req.query.description;
        matchRegex.desc = {
          $regex: description,
          $options: "i",
        };
      }
      if (req.query.appName) {
        appName = req.query.appName;
        matchAppRegex["app.name"] = {
          $regex: appName,
          $options: "i",
        };
      }

      if (req.query.deviceName) {
        deviceName = req.query.deviceName;
        matchDeviceRegex["device.name"] = {
          $regex: deviceName,
          $options: "i",
        };
      }
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const ruleColl = "rule";
    const RuleModel = await Rule.model(tenantDb, ruleColl);
    //const Rules = await RuleModel.find({});
    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $match: matchRegex,
      },
      {
        $group: {
          _id: "$_id",
          rule: {
            $push: "$$ROOT",
          },
        },
      },
      {
        $project: {
          app: {
            $arrayElemAt: ["$rule.app", 0],
          },
          rule: 1,
        },
      },
      {
        $lookup: {
          from: "apps",
          localField: "app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          rule: 1,

          customer: 1,
          app: {
            $arrayElemAt: ["$app", 0],
          },
        },
      },
      {
        $project: {
          rule: 1,

          customer: 1,
          app: {
            _id: "$app._id",
            name: "$app.name",
          },
        },
      },
      { $unwind: "$rule" },
      {
        $lookup: {
          from: "devices",
          localField: "rule.deviceId",
          foreignField: "deviceId",
          as: "device",
        },
      },
      {
        $project: {
          rule: 1,
          app: 1,
          device: {
            $arrayElemAt: ["$device", 0],
          },
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $lookup: {
          from: "mfr.models",
          localField: "device.mfrId",
          foreignField: "_id",
          as: "manufacturer",
        },
      },
      {
        $project: {
          rule: 1,
          app: 1,
          device: 1,
          customer: 1,
          manufacturer: {
            $arrayElemAt: ["$manufacturer", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          rule: 1,
          app: 1,
          "customer._id": 1,
          "customer.name": 1,
          "device._id": 1,
          "device.name": 1,
          "manufacturer._id": 1,
          "manufacturer.name": 1,
          "manufacturer.helperFn": 1,
          "manufacturer.model": 1,
          "manufacturer.protocolType": 1,
          "manufacturer.deviceProfiles": 1,
        },
      },
      { $match: matchAppRegex },
      { $match: matchDeviceRegex },
    ];
    const Rules = await RuleModel.aggregate(pipeline);
    const response = {
      success: Rules.length > 0 ? true : false,
      data: {
        code: 20,
        msg: Rules.length > 0 ? "Records found" : "No records found",
        count: Rules.length,
        results: Rules,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error : DB problem ",
        error: err,
      },
    });
  }
};
//Add rule - Author Rajesh (04-June-2020)
exports.addRule = async (req, res) => {

  //validation
  const schema = Joi.object({
    app: Joi.required(),
    deviceType: Joi.required(),
    name: Joi.string().required(),
    desc: Joi.string(),
    dataPath: Joi.string().required(),
    operator: Joi.string().required(),
    value: Joi.string().required(),
    severity: Joi.number().required(),
    statement: Joi.string().required(),
    incharge: Joi.required(),
  });

  const checkDetails = {
    app: req.body.appId,
    deviceType: req.body.deviceType, //Parameter
    name: req.body.name,
    desc: req.body.desc,
    dataPath: req.body.dataPath, //helperId
    operator: req.body.operator,
    value: req.body.value,
    severity: req.body.severity,
    statement: req.body.statement,
    incharge: req.body.incharge,
  };


  try {
    const value = await schema.validateAsync(checkDetails);


      try {
        //Get tenant DB and apps
        const tenantDb = req.metaObj.tenantDb;

        let devicesFound = req.body.deviceId;
        console.log(devicesFound);

        if (devicesFound.length > 0) {
          const ruleColl = "rule";
          const RuleModel = await Rule.model(tenantDb, ruleColl);
          let map1 = await Promise.all(
            await devicesFound.map(async (device) => {
              //Generate ruleId
              let ruleId = await Keys.getDeviceId();
              console.log("deviceId ", device);
              console.log("ruleId ", ruleId);
              //Rule Model

              const newRule = new RuleModel({
                _id: new mongoose.Types.ObjectId(),
                ruleId: ruleId,
                app: req.body.appId,
                deviceId: device,
                deviceType: req.body.deviceType, //Parameter
                name: req.body.name,
                desc: req.body.desc,
                dataPath: req.body.dataPath, //helperId
                operator: req.body.operator,
                value: req.body.value,
                severity: req.body.severity,
                statement: req.body.statement,
                incharge: req.body.incharge,
              });
              const RuleDetails = await newRule.save();

              if (RuleDetails) {
                console.log("Rule added successfully for device : ", device);
              } else {
                console.log("Rule not added for device : ", device);
              }
            })
          ).then(async (finalResult) => {
            console.log("Processed all devices ");
            try {
              //DB Logger
              const logged = await DbLogger(
                req.user,
                req.metaObj.tenantId,
                req.metaObj.tenantDbName,
                req.metaObj.tenantName,
                logTypes.rule.added,
                true,
                {
                  ruleName: RuleDetails.name,
                  ruleId: RuleDetails.ruleId,
                  msg: "Rule Added!",
                }
              );
              if (logged) {
                console.log("Data logged !");
              }
            } catch (e) {
              console.log("Data could not logged !", e);
            }
            return res.status(201).json({
              success: true,
              data: {
                code: 20,
                msg: "Rule added successfully for all devices",
                results: null,
              },
            });
          });
        } else {
          console.log("Devices not selected ", devicesFound);
          return res.status(200).json({
            success: false,
            data: {
              code: 20,
              msg: "Devices not selected",
              results: devicesFound,
            },
          });
        }
      } catch (err) {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error : DB problem ",
            error: err,
          },
        });
      }
    } catch (err) {
    // send a 422 error response if validation fails
    console.log("error", err.details[0].message);
    return res.status(422).json({
      success: false,
      error: {
        code: 42,
        msg: err.details[0].message,
      },
    });
  }
};

//=================================================================================================

//Get all escalation levels from master DB- Author Rajesh
//exports.getAllEscalationLevel = async (req, res) => {};
