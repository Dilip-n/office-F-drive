/*jshint esversion: 8 */
const converter = require('hex2dec');
const randomBytes = require('randombytes');
// var random = require('random-bytes');
const randtoken = require('rand-token').uid;
// const crypto = require('crypto');
//Require Randomatic for keys
const randomize = require('randomatic');
//Get random keys
exports.getKeys = async (req, res) => {
  let bit = 8;
  //If bit is set in params
  if (req.params.bit) {
    bit = req.params.bit;
  }
  bit = bit / 2;
  try {
    randomBytes(bit, function (err, resp) {
      const randomKey = resp.toString('hex');
      return res.status(201).json({
        success: true,
        data: {
          code: 20,
          msg: 'Random HEX Key',
          key: randomKey.toUpperCase(),
          bits: randomKey.length
        }
      });
    });
  } catch (err) {
    console.log(err);

    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: 'Internal error',
        error: err
      }
    });
  }
};
//Get keys for appId
exports.getAppIdKey = async (req, res) => {
  try {
    const appId = randomize('0', 16);
    return res.status(201).json({
      success: true,
      data: {
        code: 20,
        msg: 'Application ID',
        key: appId
      }
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: 'Internal error',
        error: err
      }
    });
  }
};
//Get keys for siteId
exports.getSiteIdKey = async (req, res) => {
  try {
    const siteId = randomize('0', 16);
    return res.status(201).json({
      success: true,
      data: {
        code: 20,
        msg: 'Site ID',
        key: siteId
      }
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: 'Internal error',
        error: err
      }
    });
  }
};
//Get keys for deviceId
exports.getDeviceIdKey = async (req, res) => {
  try {
    const deviceId = randomize('0', 16);
    return res.status(201).json({
      success: true,
      data: {
        code: 20,
        msg: 'Device ID',
        key: deviceId
      }
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: 'Internal error',
        error: err
      }
    });
  }
};