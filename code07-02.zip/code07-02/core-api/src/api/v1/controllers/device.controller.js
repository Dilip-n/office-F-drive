/*jshint esversion: 8 */
const mongoose = require("mongoose");
const moment = require("moment");
require("moment-timezone");
const vm = require("vm");
const jwt = require("jsonwebtoken");
//Require Randomatic for keys
const randomize = require("randomatic");
const bcrypt = require("bcrypt");
const randomBytes = require("randombytes");
const underscore = require("underscore");
const btoa = require("btoa");
const xlsx = require("xlsx");
const logger = require("./../utils/logger");
const kafkaHandler = require("./../middlewares/kafkaHandler");
let { produce } = kafkaHandler;
const {
  mongoDb,
  loraCredentials,
  sendCommandEndPoint,
  dataHandlerHost,
  logTypes,
} = require("./../../../constants");
//Require App Model
const App = require("../models/App");
//Require Site Model
const Site = require("./../models/Site");
//Require User Model
const User = require("./../models/User");
//Require Device Model
const Device = require("./../models/Device");
//Require Data Model
const Data = require("../models/PgDeviceData");
//Require Alerts Model
const Alerts = require("../models/Alert");
//Require DeviceProfile Model
const DeviceProfile = require("./../models/DeviceProfile");
//Require Device Manufacturer Model
const DeviceMfr = require("./../models/Manufacturer");
//Require MDevice - Device in Master db
const MDevice = require("./../models/MDevice");
//Require MConfigUrls - config urls in Master db
const MConfigUrl = require("./../models/ConfigUrls");
//Require data handler secret from config
const config = require("./../../../config");
//Require Rule Model
const Rule = require("../models/Rule");
//Require Command Model
//const Command = require("./../models/Command");
//Require axios
const Axios = require("axios");
//Require Util module
const Keys = require("./../utils/keys");
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();
//Get master db name
const masterDb = mongoDb.masterDb;
//Db logger
let { DbLogger } = require("./../utils/dbLogger");
/*

! Controller functions starts

*/
//Add Device
exports.addDevice = async (req, res) => {
  try {
    //Get user - who is trying to add the device
    const user = req.user;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    //tenantId = tenantDbName
    const tenantId = req.metaObj.tenantDbName;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get Request object
    //appId
    const appId = req.body.appId;
    //Check if user has this app
    let appCheck = false;
    if (appIds.some((item) => item._id == appId)) {
      appCheck = true;
    }

    if (!appCheck) {
      //App does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "App does not exists !",
        },
      });
    }
    //Generate DeviceId
    const deviceId = await Keys.getDeviceId();
    const deviceColl = "device";
    const devicePColl = "device.profile";
    const mfrModel = "mfr.model";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    //Device Profile Model
    const DeviceProfileModel = await DeviceProfile.model(tenantDb, devicePColl);
    //Device Manufacturer Model
    const DeviceMfrModel = await DeviceMfr.model(tenantDb, mfrModel);
    //Master DB Connection
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get Device Model - master db
    const MDeviceModel = await MDevice.model(masterDbConn, deviceColl);
    //Device Profile Model - master db
    const MDeviceProfileModel = await DeviceProfile.model(
      masterDbConn,
      devicePColl
    );
    //Device Manufacturer Model - master db
    const MDeviceMfrModel = await DeviceMfr.model(masterDbConn, mfrModel);

    //Get Configuration url Model - master db
    const MConfigUrlModel = await MConfigUrl.model(
      masterDbConn,
      "configuration.urls"
    );
    //Check Hyperthings Developer User
    const devEmail = user.email;
    let devUser = false;
    const devEmailCheck = await MConfigUrlModel.findOne({
      addDeviceProfileEmail: devEmail,
    });
    //Mark User as Hyper Developer
    if (devEmailCheck) devUser = true;
    //Intialize ProtocolHandler and protocolResult
    //Create ProtocolHandler Object
    let protocolResult = null;
    ProtocolHandlers = new ProtocolHandler();

    //Check if device ID exists - in tenant DB
    const deviceCheck = await DeviceModel.findOne({
      $or: [
        {
          deviceId: deviceId,
        },
        {
          macAddress: req.body.macAddress,
        },
      ],
    });
    //Check if device ID exists - in master DB
    const mDeviceCheck = await MDeviceModel.findOne({
      $or: [
        {
          deviceId: deviceId,
        },
        {
          macAddress: req.body.macAddress,
        },
      ],
    });
    if (deviceCheck || mDeviceCheck) {
      //App does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "`Device ID or Mac Address` already exists !",
        },
      });
    }
    /*

    !Note: 
    If protocol is LORA - send it to lora handler
    If handler is able to save it to LORA Server then only do other process and save it to db
    
    */
    //If protocol is LORA - send it to lora handler
    if (req.body.protocolType === "lora") {
      let loraObj = req.body.protocolInfo;
      macAddress = req.body.macAddress;
      deviceName = req.body.name;
      loraObj = { ...loraObj, deviceId, deviceName };

      //Get the result
      protocolResult = await ProtocolHandlers.lora(loraObj, MConfigUrlModel);
      //If unable to save the device to lora server
      if (!protocolResult || protocolResult.success === false) {
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: protocolResult.message,
          },
        });
      }
    }

    //Get Data transform functions
    dataTransformers = req.body.dataTransformers;
    let mfrId = null;
    let gateway = null;
    //Custom device/gateway
    if (req.body.existing === false) {
      //To store it in separate documents
      let profiles = [];
      //If it is device
      if (req.body.gateway === true) {
        //Array of data transformers
        dataTransformers.map((obj) => {
          profiles.push({
            for: obj.for,
            fnCode: `${obj.fnCode} processedData = myFun(rawData)`,
            dataSchema: obj.schema,
          });
        });
      } else {
        //One transformer object only
        profiles.push({
          for: dataTransformers.for,
          fnCode: `${dataTransformers.fnCode} processedData = myFun(rawData)`,
          dataSchema: dataTransformers.schema,
        });
      }

      //Insert new device profiles
      const newDeviceProfiles = await DeviceProfileModel.insertMany(profiles);
      if (newDeviceProfiles.length > 0) {
        //If Hyperthink Developer
        if (devUser) {
          //Insert new device profiles - to master db
          await MDeviceProfileModel.insertMany(profiles);
        }

        //Gather device profile for this MFR and Model
        // let deviceProfiles = [];
        // newDeviceProfiles.map(obj => {
        //   deviceProfiles.push({
        //     [obj.for]: obj._id
        //   });
        // });

        let deviceProfiles = {};

        newDeviceProfiles.map((obj) => {
          deviceProfiles[obj.for] = obj._id;
        });

        //Create Device MFR Model
        const mfrObj = {
          name: req.body.manufacturer,
          model: req.body.model,
          gateway: req.body.gateway,
          helperFn: req.body.helperFn,
          protocolType: req.body.protocolType,
          deviceProfiles,
        };
        //Save to Tenant db
        const newMfr = new DeviceMfrModel(mfrObj);

        //If Hyperthink Developer
        if (devUser) {
          //Save to Master db
          const newMMfr = new MDeviceMfrModel(mfrObj);
          await newMMfr.save();
        }
        //Get mfrId
        savedMfr = await newMfr.save();
        mfrId = savedMfr._id;
        gateway = savedMfr.gateway;
      }
    }
    //Existing device/gateway
    if (req.body.existing === true) {
      //Get manufacturerId from request
      const givenMfrId = req.body.manufacturerId;
      const mfrCheck = await DeviceMfrModel.findById(givenMfrId);
      if (!mfrCheck) {
        //Manufacturer does not exists
        return res.status(404).json({
          success: false,
          error: {
            code: 44,
            msg: "Manufacturer does not exists!",
          },
        });
      }
      mfrId = mfrCheck._id;
      gateway = mfrCheck.gateway;
    }

    //If Manufacturer is not set
    if (!mfrId) {
      //Something went wrong
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Something went wrong!",
        },
      });
    }
    //Unique API Key Generator
    const uniqueKeyB64 = randomize("Aa0", 32);
    // const uniqueKeyB64 = btoa(uniqueKey);
    //Save Device now and attach the "mfrId, gateway" obtained from last step
    const deviceObj = {
      deviceId: deviceId,
      app: appId,
      name: req.body.name,
      macAddress: req.body.macAddress,
      lat: req.body.lat,
      lng: req.body.lng,
      address: req.body.address,
      gateway,
      mfrId,
      addedBy: user.userId,
      protocolType: req.body.protocolType,
      protocolInfo: req.body.protocolInfo,
      uniqueKeyB64,
    };
    //Create object and save device
    const newDevice = new DeviceModel(deviceObj);
    await newDevice.save();

    //Save the device copy in Master db device collection
    const mDeviceObj = {
      //tenantDbName = tenantId
      tenantId,
      deviceId,
      app: appId,
      gateway,
      mfrId,
      name: req.body.name,
      macAddress: req.body.macAddress,
      protocolType: req.body.protocolType,
      uniqueKeyB64,
    };

    //Create object and save device - in master db
    const mDevice = new MDeviceModel(mDeviceObj);
    const savedMDevice = await mDevice.save();

    //If protocol is MQTT - send it to saveMqtt
    if (req.body.protocolType === "mqtt") {
      const mqttObj = {
        tenantId,
        deviceId,
        savedMDevice,
        gateway: req.body.gateway,
        helperId: req.body.helperId,
      };
      //Get the result
      protocolResult = await ProtocolHandlers.mqtt(mqttObj, MConfigUrlModel);
    }

    //If protocol is Sigfox - send it to sigfox handler
    if (req.body.protocolType === "sigfox") {
      const sigfoxObj = {};
      //Get the result
      protocolResult = await ProtocolHandlers.sigfox(
        sigfoxObj,
        MConfigUrlModel
      );
    }
    //If protocol is TCP - send it to TCP handler
    if (req.body.protocolType === "tcp") {
      const tcpObj = {};
      //Get the result
      protocolResult = await ProtocolHandlers.tcp(tcpObj, MConfigUrlModel);
    }
    //If protocol is UDP - send it to UDP handler
    if (req.body.protocolType === "udp") {
      const udpObj = {};
      //Get the result
      protocolResult = await ProtocolHandlers.udp(udpObj, MConfigUrlModel);
    }
    //If protocol is API - send it to API handler
    if (req.body.protocolType === "api") {
      const apiObj = {};
      //Get the result
      protocolResult = await ProtocolHandlers.api(apiObj, MConfigUrlModel);
    }

    //If protocol is http - send it to API handler
    if (req.body.protocolType === "http") {
      let protocolInfo = req.body.protocolInfo;
      console.log("HTTP protocolInfo ", protocolInfo);
      const httpProtocolInfo = {
        protocolType: req.body.protocolType,
        url: protocolInfo.url,
        method: protocolInfo.method,
        body: protocolInfo.body,
        json: true,
        headers: protocolInfo.headers,
        pollTime: protocolInfo.pollTime,
      };
      //Get the result
      protocolResult = await ProtocolHandlers.http(httpProtocolInfo);
    }

    let seconds = new Date() / 1000;
    seconds = seconds.toFixed();
    let kafkaObject = {
      protocol: req.body.protocolType,
      deviceId: deviceId,
      tenantId: tenantId,
      appId: appId,
      eventTimestamp: seconds,
      mfr: mfrId,
    };

    // convert JSON object to String
    let jsonKStr = JSON.stringify(kafkaObject);
    //console.log("online kafkaMessages ", kafkaMessages);
    let kafkaData = {
      topic: config.kafkaPublishTopic,
      messages: jsonKStr,
    };
    await produce([kafkaData]);
    try {
      //DB Logger
      const logged = await DbLogger(
        user,
        tenantId,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.device.added,
        true,
        {
          deviceName: mDeviceObj.name,
          deviceId: mDeviceObj.deviceId,
          macAddress: mDeviceObj.macAddress,
          protocolType: mDeviceObj.protocolType,
          msg: "Device Added!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    //Format response
    let response = {
      success: true,
      data: {
        code: 21,
        msg: "Device Added !",
        results: protocolResult,
      },
    };
    //Send response
    return res.status(201).json(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/*
Find all devices for one tenant - with pagination
*/
exports.getAllDevices = async (req, res) => {
  try {
    /*


    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;

    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    const pipeline = [
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $match: {
          app: {
            $in: mongooseTAppIds,
          },
        },
      },
      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $project: {
          device: "$$ROOT",
        },
      },
      {
        $lookup: {
          from: "apps",
          localField: "device.app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $lookup: {
          from: "mfr.models",
          localField: "device.mfrId",
          foreignField: "_id",
          as: "manufacturer",
        },
      },

      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          device: 1,
          manufacturer: {
            $arrayElemAt: ["$manufacturer", 0],
          },
          app: {
            $arrayElemAt: ["$app", 0],
          },
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          device: 1,
          "app._id": 1,
          "app.name": 1,
          "app.customer": 1,
          "customer._id": 1,
          "customer.name": 1,
          "manufacturer._id": 1,
          "manufacturer.name": 1,
          "manufacturer.model": 1,
        },
      },
    ];
    const deviceColl = "device";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    const devs = await DeviceModel.aggregate(pipeline);
    //return devs;

    const response = {
      success: devs.length > 0 ? true : false,
      data: {
        code: 20,
        msg: devs.length > 0 ? "Records found" : "No records found",
        count: devs.length,
        results: devs,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Delete one device
exports.deleteDevice = async (req, res) => {
  try {
    //Get user - who is trying to delete the device
    const user = req.user;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Get deviceId from request
    const deviceId = req.params.deviceId;
    //Get Tenant id
    const tenantId = req.metaObj.tenantId;

    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Switch to master db
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get Device Model - master db
    const MDeviceModel = await MDevice.model(masterDbConn, "device");
    const deviceCheck = await DeviceModel.findOne({
      $and: [
        {
          _id: deviceId,
        },
        {
          app: { $in: appIds },
        },
      ],
    });
    //Check if deviceId is valid
    if (!deviceCheck) {
      //Device does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Device does not exists !",
        },
      });
    }
    //Get macAddress and deviceId to find the same device in master collection
    const mDeviceCheck = await MDeviceModel.findOne({
      $and: [
        {
          deviceId: deviceCheck.deviceId,
        },
        {
          macAddress: deviceCheck.macAddress,
        },
      ],
    });
    //Remove this device from device collection
    await deviceCheck.deleteOne();
    //Remove this device from master device collection
    if (mDeviceCheck) {
      await mDeviceCheck.deleteOne();
    }

    //Remove this device from rule collection
    //Get rule Model - Auth Rajesh
    const RuleModel = await Rule.model(tenantDb, "rule");
    await RuleModel.deleteMany({ deviceId: deviceId });
    try {
      //DB Logger
      const logged = await DbLogger(
        user,
        tenantId,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.device.removed,
        true,
        {
          deviceName: deviceCheck.name,
          deviceId: deviceCheck.deviceId,
          macAddress: deviceCheck.macAddress,
          protocolType: deviceCheck.protocolType,
          msg: "Device Removed!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    //Send response
    //HTTP code can be 204
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "Device removed !",
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Controller
//One device details
exports.getOneDevice = async (req, res) => {
  try {
    /*


    */
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    //Get deviceId from request
    const deviceId = req.params.deviceId;

    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    const device = await DeviceModel.findOne({
      $and: [
        {
          _id: deviceId,
        },
        {
          app: { $in: appIds },
        },
      ],
    })
      .select("-__v")
      .populate({
        path: "app",
        select: "name -_id",
        model: tenantDb.models.app,
      });
    //Check if deviceId is valid
    if (!device) {
      //Device does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Device does not exists !",
        },
      });
    }
    //Get deviceId - numeric - for Postgres
    const pgDeviceId = device.deviceId;

    //Get the device last communication time
    //Getting the last record of the device from timescale db

    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    const deviceLiveData = await pgConn.query(
      "SELECT time FROM device_data where device_id=:deviceId ORDER BY time DESC LIMIT 1",
      {
        replacements: {
          deviceId: pgDeviceId,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    console.log(deviceLiveData);
    //Getting last communication time and status

    let status = false,
      diffrence = "N/A";
    if (deviceLiveData.length == 1) {
      //Get device last communication time.
      let deviceLastComm = moment(deviceLiveData[0].time)
        .tz("Asia/Kolkata")
        .format();
      //Calculate the last communication time
      let currentTime = moment().tz("Asia/Kolkata").format();
      //Get the moment object
      deviceLastComm = moment(deviceLastComm);
      currentTime = moment(currentTime);

      //Find the diffrence
      diffrence = currentTime.diff(deviceLastComm, "seconds");

      /*
      ! For testing purpose only
      ! If device has not received any data in last 60 min, then display it as "Offline/False"
      
      */

      if (diffrence / 60 < 60) {
        status = true;
        //Get diffrence
        diffrence = UtilFunctions.secondsToHms(diffrence) + " ago";
      } else {
        diffrence = moment(deviceLastComm)
          .tz("Asia/Kolkata")
          .format("DD-MM-YYYY HH:mm:ss A");
      }
    }

    //Send success response with device obj
    return res.status(200).send({
      success: true,
      data: {
        code: 20,
        msg: "Device found",
        results: {
          device,
          status: {
            lastCommTime: diffrence,
            online: status,
          },
        },
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
exports.getDeviceLiveData = async (req, res) => {
  try {
    return res.send("Device Data");
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/*Get all devices - Pagination does not work here
// exports.getAllDevices = async (req, res) => {
//   try {
//     const db = await dbConn.mongoDbConn.useDb(masterDb);
//     const UserModel = await User.model(db, 'user');
//     //Get user id
//     const user = req.user;
//     //Add Custom App schema in user model for tenant type
//     UserModel.schema.add({
//       applications: [mongoose.Schema.Types.ObjectId]
//     });
//     //Format result
//     let data = [];
//     //Check if user exists
//     UserModel.findOne({ _id: user.userId })
//       .then(async user => {
//         if (!user) {
//           return res.status(404).json({
//             code: 44,
//             msg: 'User does not exists !'
//           });
//         }
//         //Check if this user has some assigned App
//         if (!user.applications.length > 0) {
//           return res.status(200).json({
//             success: false,
//             data: {
//               code: 49,
//               msg: 'User has no App assigned !',
//               results: []
//             }
//           });
//         }
//         //Get this tenant db
//         const dbName = UtilFunctions.tenantDbName(user.username, tenantDbSuffix);
//         if (!dbName) {
//           return res.status(400).json({
//             success: false,
//             error: {
//               code: 40,
//               msg: 'Something went wrong !'
//             }
//           });
//         }
//         //Use tenant db
//         const db1 = await dbConn.mongoDbConn.useDb(dbName);
//         //Get all the app details form tenant db
//         const ApplicationModel = App.model(db1, 'app');
//         const apps = await ApplicationModel.find({
//           _id: { $in: user.applications }
//         }).select('internal_id app_id name');

//         /* Promise all promises*/
//         const promises = apps.map(async (val, idx) => {
//           //Get collection name for the device
//           const collection = UtilFunctions.collectionName(
//             val.internal_id,
//             'device'
//           );
//           //Get device Model
//           const DeviceModel = await Device.model(db1, collection);
//           const devices = await DeviceModel.find({}).select('-__v');
//           // .populate({
//           //   path: 'users.user',
//           //   select: 'name -_id',
//           //   model: UserModel
//           // });
//           //Push the device data to data array
//           data.push({
//             app: { appId: val.app_id, _id: val._id, name: val.name },
//             devices
//           });
//         });

//         await Promise.all(promises);
//         return data;
//       })
//       .then(result => {
//         //If there is no device
//         if (!result.length > 0) {
//           const response = {
//             success: false,
//             data: {
//               code: 20,
//               msg: 'No device found !',
//               results: []
//             }
//           };
//           return res.status(200).send(response);
//         }

//         //If some device found
//         const results = {
//           tenantName: user.name,
//           count: result.length,
//           device: result
//         };
//         const response = {
//           success: true,
//           data: {
//             code: 20,
//             msg: 'Devices found',
//             results
//           }
//         };
//         return res.status(200).send(response);
//       })
//       .catch(err => {
//         console.log(err);
//         return res.status(500).json({
//           success: false,
//           error: {
//             code: 50,
//             msg: 'Internal error',
//             error: err
//           }
//         });
//       });
//   } catch (err) {
//     console.log(err);
//     return res.status(500).json({
//       success: false,
//       error: {
//         code: 50,
//         msg: 'Internal error',
//         error: err
//       }
//     });
//   }
// };*/

//Function preview
exports.devicesFunction = async (req, res) => {
  try {
    //Get data from body
    let functionCode = req.body.functionCode;
    let code = `${functionCode};processedData = myFun(rawData)`;
    let input = JSON.parse(req.body.functionInput);
    const runTransform = (rawData, transform) => {
      return new Promise(function (resolve, reject) {
        try {
          const script = new vm.Script(transform);
          let sandbox = {
            rawData,
            processedData: null,
          };
          let context = new vm.createContext(sandbox);
          try {
            script.runInContext(context);
          } catch (error) {
            console.log(error);
          }
          resolve(sandbox);
        } catch (error) {
          reject({ error: "transform_error" });
        }
      });
    };
    const result = await runTransform(input, code);
    return res.json({
      result: result.processedData,
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Controller
//Add multiple Devices to one site - Auth Rajesh
exports.addDeviceToSite = async (req, res) => {
  console.log("Body ", req.body);
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    //Get siteId from request
    const siteId = req.body.siteId;
    const appId = req.body.appId;
    const deviceList = req.body.deviceIds;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    const apps = await tenantDb.models.app.find({ _id: appId });
    if (apps.length > 0) {
      //Application exists check device for this appId
      //Site Model
      const siteColl = "site";
      const SiteModel = await Device.model(tenantDb, siteColl);
      const siteDetails = await SiteModel.find({ _id: siteId });
      if (siteDetails.length > 0) {
        //Site exists check device for this siteId
        //Get device Model
        const DeviceModel = await Device.model(tenantDb, "device");

        let async = require("async");
        async.each(
          deviceList,
          async function (device, callback) {
            //console.log("device in async ", device);
            const deviceDetails = await DeviceModel.find({ _id: device });
            if (deviceDetails.length > 0) {
              let deviceId = device;
              await DeviceModel.updateOne(
                { _id: deviceId },
                { $set: { site: siteId } }
              );
              //callback();
            }
          },
          function (err) {
            // if any of the file processing produced an error, err would equal that error
            if (err) {
              console.log(err);
              return res.status(500).json({
                success: false,
                error: {
                  code: 50,
                  msg: "Internal error",
                  error: err,
                },
              });
            } else {
              // console.log("All devices have been processed successfully");
              //Send response
              //HTTP code can be 204
              return res.status(200).json({
                success: true,
                data: {
                  code: 20,
                  msg: "Devices added !",
                },
              });
            }
          }
        );
      } else {
        //Site does not exists
        return res.status(404).json({
          success: false,
          error: {
            code: 44,
            msg: "Site does not exists !",
            data: {},
          },
        });
      }
    } else {
      //Application does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application does not exists !",
          data: {},
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/*
Find all devices for one tenant - with search items - regex - Author Rajesh
*/
exports.getDevicesForSearch = async (req, res) => {
  try {
    //Get Query params for search and pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    let dName = null;
    let appName = null;
    let macAddress = null;
    let customer = null;
    let protocol = null;
    let matchRegex = {};
    let matchAppRegex = {};
    let matchCustomerRegex = {};
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    console.log("mongooseTAppIds ", mongooseTAppIds);
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }
      //Device name/id/app for regex
      if (req.query.dName) {
        dName = req.query.dName;
        matchRegex.name = {
          $regex: dName,
          $options: "i",
        };
      }

      if (req.query.appName) {
        appName = req.query.appName;
        matchAppRegex["app.name"] = {
          $regex: appName,
          $options: "i",
        };
      }

      if (req.query.macAddress) {
        macAddress = req.query.macAddress;
        matchRegex.macAddress = {
          $regex: macAddress,
          $options: "i",
        };
      }

      if (req.query.protocol) {
        protocol = req.query.protocol;
        matchRegex.protocolType = {
          $regex: protocol,
          $options: "i",
        };
      }

      if (req.query.customer) {
        customer = req.query.customer;
        matchCustomerRegex["customer.name"] = {
          $regex: customer,
          $options: "i",
        };
      }
    }

    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      { $match: matchRegex },

      {
        $match: {
          app: {
            $in: mongooseTAppIds,
          },
        },
      },
      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $project: {
          device: "$$ROOT",
        },
      },
      {
        $lookup: {
          from: "apps",
          localField: "device.app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $lookup: {
          from: "mfr.models",
          localField: "device.mfrId",
          foreignField: "_id",
          as: "manufacturer",
        },
      },

      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          device: 1,
          manufacturer: {
            $arrayElemAt: ["$manufacturer", 0],
          },
          app: {
            $arrayElemAt: ["$app", 0],
          },
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $project: {
          _id: 0,
          device: 1,
          "app._id": 1,
          "app.name": 1,
          "app.customer": 1,
          "customer._id": 1,
          "customer.name": 1,
          "manufacturer._id": 1,
          "manufacturer.name": 1,
          "manufacturer.model": 1,
        },
      },
      { $match: matchAppRegex },
      { $match: matchCustomerRegex },
    ];
    //Get tenant DB and devs
    const tenantDb = req.metaObj.tenantDb;
    const deviceColl = "device";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    const devs = await DeviceModel.aggregate(pipeline);
    //return devs;

    const response = {
      success: devs.length > 0 ? true : false,
      data: {
        code: 20,
        msg: devs.length > 0 ? "Records found" : "No records found",
        count: devs.length,
        results: devs,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Getting device alerts
exports.getRecentAlerts = async (req, res) => {
  try {
    const deviceId = req.params.deviceId;
    /*

    //Validation needs to be done 

    */
    const db = await dbConn.mongoDbConn.useDb(masterDb);
    const UserModel = await User.model(db, "user");
    //Get user id
    const userJWT = req.user;
    if (userJWT.type === "tenant") {
      //Add Custom App schema in user model for tenant type
      UserModel.schema.add({
        applications: [
          {
            type: mongoose.Schema.Types.ObjectId,
          },
        ],
      });
    }
    //Check if user exists
    UserModel.findOne({
      _id: userJWT.userId,
    })
      .then(async (user) => {
        if (!user) {
          return res.status(404).json({
            success: false,
            error: {
              code: 44,
              msg: "User does not exists !",
            },
          });
        }
        let dbPrefix = null;
        if (userJWT.type === "tenant") {
          //For tenant
          dbPrefix = user.username;
        } else {
          const tenant = await UserModel.findOne({
            _id: user.tenant_id,
          });
          dbPrefix = tenant.username;
        }
        //Get this tenant db
        const dbName = UtilFunctions.tenantDbName(dbPrefix, tenantDbSuffix);
        if (!dbName || !dbPrefix) {
          return res.status(400).json({
            success: false,
            error: {
              code: 40,
              msg: "Something went wrong !",
            },
          });
        }
        //Use tenant db
        const db1 = await dbConn.mongoDbConn.useDb(dbName);
        //Collection name For the devices which are inside the "tenantDB > Devices" master collection
        const deviceColl = "device";
        //Get device Model
        const DeviceModel = await Device.model(db1, deviceColl);

        const device = await DeviceModel.findOne({ device_id: deviceId });
        //If device exists
        let data;
        if (device) {
          //Check recent alerts from - Alert Model
          const AlertModel = await Alerts.model(db1, "alert");
          data = await AlertModel.find({
            device_id: device.device_id,
          })
            .sort({ created_at: -1 })
            .limit(10);
        }

        return { device, data };
      })
      .then((result) => {
        //If there is no device
        if (result.device === null) {
          const response = {
            success: false,
            data: {
              code: 20,
              msg: "No such device found !",
              results: [],
            },
          };
          return res.status(200).send(response);
        }
        if (result.data === null) {
          const response = {
            success: false,
            data: {
              code: 20,
              msg: "No recent alerts !",
              results: [],
            },
          };
          return res.status(200).send(response);
        }
        const response = {
          success: true,
          data: {
            code: 20,
            msg: "Alerts found",
            results: result.data,
          },
        };
        return res.status(200).send(response);
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error",
            error: err,
          },
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Search MAC Address - If it exists in master or tenant db
exports.searchMac = async (req, res) => {
  try {
    /*

    */
    //Get tenant DB and userLevel
    const tenantDb = req.metaObj.tenantDb;
    //Get appId from  URL
    const id = req.params.macAddress;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Connect to master DB
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get Device Model - master db
    const MDeviceModel = await MDevice.model(masterDbConn, "device");
    //Check if device ID exists - in tenant DB
    const deviceCheck = await DeviceModel.findOne({
      $or: [
        {
          deviceId: id,
        },
        {
          macAddress: id,
        },
      ],
    });
    //Check if device ID exists - in master DB
    const mDeviceCheck = await MDeviceModel.findOne({
      $or: [
        {
          deviceId: id,
        },
        {
          macAddress: id,
        },
      ],
    });
    if (deviceCheck || mDeviceCheck) {
      //Device already exists - 409
      return res.status(200).json({
        success: false,
        error: {
          code: 49,
          msg: "`Mac Address` already exists !",
        },
      });
    }
    //Success
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "Valid `Mac Address` !",
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get all devices for app and device type for rule adding - auth Rajesh 12-June-2020

exports.getAllDevicesForAppAndDeviceType = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appId = req.params.appId;

    const deviceType = req.params.deviceType;

    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    const deviceColl = "device";
    const devicePColl = "device.profile";
    const mfrModel = "mfr.model";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    //Device Profile Model
    const DeviceProfileModel = await DeviceProfile.model(tenantDb, devicePColl);
    //Device Manufacturer Model
    const DeviceMfrModel = await DeviceMfr.model(tenantDb, mfrModel);

    async function getMfrs(profiles) {
      return new Promise(async (resolve, reject) => {
        let data = Promise.all(
          await profiles.map(async (profile) => {
            let key = `deviceProfiles.${profile.for}`;
            let query = {
              [key]: profile._id,
            };

            //console.log("query ", query);

            let devicesMfr = await DeviceMfrModel.findOne(query).select(" _id");
            // console.log("--", devicesMfr);
            if (devicesMfr !== null) {
              return devicesMfr;
            }
          })
        );

        await resolve(data);
      });
    }

    async function getAllDevices(mfrs, app) {
      return new Promise(async (resolve, reject) => {
        let data = Promise.all(
          await mfrs.map(async (mfr) => {
            if (mfr) {
              let query = {
                app: app,
                mfrId: mfr._id,
              };

              // console.log("query ", query);

              let device = await DeviceModel.find(query).select(
                " name deviceId app"
              );
              //console.log("--", device);
              if (device) {
                return device;
              }
            }
          })
        );
        await resolve(data);
      });
    }

    const devicesProfs = await DeviceProfileModel.find({
      for: deviceType,
    }).select(" _id for");
    //console.log("devicesProfs ", devicesProfs);

    if (devicesProfs.length > 0) {
      let manufacturers = await getMfrs(devicesProfs);
      // console.log("manufacturers ", manufacturers);

      let devicesFound = await getAllDevices(manufacturers, appId);
      // console.log(devicesFound);

      function filter_array(test_array) {
        var index = -1,
          arr_length = test_array ? test_array.length : 0,
          resIndex = -1,
          result = [];

        while (++index < arr_length) {
          var value = test_array[index];

          if (value) {
            result[++resIndex] = value;
          }
        }

        return result;
      }

      let filteredDevices = await filter_array(devicesFound);

      var mergedDevices = [].concat.apply([], filteredDevices);

      const response = {
        success: mergedDevices.length > 0 ? true : false,
        data: {
          code: 20,
          msg: mergedDevices.length > 0 ? "Records found" : "No records found",
          count: mergedDevices.length,
          results: mergedDevices,
        },
      };
      return res.status(200).send(response);
    } else {
      const response = {
        success: devicesProfs.length > 0 ? true : false,
        data: {
          code: 20,
          msg:
            devicesProfs.length > 0
              ? "Device profiles found"
              : "Device profiles not found",
          count: devicesProfs.length,
          results: devicesProfs,
        },
      };
      return res.status(200).send(response);
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Update Device - Auth Rajesh -12-June-2020 (only appId, name, lat, lng, address, macAddress)
exports.updateDevice = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    //Get user - who is trying to update the device
    const user = req.user;
    const appIds = req.metaObj.apps;
    //Get Tenant id
    const tenantId = req.metaObj.tenantId;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get Request object
    const { name, lat, lng, address } = req.body;

    const deviceColl = "device";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    const masterDbConn = await tenantDb.useDb(masterDb);
    //Get Device Model - master db
    const MDeviceModel = await MDevice.model(masterDbConn, deviceColl);

    let updateTdeviceData = {};
    let updateMdeviceData = {};
    //Check app
    // if (appId) {
    //   //appId
    //   let appId = req.body.appId;
    //   //Check if user has this app
    //   let appCheck = false;
    //   if (appIds.some((item) => item._id == appId)) {
    //     appCheck = true;
    //   }

    //   if (!appCheck) {
    //     //App does not exists
    //     return res.status(404).json({
    //       success: false,
    //       error: {
    //         code: 44,
    //         msg: "App does not exists !",
    //       },
    //     });
    //   } else {
    //     updateTdeviceData.app = appId;
    //     updateMdeviceData.app = appId;
    //   }
    // }
    //Check mac address
    // if (macAddress) {
    //   //Check if macAddress exists - in tenant DB
    //   const deviceCheck = await DeviceModel.findOne({
    //     macAddress: req.body.macAddress,
    //   });
    //   //Check if macAddress exists - in master DB
    //   const mDeviceCheck = await MDeviceModel.findOne({
    //     macAddress: req.body.macAddress,
    //   });
    //   if (deviceCheck || mDeviceCheck) {
    //     //App does not exists
    //     return res.status(409).json({
    //       success: false,
    //       error: {
    //         code: 49,
    //         msg: "Mac Address already exists !",
    //       },
    //     });
    //   } else {
    //     updateTdeviceData.macAddress = macAddress;
    //     updateMdeviceData.macAddress = macAddress;
    //   }
    // }

    if (name) {
      updateTdeviceData.name = name;
      updateMdeviceData.name = name;
    }

    if (address) {
      updateTdeviceData.address = address;
    }
    if (lat) {
      updateTdeviceData.lat = lat;
    }
    if (lng) {
      updateTdeviceData.lng = lng;
    }

    const deviceId = req.params.deviceId;

    if (deviceId) {
      let tDevice = await DeviceModel.findOne({ deviceId: deviceId });
      if (tDevice) {
        let tDeviceUpdate = await DeviceModel.updateOne(
          { deviceId: deviceId },
          { $set: updateTdeviceData }
        );
        if (tDeviceUpdate.nModified) {
          let MDevice = await MDeviceModel.findOne({ deviceId: deviceId });
          if (MDevice) {
            let mDeviceUpdate = await MDeviceModel.updateOne(
              { deviceId: deviceId },
              { $set: updateMdeviceData }
            );

            if (mDeviceUpdate.nModified) {
              try {
                //DB Logger
                const logged = await DbLogger(
                  user,
                  tenantId,
                  req.metaObj.tenantDbName,
                  req.metaObj.tenantName,
                  logTypes.device.updated,
                  true,
                  {
                    deviceName: tDevice.name,
                    deviceId: tDevice.deviceId,
                    macAddress: tDevice.macAddress,
                    protocolType: tDevice.protocolType,
                    msg: "Device Updated!",
                  }
                );
                if (logged) {
                  console.log("Data logged !");
                }
              } catch (e) {
                console.log("Data could not logged !", e);
              }
              let response = {
                success: true,
                data: {
                  code: 20,
                  msg: "Device details Updated !",
                  results: updateTdeviceData,
                },
              };
              //Send response
              return res.status(200).json(response);
            } else {
              console.log("Device details not updated in master db");
              return res.status(200).json({
                success: false,
                error: {
                  code: 20,
                  msg: "Device details not updated!",
                },
              });
            }
          } else {
            return res.status(200).json({
              success: false,
              error: {
                code: 20,
                msg: "Device not found !",
              },
            });
          }
        } else {
          console.log("Device details not updated in tenant db");
          return res.status(200).json({
            success: false,
            error: {
              code: 20,
              msg: "Device details not updated!",
            },
          });
        }
      } else {
        return res.status(200).json({
          success: false,
          error: {
            code: 20,
            msg: "Device not found !",
          },
        });
      }
    } else {
      return res.status(200).json({
        success: false,
        error: {
          code: 20,
          msg: "deviceId required !",
        },
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
exports.addBulkDevice = async (req, res) => {
  try {
    //Get user - who is trying to add the device
    const user = req.user;
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    //tenantId = tenantDbName
    const tenantId = req.metaObj.tenantId;
    const appIds = req.metaObj.apps;
    //Get appId
    const appId = req.query.appId;
    //Get Request object
    //Get Input data
    const data = req.body;
    const deviceColl = "devicex";

    //Check if user has this app
    let appCheck = false;
    if (appIds.some((item) => item._id == appId)) {
      appCheck = true;
    }

    if (!appCheck) {
      //App does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "App does not exists !",
        },
      });
    }

    //Get device Model
    const DeviceModel = await Device.model(tenantDb, deviceColl);
    const newDeviceProfiles = await DeviceModel.insertMany(data);
    if (newDeviceProfiles.length > 0) {
      let response = {
        success: true,
        data: {
          code: 20,
          msg: "Devices saved!",
          results: data,
        },
      };
      //Send response
      return res.status(200).json(response);
    }
  } catch (err) {
    //console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Send command to Device - Auth Rajesh -18-June-2020 (only mqtt, tcp, udp)
exports.sendCommand = async (req, res) => {
  try {
    //Get tenant DB and apps
    // console.log(req.metaObj);

    const tenantDb = req.metaObj;
    console.log(tenantDb.tenantDbName);

    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get Request object
    const { deviceId, payload, protocol } = req.body;

    const deviceColl = "device";
    //Get device Model
    const DeviceModel = await Device.model(tenantDb.tenantDb, deviceColl);

    let deviceFound = await DeviceModel.findOne({ deviceId: deviceId });

    if (deviceFound) {
      let ts = Date.now();
      ts = ts / 1000;

      let dataToSend = {
        tenantId: tenantDb.tenantDbName,
        deviceId: deviceId,
        payload: payload,
        protocol: protocol,
        from: "core_api",
        by: "admin",
        ts: ts,
      };
      console.log("dataToSend ", dataToSend);

      let url = `${sendCommandEndPoint}/command`;
      console.log("URL ", url);

      try {
        console.log("Sending command.....");
        let commandData = await Axios({
          method: "POST",
          url: url,
          data: dataToSend,
        });
        //console.log("commandData ", commandData);

        let response = {
          success: true,
          data: {
            code: 20,
            msg: "Command sent successfully",
            results: dataToSend,
          },
        };
        //Send response
        return res.status(200).json(response);
      } catch (err) {
        if (err.response && err.response.data) {
          let response = {
            success: false,
            data: {
              code: 20,
              msg: "Command not sent",
              results: dataToSend,
            },
          };
          //Send response
          return res.status(200).json(response);
        }
      }
    } else {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Device details not sent",
          results: null,
        },
      };
      //Send response
      return res.status(200).json(response);
    }
  } catch (err) {
    //console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get all commands for the device Auth Rajesh - 22-06-2020
exports.getDeviceCommands = async (req, res) => {
  try {
    //Get Request object
    const deviceId = req.params.deviceId;

    //Get PG Connection
    //console.log(req.metaPgObj);
    const pgConn = req.metaPgObj.tenantDb;
    const deviceCommands = await pgConn.query(
      `SELECT "time", id, device_id, protocol, "size", command, ingest_time, command_from, command_by
FROM public.device_commands where device_id=:deviceId ORDER BY "time" DESC;`,
      {
        replacements: {
          deviceId: deviceId,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    console.log("deviceCommands ", deviceCommands);
    if (deviceCommands.length > 0) {
      let finalData = [];
      await deviceCommands.map(async (data) => {
        data.status = "sent";
        finalData.push(data);
      });
      let response = {
        success: true,
        data: {
          code: 20,
          msg: "Records found",
          results: finalData,
        },
      };
      //Send response
      return res.status(200).json(response);
    } else {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Records not found",
          results: [],
        },
      };
      //Send response
      return res.status(200).json(response);
    }
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

/* 

! Controller helper class which has methods to handle protocols starts here


*/
class ProtocolHandler {
  constructor() {}
  //Controller helper function - for saving LORA device type on LORA server
  async lora(inputData, configUrlModel) {
    try {
      //Check if protocol info is not empty
      const input = underscore.isEmpty(inputData);
      if (input) {
        //Send error
        return {
          success: false,
          message:
            "Unable to process LORA type devices at this moment. Please try after some time!",
        };
      } else {
        let loraTitle = "HTS_" + randomize("a", 8);
        let loraDesc = "Device Description";
        //name
        if (inputData.loraTitle) {
          loraTitle = inputData.loraTitle;
        }
        //description
        if (inputData.description) {
          loraDesc = inputData.description;
        }
        //Add device to lORA server starts
        const loginDetails = loraCredentials;

        const options = {
          url: "http://192.168.1.220:8080/api/internal/login",
          "content-type": "App/json",
          method: "POST",
          json: loginDetails,
          rejectUnauthorized: false,
        };
        //Login to LORA Server
        const loraResp = await request(options);
        //Get the JWT key returned from LORA for next request
        const jwtAuth = loraResp.jwt;
        //Add the device to lora server
        let device = {
          device: {
            //Static for now
            applicationID: "1",
            description: loraDesc,
            devEUI: randomBytes(8).toString("hex"),
            //Static for now
            deviceProfileID: "f58acd0c-4b48-445b-bf6c-3cabbea8ed0f",
            name: loraTitle,
            referenceAltitude: 0,
            skipFCntCheck: true,
            tags: {},
            variables: {},
          },
        };
        //After saving Activate device now
        let activate = {
          deviceActivation: {
            aFCntDown: 0,
            appSKey: "2f9ae9e7eb62bdadd1d9437e4e11455d",
            devAddr: "1bc081f8",
            devEUI: device.device.devEUI,
            fCntUp: 0,
            fNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38e",
            nFCntDown: 0,
            nwkSEncKey: "68618d47e870dfd6352fffbcdd96f38d",
            sNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38d",
          },
        };
        //If lorawan == '1.1.x' && this.enprocess == 'ABP'
        if (inputData.lorawan == "1.1.x" && inputData.enprocess == "ABP") {
          device = {
            device: {
              //Static for now
              applicationID: "1",
              description: loraDesc,
              devEUI: inputData.devEUI,
              //Static for now
              deviceProfileID: "f58acd0c-4b48-445b-bf6c-3cabbea8ed0f",
              name: loraTitle,
              referenceAltitude: 0,
              skipFCntCheck: true,
              tags: {},
              variables: {},
            },
          };
          activate = {
            deviceActivation: {
              aFCntDown: 0,
              appSKey: inputData.appSKey,
              devAddr: inputData.devAddr,
              devEUI: inputData.devEUI,
              fCntUp: 0,
              fNwkSIntKey: inputData.fNwkSIntKey,
              nFCntDown: 0,
              nwkSEncKey: "68618d47e870dfd6352fffbcdd96f38d",
              sNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38d",
            },
          };
        } else if (
          inputData.lorawan == "1.1.x" &&
          inputData.enprocess == "OTAA"
        ) {
          device = {
            device: {
              //Static for now
              applicationID: "1",
              description: loraDesc,
              devEUI: inputData.devEUI,
              //Static for now
              deviceProfileID: "f58acd0c-4b48-445b-bf6c-3cabbea8ed0f",
              name: loraTitle,
              referenceAltitude: 0,
              skipFCntCheck: true,
              tags: {},
              variables: {},
            },
          };
          activate = {
            deviceActivation: {
              aFCntDown: 0,
              appSKey: inputData.appSKey,
              devAddr: "1bc081f8",
              devEUI: inputData.devEUI,
              fCntUp: 0,
              fNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38e",
              nFCntDown: 0,
              nwkSEncKey: "68618d47e870dfd6352fffbcdd96f38d",
              sNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38d",
            },
          };
        } else if (
          inputData.lorawan == "1.0.x" &&
          inputData.enprocess == "ABP"
        ) {
          device = {
            device: {
              //Static for now
              applicationID: "1",
              description: loraDesc,
              devEUI: inputData.deviceId,
              //Static for now
              deviceProfileID: "f58acd0c-4b48-445b-bf6c-3cabbea8ed0f",
              name: inputData.deviceName,
              referenceAltitude: 0,
              skipFCntCheck: true,
              tags: {},
              variables: {},
            },
          };
          activate = {
            deviceActivation: {
              aFCntDown: 0,
              appSKey: "2f9ae9e7eb62bdadd1d9437e4e11455d",
              devAddr: "1bc081f8",
              devEUI: inputData.deviceId,
              fCntUp: 0,
              fNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38e",
              nFCntDown: 0,
              nwkSEncKey: "68618d47e870dfd6352fffbcdd96f38d",
              sNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38d",
            },
          };
        } else if (
          inputData.lorawan == "1.0.x" &&
          inputData.enprocess == "OTAA"
        ) {
          device = {
            device: {
              //Static for now
              applicationID: "1",
              description: loraDesc,
              devEUI: inputData.devEUI,
              //Static for now
              deviceProfileID: "f58acd0c-4b48-445b-bf6c-3cabbea8ed0f",
              name: loraTitle,
              referenceAltitude: 0,
              skipFCntCheck: true,
              tags: {},
              variables: {},
            },
          };
          activate = {
            deviceActivation: {
              aFCntDown: 0,
              appSKey: inputData.appSKey,
              devAddr: "1bc081f8",
              devEUI: inputData.devEUI,
              fCntUp: 0,
              fNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38e",
              nFCntDown: 0,
              nwkSEncKey: "68618d47e870dfd6352fffbcdd96f38d",
              sNwkSIntKey: "68618d47e870dfd6352fffbcdd96f38d",
            },
          };
        }

        const deviceOptions = {
          url: "http://192.168.1.220:8080/api/devices",
          method: "POST",
          body: device,
          json: true,
          auth: {
            bearer: jwtAuth,
          },
          rejectUnauthorized: false,
        };
        //Save device
        const saveDevice = await request(deviceOptions);

        const activatedeviceOptions = {
          url: `http://192.168.1.220:8080/api/devices/${device.device.devEUI}/activate`,
          method: "POST",
          body: activate,
          json: true,
          auth: {
            bearer: jwtAuth,
          },
          rejectUnauthorized: false,
        };
        //Activate now
        const activateDevice = await request(activatedeviceOptions);
        //Adding device to LORA server ends
        //Get device configuration url and port from master DB
        //Get the protocol releated url and port
        const urlDetails = await configUrlModel.findOne({
          protocol: "lora",
        });

        // let tokenData = {
        //   deviceId: input.deviceId,
        //   macAddress: input.savedMDevice.macAddress
        // };

        // let token = await jwt.sign(
        //   {
        //     data: tokenData
        //   },
        //   config.dataHandlerAccessTokenSecret,
        //   { expiresIn: "60 days" }
        // );

        //LORA response
        const loraRes = {
          success: true,
          name: device.device.name,
          description: device.device.description,
          devEUI: device.device.devEUI,
          appEUI: device.device.applicationID,
          devAddr: activate.deviceActivation.devAddr,
          downlink: "Enabled",
          host: urlDetails.host,
          port: urlDetails.port,
        };
        return loraRes;
      }
    } catch (err) {
      console.log(err);
      return {
        success: false,
        error: "Internal Error",
        message:
          "Unableiiii to process LORA type devices at this moment. Please try after some time!",
      };
    }
  }
  //Controller helper function to handle MQTT protocol
  async mqtt(input, configUrlModel) {
    try {
      //Get device configuration url and port from master DB

      //Get the protocol releated url and port
      const urlDetails = await configUrlModel.findOne({ protocol: "mqtt" });

      //MQTT config
      let mqttConfig = {
        boroker: urlDetails.host, //dataHandlerHost
        portNo: urlDetails.port,
        topic: `${input.tenantId}/${input.savedMDevice.macAddress}`,
        username: input.savedMDevice.macAddress,
        password: randomize("a", 8),
      };

      //If it is a gateway
      if (input.gateway === true) {
        mqttConfig.topic = `${input.tenantId}/${input.savedMDevice.macAddress}/${input.helperId}`;
      }

      const hash = await bcrypt.hash(mqttConfig.password, 10);
      //Update this MQTT Credentials in Master Device collection
      const updateCre = {
        credentials: {
          username: input.macAddress,
          password: hash,
        },
      };
      await input.savedMDevice.updateOne({
        $set: updateCre,
      });
      //Return
      return mqttConfig;
    } catch (e) {
      let response = null;
      return response;
    }
  }
  //Controller helper function to handle API protocol
  async api(input, configUrlModel) {
    //Get device configuration url and port from master DB
    //Get the protocol releated url and port
    const urlDetails = await configUrlModel.findOne({ protocol: "api" });

    let tokenData = {
      deviceId: input.deviceId,
      macAddress: input.savedMDevice.macAddress,
    };

    let token = await jwt.sign(
      {
        data: tokenData,
      },
      config.dataHandlerAccessTokenSecret,
      { expiresIn: "60 days" }
    );
    //API response
    const apiRes = {
      callbackUrl: urlDetails.host,
      port: urlDetails.port,
      token,
    };
    return apiRes;
  }
  //Controller helper function to handle SIGFOX protocol
  async sigfox(input, configUrlModel) {
    //Get device configuration url and port from master DB
    //Get the protocol releated url and port
    const urlDetails = await configUrlModel.findOne({ protocol: "sigfox" });

    let tokenData = {
      deviceId: input.deviceId,
      macAddress: input.savedMDevice.macAddress,
    };

    // let token = await jwt.sign(
    //   {
    //     data: tokenData
    //   },
    //   config.dataHandlerAccessTokenSecret,
    //   { expiresIn: "60 days" }
    // );

    //Sigfox response
    const sigfoxRes = {
      callbackUrl: urlDetails.host,
      port: urlDetails.port,
      token,
    };
    return sigfoxRes;
  }
  //Controller helper function to handle TCP protocol
  async tcp(input, configUrlModel) {
    //Get device configuration url and port from master DB
    //Get the protocol releated url and port
    const urlDetails = await configUrlModel.findOne({ protocol: "tcp" });
    //TCP response
    const tcpRes = {
      callbackUrl: urlDetails.host,
      port: urlDetails.port,
    };
    return tcpRes;
  }
  //Controller helper function to handle UDP protocol
  async udp(input, configUrlModel) {
    //Get device configuration url and port from master DB
    //Get the protocol releated url and port
    const urlDetails = await configUrlModel.findOne({ protocol: "udp" });

    //UDP response
    const udpRes = {
      callbackUrl: urlDetails.host,
      port: urlDetails.port,
    };
    return udpRes;
  }

  //Controller helper function to handle MQTT protocol
  async http(input) {
    try {
      const inputData = underscore.isEmpty(input);
      if (inputData) {
        //Send error
        return {
          success: false,
          message:
            "Unable to process HTTP type devices due to empty input params!",
        };
      } else {
        //http config
        let httpConfig = {
          protocolType: input.protocolType,
          url: input.url,
          method: input.method,
          body: input.body,
          json: true,
          headers: input.headers,
          poolTime: input.poolTime,
        };

        //Return
        return httpConfig;
      }
    } catch (e) {
      let response = null;
      return response;
    }
  }

  //Class ends
}

const saveTOTSDB = async (tsdbData) => {
  const obj = {
    url: "http://localhost:3000/tsdb",
    method: "POST",
    body: tsdbData,
    json: true,
  };
  //Save device to TSDB
  const saveDevice = await request(obj);
  console.log(saveDevice);
};

/* 

# Controller helper function ends here


*/
