/*jshint esversion: 8 */
const mongoose = require("mongoose");
const async = require("async");

const underscore = require("underscore");
const logger = require("./../utils/logger");

//Require Customer Model
const Customer = require("./../models/Customer");

//Getting all customers
exports.getAllCustomers = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const CustomerModel = await Customer.model(tenantDb, "Customer");
    //Find all customers
    const customerList = await CustomerModel.find({})
      .select("-__v -is_active -createdAt -updatedAt")
      .skip(prev)
      .limit(next);
    //If there is no user
    if (!customerList.length > 0) {
      let response = {
        success: false,
        data: {
          code: 20,
          msg: "Customers not found !",
          results: []
        }
      };
      return res.status(200).send(response);
    }

    let response = {
      success: true,
      data: {
        code: 20,
        msg: "Customers found",
        results: customerList
      }
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err
      }
    });
  }
};
