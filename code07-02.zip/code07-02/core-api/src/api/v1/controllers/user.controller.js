/*jshint esversion: 8 */
const mongoose = require("mongoose");
const moment = require("moment");
const bcrypt = require("bcrypt");
const randtoken = require("rand-token").uid;
const logger = require("./../utils/logger");
const { mongoDb, logTypes } = require("./../../../constants");
const masterDb = mongoDb.masterDb;
//Mongo DB connection
const dbConn = require("./../../../config/express.config");
//Require User Model
const User = require("./../models/User");
//Require App Model
const App = require("../models/App");
//Require Site Model
const Site = require("./../models/Site");
//Require DataCount Model
const DataCount = require("./../models/DataCounts");
//Require Device Model
const Device = require("./../models/Device");
const PGDeviceData = require("../models/PgDeviceData");
//Require RoleAndRights model
const RoleAndRights = require("./../models/RoleAndRights");
//Require Auth Model
const Auth = require("./../models/Auth");
//Auth Util
let { AuthUtils } = require("./../utils/auth");
AuthUtils = new AuthUtils();
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();

//Tenant/User login
exports.signin = async (req, res) => {
  try {
    const db = await dbConn.mongoDbConn.useDb("hts-iot-platform-v1");
    const UserModel = await User.model(db, "user");
    const RoleAndRightsModel = await RoleAndRights.model(db, "role.rights");
    //Check if the mobile/email exists
    UserModel.findOne({
      "email.address": req.body.email,
    })
      .then(async (user) => {
        if (!user) {
          res.status(401).json({
            success: false,
            error: {
              code: 44,
              msg: "User does not exists",
            },
          });
        } else {
          bcrypt.compare(
            req.body.password,
            user.password,
            async function (err, result) {
              if (err) {
                return res.status(401).json({
                  success: false,
                  error: {
                    code: 41,
                    msg: "Auth Failed",
                  },
                });
              }
              if (result) {
                //Get user rights by providing roleId
                const rights = await RoleAndRightsModel.findById(
                  user.role
                ).select("rights -_id");
                if (!rights) {
                  return res.status(400).json({
                    success: false,
                    error: {
                      code: 40,
                      msg: "Something went wrong !",
                    },
                  });
                }
                //To attach the user's data in token
                const userDetails = {
                  email: user.email.address,
                  userId: user._id,
                  name: user.name,
                  rights: rights.rights,
                };
                //Generate token - add 1 hour expiry time
                //Call generateAccessToken function
                const accessToken = AuthUtils.generateAccessToken(userDetails);
                //Call generateRefereshToken function
                const refreshToken = await AuthUtils.generateRefreshToken(
                  userDetails
                );
                return (
                  res
                    .status(200)
                    //access-token
                    .header("auth-token", accessToken)
                    //refresh-token
                    .header("refresh-token", refreshToken)
                    .json({
                      success: true,
                      data: {
                        code: 20,
                        msg: "Login Successful",
                        results: {
                          name: user.name,
                          email: user.email.address,
                          mobile: user.mobile.number,
                          companyName: user.companyName,
                          rights: rights.rights,
                          timezone: user.timezone,
                          tenantId: user.tenant,
                        },
                      },
                    })
                );
              }
              return res.status(401).json({
                success: false,
                error: {
                  code: 41,
                  msg: "Password does not match !",
                },
              });
            }
          );
        }
      })
      .catch((err) => {
        console.log(err);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error",
            error: err,
          },
        });
      });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get Dashboard data
exports.getDashboardData = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Initialize counts
    let apps = 0;
    let devicesCount = 0;
    let sites = 0;
    let packets = {};

    //Get site Model
    const SiteModel = await Site.model(tenantDb, "site");
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Get app count
    apps = appIds.length;
    //Get site count
    sites = await SiteModel.countDocuments({});
    //Get Device count
    devicesCount = {};
    devicesCount.total = await DeviceModel.countDocuments({ app: appIds });
    devicesCount.online = await DeviceModel.countDocuments({
      app: appIds,
      state: true,
    });
    devicesCount.offline = await DeviceModel.countDocuments({
      app: appIds,
      state: false,
    });

    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    //Get device Model

    //Get all the deviceId for appId
    const devices = await DeviceModel.find({ app: appIds });
    if (devices.length < 1) {
      return res.status(404).json({
        success: false,
        data: {
          code: 50,
          msg: "Devices not found",
        },
      });
    }
    let deviceIds = [];
    devices.map(async (device) => {
      //Push
      deviceIds.push(device.deviceId);
    });
    let msgsCount = await pgConn.query(
      `Select count(1) totalMsgs, sum(size) upload from device_data where device_id IN(:deviceIds) and Date(time) >= date_trunc('month', CURRENT_DATE)`,
      {
        replacements: {
          deviceIds,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    let totalmsgs = "";
    let upload = "";
    if (msgsCount.length) {
      msgsCount = msgsCount[0];

      if (parseInt(msgsCount.totalmsgs) > 1000) {
        totalmsgs = `${parseInt(msgsCount.totalmsgs / 1000)} K`;
      } else {
        totalmsgs = msgsCount.totalmsgs;
      }

      if (parseInt(msgsCount.upload) > 1000) {
        upload = `${parseInt(msgsCount.upload / 1000)} K`;
      } else {
        upload = msgsCount.upload;
      }
    }

    let unResolvedAlerts = await pgConn.query(
      `select cast (count(resolved) as int) from device_events where resolved ='false' and device_id IN(:deviceIds) and event_type=:event_type`,
      {
        replacements: {
          event_type: "RULE_VALUE",
          deviceIds,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    let resolvedAlerts = await pgConn.query(
      `select cast(count(resolved) as int) from device_events where resolved ='true' and device_id IN(:deviceIds) and event_type=:event_type`,
      {
        replacements: {
          event_type: "RULE_VALUE",
          deviceIds,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );

    let events = {};
    events.unresolved = unResolvedAlerts.length ? unResolvedAlerts[0].count : 0;
    events.resolved = resolvedAlerts.length ? resolvedAlerts[0].count : 0;
    events.total = events.unresolved + events.resolved;
    if (parseInt(events.unresolved) > 1000) {
      events.unresolved = `${parseInt(events.unresolved / 1000)} K`;
    }
    if (parseInt(events.resolved) > 1000) {
      events.resolved = `${parseInt(events.resolved / 1000)} K`;
    }
    if (parseInt(events.total) > 1000) {
      events.total = `${parseInt(events.total / 1000)} K`;
    }
    //Send response
    const response = {
      success: true,
      data: {
        code: 20,
        msg: "Records found",
        results: {
          appsCount: apps,
          sitesCount: sites,
          devicesCount: devicesCount,
          packets: {
            totalmsgs: `${totalmsgs}`,
            upload: `${upload}`,
          },
          events,
        },
      },
    };

    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Change Password
exports.postChangePwd = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get old and new password from request
    const currPwd = req.body.oldPassword;
    const newPwd = req.body.newPassword;

    const masterDbConn = await tenantDb.useDb(masterDb);
    const UserModel = await User.model(masterDbConn, "user");
    //Get user id from JWT Token
    const userJWT = req.user;
    //Check if user exists
    const userCheck = await UserModel.findOne({
      _id: userJWT.userId,
    });
    if (!userCheck) {
      return res.status(409).json({
        success: false,
        error: {
          code: 49,
          msg: "User does not exists !",
        },
      });
    }

    //If valid user - Compare the current password
    const match = await bcrypt.compare(currPwd, userCheck.password);
    if (!match) {
      return res.status(401).json({
        success: false,
        error: {
          code: 41,
          msg: "Invalid password",
        },
      });
    }
    //Valid password, now hash the new  password
    //Generate Salt - with saltRounds 10
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(newPwd, salt);
    if (!hash || !salt) {
      return res.status(500).json({
        success: false,
        error: {
          code: 50,
          msg: "Internal error",
          error: err,
        },
      });
    }
    //Update the hashed password
    const update = {};
    update.password = hash;
    //Update the password now
    const updated = await userCheck.update({
      $set: update,
    });
    if (updated) {
      return res.status(200).json({
        success: true,
        data: {
          code: 20,
          msg: "Password changed",
        },
      });
    }
    //Something went wrong
    return res.status(400).json({
      success: false,
      error: {
        code: 40,
        msg: "Something went wrong !",
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
/* 

# Controller helper function starts here


*/
