/*jshint esversion: 8 */
const mongoose = require("mongoose");
const Sequelize = require("sequelize");
const moment = require("moment");
const underscore = require("underscore");
require("moment-timezone");
const { mongoDb } = require("./../../../constants");
//Get master db name
const masterDb = mongoDb.masterDb;
//Require App Model
const App = require("../models/App");
//Require Device Model
const Device = require("../models/Device");
//Require Alerts Model
const Alerts = require("../models/Alert");
//Require Rule Model
const Rule = require("../models/Rule");
//Require Data Model
const DeviceData = require("../models/PgDeviceData");
//Require User Model
const User = require("./../models/User");
//Require DataCount Model
const DataCount = require("../models/DataCounts");
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();

//Controllers
//Getting all alerts - by default it will give only list of all un-resolved alerts (Edited by Rajesh on 02-March-2020)
exports.getAllAlerts = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;

    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");
    //Device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Switch to master db to get users who resolved some alarms
    const masterDbConn = await tenantDb.useDb(masterDb);
    const UserModel = await User.model(masterDbConn, "user");
    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    let users = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    const data = await pgConn.query(
      "SELECT * FROM device_events where event_type=:event_type and rule_id IN(:ids) and resolved=:type ORDER BY time DESC OFFSET :offset limit :limit",
      {
        replacements: {
          event_type: "RULE_VALUE",
          type: "false",
          ids: ruleIds,
          offset: prev,
          limit: next,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    let meta = [];
    if (data.length > 0) {
      //Get deviceIds
      let deviceIds = [];
      //Get users who resolved alerts
      let userIds = [];

      //Push all deviceIds
      data.map((oneRec) => {
        deviceIds.push(oneRec.device_id);
      });
      //Push all resolved_by ids which is not null
      data.map((oneRec) => {
        if (oneRec.resolved_by != null) userIds.push(oneRec.resolved_by);
      });
      //Get meta info from mongo db
      //Find these deviceIds in mongo
      const devices = await DeviceModel.find({
        deviceId: { $in: deviceIds },
      })
        .select("name deviceId -_id")
        .populate({
          path: "app",
          select: "name -_id",
          model: tenantDb.models.app,
        });
      if (devices.length > 0) {
        meta = devices;
      }
      console.log("userIds ", userIds);
      //Find users who has resolved some alerts
      users = await UserModel.find({
        _id: { $in: userIds },
      }).select("name _id");
    }

    //Send response
    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        results: {
          devices: meta,
          rules,
          users,
          data,
        },
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Getting all alerts - by default it will give only list of all resolved alerts (Edited by Rajesh on 02-March-2020)
exports.getAllResolvedAlerts = async (req, res) => {
  try {
    /*

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    const resolvedData = [];
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");
    //Device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Switch to master db to get users who resolved some alarms
    const masterDbConn = await tenantDb.useDb(masterDb);
    const UserModel = await User.model(masterDbConn, "user");
    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    let users = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    const data = await pgConn.query(
      "SELECT * FROM device_events where event_type=:event_type and rule_id IN(:ids) and resolved=:type ORDER BY time DESC OFFSET :offset limit :limit",
      {
        replacements: {
          event_type: "RULE_VALUE",
          type: "true",
          ids: ruleIds,
          offset: prev,
          limit: next,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    let meta = [];
    if (data.length > 0) {
      //Get deviceIds
      let deviceIds = [];
      //Get users who resolved alerts
      let userIds = [];

      //Filter and Push all resolvedData
      // data.map(oneRec => {
      //   if (oneRec.resolved === true) {
      //     resolvedData.push(oneRec);
      //   }
      // });
      //Push all deviceIds
      data.map((oneRec) => {
        deviceIds.push(oneRec.device_id);
      });
      //Push all resolved_by ids which is not null
      data.map((oneRec) => {
        if (oneRec.resolved_by != null) userIds.push(oneRec.resolved_by);
      });
      //Get meta info from mongo db
      //Find these deviceIds in mongo
      const devices = await DeviceModel.find({
        deviceId: { $in: deviceIds },
      })
        .select("name deviceId -_id")
        .populate({
          path: "app",
          select: "name -_id",
          model: tenantDb.models.app,
        });
      if (devices.length > 0) {
        meta = devices;
      }
      console.log("userIds ", userIds);
      //Find users who has resolved some alerts
      users = await UserModel.find({
        _id: { $in: userIds },
      }).select("name _id");
    }

    //Send response
    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        results: {
          devices: meta,
          rules,
          users,
          data,
        },
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get graph data for all alerts
exports.getDataForAlertGraph = async (req, res) => {
  try {
    /*

    */

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");
    //Device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    const data = await pgConn.query(
      "SELECT to_char(Date(time), 'Day') as day, count(*),severity FROM device_events where event_type=:event_type and rule_id IN(:ids) and Date(time) > current_date - interval '7 days' GROUP BY Date(time),severity",
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    //Get last 7 days
    let days = [];
    let highSeverity = [];
    let mediumSeverity = [];
    let lowSeverity = [];

    //Last 7 days
    for (let index = 0; index < 7; index++) {
      const day = moment().subtract(index, "days").format("dddd");
      days.push(day);
    }

    days = days.reverse();
    //Push the high severity counts to highSeverity array
    if (data.length > 0) {
      //Loop through data array
      //Get all high severity 3 levels
      days.map((day) => {
        let count = "0";
        data.map((rec) => {
          if (rec.day.trim() === day && rec.severity === 3) {
            count = rec.count;
          }
        });
        highSeverity.push(count);
      });
      //Get all medium severity 2 levels
      days.map((day) => {
        let count = "0";
        data.map((rec) => {
          if (rec.day.trim() === day && rec.severity === 2) {
            count = rec.count;
          }
        });
        mediumSeverity.push(count);
      });
      //Get all low severity 1 levels
      days.map((day) => {
        let count = "0";
        data.map((rec) => {
          if (rec.day.trim() === day && rec.severity === 1) {
            count = rec.count;
          }
        });
        lowSeverity.push(count);
      });
    }
    //Send response
    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        results: {
          days,
          highSeverity,
          mediumSeverity,
          lowSeverity,
        },
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Update Alert's status - resolve true/false
//Get graph data for all alerts
exports.updateAlertStatus = async (req, res) => {
  try {
    /*

    */

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;

    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    console.log(req.body);
    console.log(req.params);

    //Get params
    const alarmId = req.params.alarmId;
    let desc = null;
    if (req.body.desc) {
      desc = req.body.desc;
    }
    //Get logged in userId
    const loggedInUser = req.user.userId.toString();

    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");
    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });

    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    // const subQuery =
    await pgConn.query(
      "update device_events set resolved = :status, remarks=:desc, resolved_by=:loggedInUser, resolved_at = timestamp without time zone 'now' where event_type=:event_type and id=:alarmId and rule_id IN(:ids)",
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
          status: true,
          alarmId,
          desc,
          loggedInUser,
        },
      }
    );
    //Format and send response
    //HTTP code can be 204
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "Status updated",
      },
    });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Un resolved Alerts Search - regex
exports.getUnResolvedAlertsSearch = async (req, res) => {
  try {
    /*

 */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    let appName = "";
    let deviceName = "";
    let alarmId = "";
    let deviceType = "";
    let severity = "";
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }
      //get appName from query
      if (req.query.appName) {
        appName = req.query.appName;
      }
      //get deviceName from query
      if (req.query.deviceName) {
        deviceName = req.query.deviceName;
      }
      //get alarmId from query
      if (req.query.alarmId) {
        alarmId = req.query.alarmId;
      }
      //get deviceType from query
      if (req.query.deviceType) {
        deviceType = req.query.deviceType;
      }
      //get severity from query
      if (req.query.severity) {
        severity = req.query.severity;
      }
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");
    //Device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Records found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    // regex match using "like" operator only works with non numeric types so to implemet regex in numerc "id" column, first cast it to varchar,
    //Note - casting to "char" will accept only 1 length char regex, varchar will accept more than one char regex
    const data = await pgConn.query(
      "SELECT * FROM device_events where resolved=:type and event_type=:event_type and rule_id IN(:ids) and CAST(id as varchar) LIKE :alarmRegex and CAST(severity as varchar) LIKE :severityRegex and device_type ILIKE :deviceTypeRegex ORDER BY time DESC OFFSET :offset limit :limit",
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
          type: "false",
          offset: prev,
          limit: next,
          alarmRegex: alarmId + "%",
          severityRegex: severity + "%",
          deviceTypeRegex: deviceType + "%",
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    let meta = [];
    if (data.length > 0) {
      //Get deviceIds
      let deviceIds = [];
      data.map((oneRec) => {
        deviceIds.push(oneRec.device_id);
      });
      //Get meta info from mongo db
      //Find these deviceIds in mongo
      const devices = await DeviceModel.find({
        $and: [
          {
            deviceId: { $in: deviceIds },
          },
          {
            name: {
              $regex: deviceName,
              $options: "i",
            },
          },
        ],
      })
        .select("name deviceId -_id")
        .populate({
          path: "app",
          select: "name -_id",
          match: {
            name: {
              $regex: appName,
              $options: "i",
            },
          },
          model: tenantDb.models.app,
        });
      if (devices.length > 0) {
        meta = devices;
      }
    }
    let response;
    //Some validation
    if (data.length < 1 || meta.length < 1 || rules.length < 1) {
      //Send response
      response = {
        success: false,
        data: {
          code: 20,
          msg: "No records found",
          results: {
            devices: [],
            rules: [],
            users: [],
            data: [],
          },
        },
      };
    } else {
      //Send response
      response = {
        success: data.length > 0 ? true : false,
        data: {
          code: 20,
          msg: data.length > 0 ? "Records found" : "No records found",
          results: {
            devices: meta,
            rules,
            users: [],
            data,
          },
        },
      };
    }

    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Resolved Alerts Search - regex
exports.getResolvedAlertsSearch = async (req, res) => {
  try {
    /*

 */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    let appName = "";
    let deviceName = "";
    let alarmId = "";
    let deviceType = "";
    let severity = "";
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }
      //get appName from query
      if (req.query.appName) {
        appName = req.query.appName;
      }
      //get deviceName from query
      if (req.query.deviceName) {
        deviceName = req.query.deviceName;
      }
      //get alarmId from query
      if (req.query.alarmId) {
        alarmId = req.query.alarmId;
      }
      //get deviceType from query
      if (req.query.deviceType) {
        deviceType = req.query.deviceType;
      }
      //get severity from query
      if (req.query.severity) {
        severity = req.query.severity;
      }
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");
    //Device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Records found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    // regex match using "like" operator only works with non numeric types so to implemet regex in numerc "id" column, first cast it to varchar,
    //Note - casting to "char" will accept only 1 length char regex, varchar will accept more than one char regex
    const data = await pgConn.query(
      "SELECT * FROM device_events where resolved=:type and event_type=:event_type and rule_id IN(:ids) and CAST(id as varchar) LIKE :alarmRegex and CAST(severity as varchar) LIKE :severityRegex and device_type ILIKE :deviceTypeRegex ORDER BY time DESC OFFSET :offset limit :limit",
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
          type: "true",
          offset: prev,
          limit: next,
          alarmRegex: alarmId + "%",
          severityRegex: severity + "%",
          deviceTypeRegex: deviceType + "%",
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    let meta = [];
    let users = [];
    const masterDbConn = await tenantDb.useDb(masterDb);
    const UserModel = await User.model(masterDbConn, "user");
    if (data.length > 0) {
      //Get deviceIds
      let deviceIds = [];
      let userIds = [];
      data.map((oneRec) => {
        deviceIds.push(oneRec.device_id);
      });
      //Push all resolved_by ids which is not null
      data.map((oneRec) => {
        if (oneRec.resolved_by != null) userIds.push(oneRec.resolved_by);
      });

      console.log("userIds ", userIds);
      //Find users who has resolved some alerts
      users = await UserModel.find({
        _id: { $in: userIds },
      }).select("name _id");
      //Get meta info from mongo db
      //Find these deviceIds in mongo
      const devices = await DeviceModel.find({
        $and: [
          {
            deviceId: { $in: deviceIds },
          },
          {
            name: {
              $regex: deviceName,
              $options: "i",
            },
          },
        ],
      })
        .select("name deviceId -_id")
        .populate({
          path: "app",
          select: "name -_id",
          match: {
            name: {
              $regex: appName,
              $options: "i",
            },
          },
          model: tenantDb.models.app,
        });
      if (devices.length > 0) {
        meta = devices;
      }
    }
    let response;
    //Some validation
    if (data.length < 1 || meta.length < 1 || rules.length < 1) {
      //Send response
      response = {
        success: false,
        data: {
          code: 20,
          msg: "No records found",
          results: {
            devices: [],
            rules: [],
            users: [],
            data: [],
          },
        },
      };
    } else {
      //Send response
      response = {
        success: data.length > 0 ? true : false,
        data: {
          code: 20,
          msg: data.length > 0 ? "Records found" : "No records found",
          results: {
            devices: meta,
            rules,
            users,
            data,
          },
        },
      };
    }

    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
//Get Recent alerts - of one device
exports.getDeviceAlerts = async (req, res) => {
  try {
    /*
    ! This API Needs some changes in repsonse format and execution steps
    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    let deviceRecentData;
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    let appIds = req.metaObj.apps;
    //Get deviceId
    const deviceId = req.params.deviceId;
    //Check
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    //Rule Model
    const RuleModel = await Rule.model(tenantDb, "rules");
    //Device Model
    const DeviceModel = await Device.model(tenantDb, "device");
    //Switch to master db to get users who resolved some alarms
    const masterDbConn = await tenantDb.useDb(masterDb);
    const UserModel = await User.model(masterDbConn, "user");

    //Find deviceId
    const device = await DeviceModel.findById(deviceId);
    //If deviceId does not exists
    if (!device) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "Device not found !",
          results: [],
        },
      });
    }
    //Find rules
    const rules = await RuleModel.find({
      app: { $in: appIds },
      deviceId: device.deviceId,
    }).select("_id desc");
    //When no alerts
    if (rules.length < 1) {
      return res.status(200).send({
        success: false,
        data: {
          code: 20,
          msg: "No Alerts found !",
          results: [],
        },
      });
    }
    let ruleIds = [];
    let users = [];
    rules.map((id) => {
      //Convert the mongo _id type to string
      ruleIds.push(id._id.toString());
    });
    //Get PG Connection
    const pgConn = req.metaPgObj.tenantDb;
    const data = await pgConn.query(
      "SELECT * FROM device_events where event_type=:event_type and rule_id IN(:ids) and device_id=:deviceId ORDER BY time DESC OFFSET :offset limit :limit",
      {
        replacements: {
          event_type: "RULE_VALUE",
          ids: ruleIds,
          deviceId: device.deviceId,
          offset: prev,
          limit: next,
        },
        type: pgConn.QueryTypes.SELECT,
      }
    );
    let meta = [];
    if (data.length > 0) {
      //Get deviceIds
      let deviceIds = [];
      //Get users who resolved alerts
      let userIds = [];
      //Push all deviceIds
      data.map((oneRec) => {
        deviceIds.push(oneRec.device_id);
      });
      //Push all resolved_by ids which is not null
      data.map((oneRec) => {
        if (oneRec.resolved_by !== null) userIds.push(oneRec.resolved_by);
      });
      //Get meta info from mongo db
      //Find these deviceIds in mongo
      const devices = await DeviceModel.find({
        deviceId: { $in: deviceIds },
      })
        .select("name deviceId -_id")
        .populate({
          path: "app",
          select: "name -_id",
          model: tenantDb.models.app,
        });
      if (devices.length > 0) {
        meta = devices;
      }
      //Find users who has resolved some alerts
      users = await UserModel.find({
        _id: { $in: userIds },
      }).select("name _id");

      //Get the recent device_data
      deviceRecentData = await pgConn.query(
        "SELECT * FROM device_data where device_id=:deviceId ORDER BY time DESC OFFSET :offset limit :limit",
        {
          replacements: {
            deviceId: device.deviceId,
            offset: prev,
            limit: next,
          },
          type: pgConn.QueryTypes.SELECT,
        }
      );
      console.log("deviceRecentData ", deviceRecentData);
    }

    //Send response
    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        results: {
          devices: meta,
          rules,
          users,
          data,
          deviceRecentData,
        },
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};
