/*jshint esversion: 8 */
const mongoose = require("mongoose");
const logger = require("./../utils/logger");
const underscore = require("underscore");
//Import Joi
const Joi = require("@hapi/joi");
//Require Customer Model
const Customer = require("./../models/Customer");
//Require Site Model
const Site = require("./../models/Site");
//Require Util module
const Keys = require("./../utils/keys");
//Require Device Model
const Device = require("./../models/Device");
const { logTypes } = require("./../../../constants");
let { UtilFunctions } = require("../utils");
UtilFunctions = new UtilFunctions();
const collections = UtilFunctions.collectionNames();
//Db logger
let { DbLogger } = require("./../utils/dbLogger");
//Add site - Author Rajesh
exports.addSite = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    const appId = req.body.appId;
    const deviceIds = req.body.deviceId;
    const apps = await tenantDb.models.app.find({ _id: appId });

    if (apps.length > 0) {
      //Application  exists check device for this app
      //Device Model
      const deviceColl = "device";
      const DeviceModel = await Device.model(tenantDb, deviceColl);
      //const devices = await DeviceModel.find({ _id: deviceId });
      const devices = deviceIds;
      let parentId = "";

      if (req.body.parentId) {
        parentId = req.body.parentId;
      }

      //Devices  exists , add site
      //Generate siteId
      const siteId = await Keys.getDeviceId();
      //Site Model
      const siteColl = "site";
      const SiteModel = await Site.model(tenantDb, siteColl);

      const tenantSite = new SiteModel({
        _id: new mongoose.Types.ObjectId(),
        name: req.body.name,
        siteId: siteId,
        app: req.body.appId,
        lat: req.body.lat,
        lng: req.body.lng,
        address: req.body.address,
        metadata: req.body.metadata,
        parentId: parentId,
      });
      console.log("tenantSite ", tenantSite);
      try {
        const SiteDetails = await tenantSite.save();
        console.log("SiteDetails ", SiteDetails);
        //Update the site _id in all devices in tenant level
        devices.map(async (deviceId) => {
          let deviceDetails = await DeviceModel.find({ _id: deviceId });
          if (deviceDetails.length > 0) {
            await DeviceModel.update(
              { _id: deviceId },
              { $set: { site: SiteDetails._id } }
            );
          }
        });
        try {
          //DB Logger
          const logged = await DbLogger(
            req.user,
            req.metaObj.tenantId,
            req.metaObj.tenantDbName,
            req.metaObj.tenantName,
            logTypes.site.added,
            true,
            {
              siteName: tenantSite.name,
              siteId: tenantSite.siteId,
              appId: req.body.appId,
              msg: "Site Added!",
            }
          );
          if (logged) {
            console.log("Data logged !");
          }
        } catch (e) {
          console.log("Data could not logged !", e);
        }
        return res.status(200).json({
          success: false,
          data: {
            code: 20,
            msg: "Site details added successfully and devices are assigned ",
            results: SiteDetails,
          },
        });
      } catch (e) {
        console.log(e);
        return res.status(500).json({
          success: false,
          error: {
            code: 50,
            msg: "Internal error : Error in saving site details",
            results: e,
          },
        });
      }
    } else {
      //Application does not exists
      return res.status(404).json({
        success: false,
        error: {
          code: 44,
          msg: "Application does not exists !",
          results: [],
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error : DB problem ",
        results: err,
      },
    });
  }
};

//Get all sites of a tenant - with pagination - Author Rajesh
exports.getAllSites = async (req, res) => {
  try {
    /*

    //Validation needs to be done 

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    //console.log("mongooseTAppIds ", mongooseTAppIds);
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Site Model
    const siteColl = "site";
    const SiteModel = await Site.model(tenantDb, siteColl);

    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      {
        $match: {
          app: {
            $in: mongooseTAppIds,
          },
        },
      },
      { $match: { parentId: "" } },
      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $project: {
          site: "$$ROOT",
        },
      },

      {
        $lookup: {
          from: "apps",
          localField: "site.app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $project: {
          site: 1,
          app: {
            $arrayElemAt: ["$app", 0],
          },
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          site: 1,
          app: 1,
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $lookup: {
          from: "devices",
          localField: "_id",
          foreignField: "site",
          as: "device",
        },
      },
      {
        $project: {
          _id: 0,
          site: 1,
          "app._id": 1,
          "app.name": 1,
          "app.customer": 1,
          "customer._id": 1,
          "customer.name": 1,
          "device._id": 1,
          "device.name": 1,
          "device.macAddress": 1,
          "device.deviceId": 1,
          "device.protocolType": 1,
          "device.lat": 1,
          "device.lng": 1,
        },
      },
    ];
    //const data = await SiteModel.aggregate(pipeline);

    // Models

    const CustomerModel = await Customer.model(tenantDb, "customer");
    const DeviceModel = await Device.model(tenantDb, "device");

    const data = await SiteModel.find({
      app: {
        $in: mongooseTAppIds,
      },
      parentId: "",
    })
      .select("-__v -createdAt -updatedAt")
      .populate({
        path: "app",
        select: "name _id customer",
        model: tenantDb.models.app,
        populate: {
          path: "customer",
          select: "name _id ",
          model: CustomerModel,
        },
      });

    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        count: data.length,
        results: data,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log("aaa" + err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: err.message,
        data: err,
      },
    });
  }
};
//Site Search - regex -Author Rajesh
exports.getSitesForSearch = async (req, res) => {
  try {
    let prev = 0;
    let next = 10;
    let appName = null;
    let siteName = null;
    let matchRegex = {};
    let customer = null;
    let address = null;
    let matchAppRegex = {};
    let matchCustomerRegex = {};
    //Check if query string exists
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    //console.log("mongooseTAppIds ", mongooseTAppIds);
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      if (req.query.prev) {
        prev = parseInt(req.query.prev);
      }
      if (req.query.prev) {
        next = parseInt(req.query.next);
      }

      if (req.query.siteName) {
        siteName = req.query.siteName;
        matchRegex.name = {
          $regex: siteName,
          $options: "i",
        };
      }

      if (req.query.address) {
        address = req.query.address;
        matchRegex.name = {
          $regex: address,
          $options: "i",
        };
      }

      if (req.query.appName) {
        appName = req.query.appName;
        matchAppRegex["app.name"] = {
          $regex: appName,
          $options: "i",
        };
      }

      if (req.query.customer) {
        customer = req.query.customer;
        matchCustomerRegex["customer.name"] = {
          $regex: customer,
          $options: "i",
        };
      }
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Site Model
    const siteColl = "site";
    const SiteModel = await Site.model(tenantDb, siteColl);
    //const CustomerModel = await Customer.model(tenantDb, "customer");
    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      { $match: matchRegex },

      {
        $match: {
          app: {
            $in: mongooseTAppIds,
          },
        },
      },

      {
        $skip: prev,
      },
      {
        $limit: next,
      },
      {
        $project: {
          site: "$$ROOT",
        },
      },

      {
        $lookup: {
          from: "apps",
          localField: "site.app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $project: {
          site: 1,
          app: {
            $arrayElemAt: ["$app", 0],
          },
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          site: 1,
          app: 1,
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $lookup: {
          from: "devices",
          localField: "_id",
          foreignField: "site",
          as: "device",
        },
      },
      {
        $project: {
          _id: 0,
          site: 1,
          "app._id": 1,
          "app.name": 1,
          "app.customer": 1,
          "customer._id": 1,
          "customer.name": 1,
          "device._id": 1,
          "device.name": 1,
          "device.macAddress": 1,
          "device.deviceId": 1,
          "device.protocolType": 1,
          "device.lat": 1,
          "device.lng": 1,
        },
      },
      { $match: matchAppRegex },
      { $match: matchCustomerRegex },
    ];
    const data = await SiteModel.aggregate(pipeline);

    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        count: data.length,
        results: data,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log("aaa" + err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error: Getting sites",
        data: err,
      },
    });
  }
};

//Site edit - Author Rajesh

exports.updateSite = async (req, res) => {
  try {
    //Get tenant DB
    const tenantDb = req.metaObj.tenantDb;
    const siteId = req.params.siteId;
    if (!tenantDb) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }

    try {
      const input = req.body;

      const SiteModel = await Site.model(tenantDb, collections.site);
      //Device Model
      const DeviceModel = await Device.model(tenantDb, collections.device);

      const { name, lat, lng, address, metaData, devices } = req.body;
      //If valid siteId, make a update obj
      let updateData = {};
      if (name) {
        //Get Name
        updateData.name = name;
      }
      if (lat) {
        //Get latitude
        updateData.lat = lat;
      }
      if (lng) {
        //Get longitude
        updateData.lng = lng;
      }
      if (address) {
        //Get address
        updateData.address = address;
      }
      if (metaData) {
        //Get metaData
        updateData.metadata = metaData;
      }

      const siteUpdate = await SiteModel.updateOne(
        { _id: siteId },
        { $set: updateData }
      );

      //If any new device added for same site update device site _id in the device collection
      if (devices) {
        devices.map(async (deviceId) => {
          let deviceDetails = await DeviceModel.find({ _id: deviceId });
          if (deviceDetails.length > 0) {
            await DeviceModel.updateOne(
              { _id: deviceId },
              { $set: { site: siteId } }
            );
          }
        });
      }
      if (siteUpdate) {
        try {
          //DB Logger
          const logged = await DbLogger(
            req.user,
            req.metaObj.tenantId,
            req.metaObj.tenantDbName,
            req.metaObj.tenantName,
            logTypes.site.updated,
            true,
            {
              siteName: siteUpdate.name,
              msg: "Site Updated!",
            }
          );
          if (logged) {
            console.log("Data logged !");
          }
        } catch (e) {
          console.log("Data could not logged !", e);
        }
        return res.status(200).json({
          success: true,
          data: {
            code: 20,
            msg: "Site details updated successfully",
          },
        });
      }

      //Something went wrong
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    } catch (err) {
      console.log(err);
      return res.status(422).json({
        success: false,
        data: {
          code: 42,
          msg: "Invalid request data !",
        },
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Delete one site and remove site id in all devices for this site - Author Rajesh
exports.deleteSite = async (req, res) => {
  try {
    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    //Get siteId from request
    const siteId = req.params.siteId;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Get device Model
    const DeviceModel = await Device.model(tenantDb, "device");

    //Get Site collection
    const SiteModel = await Site.model(tenantDb, "site");
    const siteDetails = await SiteModel.find({ parentId: siteId }).select(
      "_id "
    );
    console.log("siteDetails ", siteDetails);

    const getChildren = (value, SiteModel) => {
      //console.log(parentSite._id);
      // get sites children
      return new Promise(async (resolve, reject) => {
        SiteModel.find({
          parentId: value._id,
        })
          .select("_id ")
          .then(async (childs) => {
            if (childs.length > 0) {
              Promise.all(
                childs.map((child) => getChildren(child, SiteModel))
              ).then((children) => {
                let sites = [];
                sites.push({ ...value._doc });
                children.map((data) => {
                  sites.push(data);
                });

                //resolve({ ...value._doc, children });
                resolve(sites);
              });
            } else {
              //console.log("Parent Site", parentSite);
              resolve({ ...value._doc });
            }
            //console.log("============================================");
          });
      });
    };

    const propertyPhotoList = await Promise.all(
      await siteDetails.map(async (site) => {
        //console.log(site.site.name);
        const response = await getChildren(site, SiteModel);
        return await response;
      })
    );

    let merged = [].concat.apply([], propertyPhotoList);
    console.log("All sites ", merged);
    merged.push({ _id: siteId }); //push the site sent in params also to delete list
    await merged.map(async (site) => {
      //Find siteId in device collection and get all devices for this site
      let siteDevices = await DeviceModel.find({ site: site._id });

      if (siteDevices.length > 0) {
        //delete all site devices and delete site
        //Map all siteDevices and update the site information in devices to null or ""
        //console.log("siteDevices ", siteDevices);
        let async = require("async");
        await async.each(
          siteDevices,
          async function (device, callback) {
            //console.log("device in async ", device._id);
            let deviceId = device._id;
            await DeviceModel.updateOne(
              { _id: deviceId },
              { $unset: { site: 1 } }
            );
            //callback();
          },
          async function (err) {
            // if any of the file processing produced an error, err would equal that error
            if (err) {
              console.log(err);
              return res.status(500).json({
                success: false,
                error: {
                  code: 50,
                  msg: "Internal error",
                  error: err,
                },
              });
            } else {
              console.log("All devices have been processed successfully");
              //Remove site
              let presentSite = await SiteModel.findOne({ _id: site._id });
              await presentSite.deleteOne();
            }
          }
        );
      } else {
        //delete only site
        let presentSite = await SiteModel.findOne({
          _id: siteId._id,
        });
        await presentSite.deleteOne();
      }
    });
    try {
      //DB Logger
      const logged = await DbLogger(
        req.user,
        req.metaObj.tenantId,
        req.metaObj.tenantDbName,
        req.metaObj.tenantName,
        logTypes.site.removed,
        true,
        {
          siteId: siteId,
          msg: "Site Removed!",
        }
      );
      if (logged) {
        console.log("Data logged !");
      }
    } catch (e) {
      console.log("Data could not logged !", e);
    }
    return res.status(200).json({
      success: true,
      data: {
        code: 20,
        msg: "Site removed !",
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error",
        error: err,
      },
    });
  }
};

//Get all sites of a tenant - with out pagination - Author Rajesh
exports.getAllSitesWithOutPagination = async (req, res) => {
  try {
    /*

    //Validation needs to be done 

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    //console.log("mongooseTAppIds ", mongooseTAppIds);
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Site Model
    const siteColl = "site";
    const SiteModel = await Site.model(tenantDb, siteColl);

    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      {
        $match: {
          app: {
            $in: mongooseTAppIds,
          },
        },
      },
      {
        $project: {
          site: "$$ROOT",
        },
      },

      {
        $lookup: {
          from: "apps",
          localField: "site.app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $project: {
          site: 1,
          app: {
            $arrayElemAt: ["$app", 0],
          },
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          site: 1,
          app: 1,
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $lookup: {
          from: "devices",
          localField: "_id",
          foreignField: "site",
          as: "device",
        },
      },
      {
        $project: {
          _id: 0,
          site: 1,
          "app._id": 1,
          "app.name": 1,
          "app.customer": 1,
          "customer._id": 1,
          "customer.name": 1,
          "device._id": 1,
          "device.name": 1,
          "device.macAddress": 1,
          "device.deviceId": 1,
          "device.protocolType": 1,
          "device.lat": 1,
          "device.lng": 1,
        },
      },
    ];
    const data = await SiteModel.aggregate(pipeline);
    const response = {
      success: data.length > 0 ? true : false,
      data: {
        code: 20,
        msg: data.length > 0 ? "Records found" : "No records found",
        count: data.length,
        results: data,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log("aaa" + err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: "Internal error: Getting sites",
        data: err,
      },
    });
  }
};

//Get all Parent-Child sites of a tenant - with pagination - Author Rajesh
exports.getAllParentChildSites = async (req, res) => {
  try {
    /*

    //Validation needs to be done 

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    //console.log("mongooseTAppIds ", mongooseTAppIds);
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    //Site Model
    const siteColl = "site";
    const SiteModel = await Site.model(tenantDb, siteColl);
    const CustomerModel = await Customer.model(tenantDb, "customer");
    const DeviceModel = await Device.model(tenantDb, "device");
    const pipeline = [
      // {
      //   $sort: {
      //     created_at: -1,
      //   },
      // },
      {
        $match: {
          app: {
            $in: mongooseTAppIds,
          },
        },
      },
      // { $match: { parentId: "" } },
      // {
      //   $skip: prev,
      // },
      // {
      //   $limit: next,
      // },
      // {
      //   $project: {
      //     site: "$$ROOT",
      //   },
      // },

      // {
      //   $lookup: {
      //     from: "apps",
      //     localField: "site.app",
      //     foreignField: "_id",
      //     as: "app",
      //   },
      // },
      // {
      //   $project: {
      //     site: 1,
      //     app: {
      //       $arrayElemAt: ["$app", 0],
      //     },
      //   },
      // },
      // {
      //   $lookup: {
      //     from: "customers",
      //     localField: "app.customer",
      //     foreignField: "_id",
      //     as: "customer",
      //   },
      // },
      // {
      //   $project: {
      //     site: 1,
      //     app: 1,
      //     customer: {
      //       $arrayElemAt: ["$customer", 0],
      //     },
      //   },
      // },

      {
        $graphLookup: {
          from: "sites",
          startWith: "$parentId",
          connectFromField: "_id",
          connectToField: "parentId",
          as: "children",
        },
      },
      {
        $project: {
          // _id: 0,
          // site: 1,
          // "app._id": 1,
          // "app.name": 1,
          // "app.customer": 1,
          // "customer._id": 1,
          // "customer.name": 1,
          children: 1,
          // "device._id": 1,
          // "device.name": 1,
          // "device.macAddress": 1,
          // "device.deviceId": 1,
          // "device.protocolType": 1,
          // "device.lat": 1,
          // "device.lng": 1,
        },
      },
    ];
    const dataAggregate = await SiteModel.aggregate(pipeline);
    //===============================================================================================
    const data = await SiteModel.find({
      app: {
        $in: mongooseTAppIds,
      },
    })
      .select("-__v -createdAt -updatedAt")
      .populate({
        path: "app",
        select: "name _id customer",
        model: tenantDb.models.app,
        populate: {
          path: "customer",
          select: "name _id ",
          model: CustomerModel,
        },
      });
    const parentSites = [];

    await data.map(async (site) => {
      //console.log(site.parentId);
      if (site.parentId == "") {
        //let devices = await DeviceModel.find({ site: site._id });
        // console.log(devices);
        // site.devices = devices;
        parentSites.push(site);
      }
    });

    //Promise.all(parentSites);
    //console.log("parentSites ", parentSites);

    const getChildren = (value, SiteModel) => {
      //console.log(parentSite._id);
      // get sites children
      return new Promise(async (resolve, reject) => {
        SiteModel.find({
          parentId: value._id,
        })
          .select("-__v -createdAt -updatedAt")
          .populate({
            path: "app",
            select: "name _id customer",
            model: tenantDb.models.app,
            populate: {
              path: "customer",
              select: "name _id ",
              model: CustomerModel,
            },
          })
          .then(async (childs) => {
            if (childs.length > 0) {
              Promise.all(
                childs.map((child) => getChildren(child, SiteModel))
              ).then(
                (children) => {
                  resolve({ value, children });
                }
                // let child = Promise.all(
                //   await children.map(async child => {
                //     //console.log(child.name);
                //     let children_ = await getChildren(child, SiteModel);
                //     return await children_;
                //     //resolve({ parentSite, children: children_ });
                //   })
              );

              //console.log("child ", child);

              //console.log("Childs sites", { parentSite, children: children });
              // some children are present
              //resolve({ parentSite, children: child });
            } else {
              //console.log("Parent Site", parentSite);
              resolve({ value, childern: [] });
            }
            //console.log("============================================");
          });
      });
    };

    const propertyPhotoList = await Promise.all(
      await parentSites.map(async (site) => {
        //console.log(site.site.name);
        const response = await getChildren(site, SiteModel);
        return await response;
      })
    );
    //================================================================================================
    const response = {
      success: propertyPhotoList.length > 0 ? true : false,
      data: {
        code: 20,
        msg:
          propertyPhotoList.length > 0 ? "Records found" : "No records found",
        count: propertyPhotoList.length,
        results: propertyPhotoList,
      },
    };
    return res.status(200).send(response);
  } catch (err) {
    console.log("aaa" + err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: err.message,
        data: err,
      },
    });
  }
};

//Get all child sites of a parent Id - with out pagination - Author Rajesh
exports.getAllChildSites = async (req, res) => {
  try {
    /*

    //Validation needs to be done 

    */
    //Get Query params for pagination
    //Default next and previous
    let prev = 0;
    let next = 10;
    //Get mongoose type app _ids
    const mongooseTAppIds = req.metaObj.mongooseTAppIds;
    //console.log("mongooseTAppIds ", mongooseTAppIds);
    //Check if query string exists
    const input = underscore.isEmpty(req.query);
    if (!input) {
      //Check prev and next count from query string
      prev = parseInt(req.query.prev);
      next = parseInt(req.query.next);
    }

    //Get tenant DB and apps
    const tenantDb = req.metaObj.tenantDb;
    const appIds = req.metaObj.apps;
    if (!tenantDb || !appIds) {
      return res.status(400).json({
        success: false,
        error: {
          code: 40,
          msg: "Something went wrong !",
        },
      });
    }
    // Models

    const SiteModel = await Site.model(tenantDb, "site");
    const CustomerModel = await Customer.model(tenantDb, "customer");
    const DeviceModel = await Device.model(tenantDb, "device");

    const pipeline = [
      {
        $sort: {
          created_at: -1,
        },
      },
      {
        $match: {
          app: {
            $in: mongooseTAppIds,
          },
        },
      },
      { $match: { parentId: req.params.parentId } },
      // {
      //   $skip: prev,
      // },
      // {
      //   $limit: next,
      // },
      {
        $project: {
          site: "$$ROOT",
        },
      },

      {
        $lookup: {
          from: "apps",
          localField: "site.app",
          foreignField: "_id",
          as: "app",
        },
      },
      {
        $project: {
          site: 1,
          app: {
            $arrayElemAt: ["$app", 0],
          },
        },
      },
      {
        $lookup: {
          from: "customers",
          localField: "app.customer",
          foreignField: "_id",
          as: "customer",
        },
      },
      {
        $project: {
          site: 1,
          app: 1,
          customer: {
            $arrayElemAt: ["$customer", 0],
          },
        },
      },
      {
        $lookup: {
          from: "devices",
          localField: "_id",
          foreignField: "site",
          as: "device",
        },
      },
      {
        $project: {
          _id: 0,
          site: 1,
          "app._id": 1,
          "app.name": 1,
          "app.customer": 1,
          "customer._id": 1,
          "customer.name": 1,
          "device._id": 1,
          "device.name": 1,
          "device.macAddress": 1,
          "device.deviceId": 1,
          "device.protocolType": 1,
          "device.lat": 1,
          "device.lng": 1,
        },
      },
    ];
    //const data = await SiteModel.aggregate(pipeline);

    const data = await SiteModel.find({
      app: {
        $in: mongooseTAppIds,
      },
      parentId: req.params.parentId,
    })
      .select("-__v -createdAt -updatedAt")
      .populate({
        path: "app",
        select: "name _id customer",
        model: tenantDb.models.app,
        populate: {
          path: "customer",
          select: "name _id ",
          model: CustomerModel,
        },
      });

    if (data.length > 0) {
      const response = {
        success: data.length > 0 ? true : false,
        data: {
          code: 20,
          msg: data.length > 0 ? "Records found" : "No records found",
          count: data.length,
          results: data,
        },
      };
      return res.status(200).send(response);
    } else {
      const devices = await DeviceModel.find({
        site: req.params.parentId,
      })
        .select("name app address lat lng")
        .populate({
          path: "app",
          select: "name _id customer",
          model: tenantDb.models.app,
          populate: {
            path: "customer",
            select: "name _id ",
            model: CustomerModel,
          },
        });
      const response = {
        success: devices.length > 0 ? true : false,
        data: {
          code: 20,
          msg: devices.length > 0 ? "Records found" : "No records found",
          count: devices.length,
          results: devices,
        },
      };
      return res.status(200).send(response);
    }

    // let deviceData = await data.map(async (site) => {
    //   const devices = await DeviceModel.find({
    //     site: site._id,
    //   })
    //     .select("name app address lat lng")
    //     .populate({
    //       path: "app",
    //       select: "name _id customer",
    //       model: tenantDb.models.app,
    //       populate: {
    //         path: "customer",
    //         select: "name _id ",
    //         model: CustomerModel,
    //       },
    //     });
    //   // const devices = await DeviceModel.find({ site: site._id }).select(
    //   //   "-__v"
    //   // );
    //   // let loraObj = site;
    //   // return (loraObj = { ...loraObj._doc, devices });
    //   let finalDevices = [];
    //   finalDevices.push(site);
    //   await Promise.all(
    //     await devices.map(async (data) => {
    //       // if (finalDevices.length > 0) {
    //       //   finalDevices.push(data);
    //       // } else {
    //       //   finalDevices.push(site);
    //       // }
    //       finalDevices.push(data);
    //     })
    //   );
    //   return finalDevices;
    //   // if (finalDevices.length > 0) {
    //   //   return finalDevices;
    //   // } else {
    //   //   return data;
    //   // }
    // });

    // let finalData = await Promise.all(deviceData);

    // const response = {
    //   success: finalData.length > 0 ? true : false,
    //   data: {
    //     code: 20,
    //     msg: finalData.length > 0 ? "Records found" : "No records found",
    //     count: finalData.length,
    //     results: finalData,
    //   },
    // };
    // return res.status(200).send(response);
  } catch (err) {
    console.log("aaa" + err);
    return res.status(500).json({
      success: false,
      error: {
        code: 50,
        msg: err.message,
        data: err,
      },
    });
  }
};
