/*jshint esversion: 8 */
const mongoose = require('mongoose');
const moment = require('moment');
const connUri =
  'mongodb://dbadmin:hts2019@192.168.1.220:12345/ujetre-tenant-db';
const {
  tenantDbSuffix,
  mongoDb
} = require('./../../../constants');

mongoose.connect(
  connUri, {
    reconnectTries: Number.MAX_VALUE,
    useNewUrlParser: true,
    autoReconnect: true,
    useUnifiedTopology: true
  },
  function (err, db) {
    if (err) {
      console.log('<----------------------------------------------->');
      console.log('Rx Tx DB filed to connect : ' + err.message);
      console.log('<----------------------------------------------->');
      return;
    } else {
      console.log('Rx Tx DB Connected successfully on ', connUri);
      console.log('<----------------------------------------------->');

      //========================================================================================
      const cron = require('node-cron');
      var now = moment();
      var currentDate = moment(now, 'YYYY-MM-DD hh:mm:ss a');
      var start = moment(currentDate, 'YYYY-MM-DD hh:mm:ss a');

      // cron wont start automatically
      var task = cron.schedule(
        '* * * * * *',
        () => {
          //console.log(start.format('YYYY-MM-DD hh:mm:ss a'));
          let collection = db.collection('data.counts');
          collection
            .findOne({
              type: 'dataPackets'
            })
            .then(device => {
              if (device) {
                //console.log('device....', device);

                collection.updateOne({
                  _id: device._id
                }, {
                  $set: {
                    'data.get': device.data.get + Math.floor(Math.random() * 11),
                    'data.post': device.data.post + Math.floor(Math.random() * 11)
                  }
                });
              } else {
                var data = {
                  type: 'dataPackets',
                  data: {
                    get: 1212,
                    post: 120
                  }
                };

                collection.insert(data);
              }
              start.add(1, 'seconds');
            })
            .catch(err => {
              console.log(err);
            });
        }, {
          scheduled: false
        }
      );

      // start method is called to start the above defined cron job
      task.start();
    }
  }
);