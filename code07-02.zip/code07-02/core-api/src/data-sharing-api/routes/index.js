/*jshint esversion: 8 */
//Require express and router
const express = require("express");
const router = express.Router();
//Require controller
const controller = require("./../controllers");
//Auth middleware
const auth = require("../middlewares/auth");
//Index Status Check
router.get("/", (req, res, next) => {
  res.status(200).json({
    code: 20,
    msg: "Running",
  });
});

/**
 * Mount all the routes
 */
//Sigin with app tokens
router.route("/signin").post(controller.signin);

//Normal sigin
router.route("/general-signin").post(auth, controller.generalSignin);

//Get All sites
router.route("/apps").get(auth, controller.getApp);

//Get All devices
router.route("/devices").get(auth, controller.getAllDevices);
//Get All sites
router.route("/sites").get(auth, controller.getAllSites);
//Get Device Raw data from PGDB
router.route("/devices/:deviceId/data").get(auth, controller.getDeviceData);
//Send Command to device - EMQX
router.route("/mqtt/command").post(auth, controller.sendMqttCommand);
//Send TCP command to device
router.route("/tcp/command").post(auth, controller.sendTcpCommand);
//Get all alerts
router.route("/deviceStatus/data").get(auth, controller.getAllDeviceStatus);
//Add Device
router.route("/devices").post(auth, controller.addDevice);

module.exports = router;
