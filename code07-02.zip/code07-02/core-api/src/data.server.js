/*jshint esversion: 8 */
const { dataSharingPort, env, ip } = require("./constants");
//Require Data Server express config
const app = require("./config/ds.express.config");
//Require Chalk
const chalk = require("chalk");
//
const logger = require("./api/v1/utils/logger");
// listen to requests
app.listen(dataSharingPort, ip, err => {
  if (err) {
    console.log(" Data Sharing Server failed to start", err);
    //Logger
    return logger.info(" Data Sharing Server failed to start", err);
  }
  console.log(
    chalk.greenBright(`\n-------\n Data Sharing Server is Running->
        mode: [${chalk.magentaBright(`${env}`)}]
        url: [${chalk.magentaBright(
          `http://${ip}:${dataSharingPort}`
        )}]\n-------`)
  );
  //Logger
  return logger.info(
    ` Data Sharing Server is running at http://${ip}:${dataSharingPort}`
  );
});
