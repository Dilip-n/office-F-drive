const { test, expect } = require("@playwright/test");
const { airQualityCreds } = require("../../config");
const fs = require("fs");
const fileName = "../../result.json";
const file = require(fileName);

test("test", async ({ page }) => {
  await page.goto(airQualityCreds.host + "/login");

  await page.click('input[type="username"]');

  await page.fill('input[type="username"]', airQualityCreds.username);

  await page.click('input[type="password"]');

  await page.fill('input[type="password"]', airQualityCreds.password);

  await Promise.all([
    page.waitForNavigation(/*{ url: `${airQualityCreds.host}/dashboard` }*/),
    page.click('button:has-text("Login")'),
  ]);
  await page.waitForLoadState("networkidle");
  const url = await page.url();
  let value = "";
  if (url === `${airQualityCreds.host}/dashboard`) {
    value = "UP";
  } else {
    value = "Down";
  }
  file.data[5].status = value;

  const AQMlastUpdatedlocator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/span[3]"
  );
  const AQMlastUpdatedlocator_innertext4 =
    await AQMlastUpdatedlocator.innerText();
  file.data[5].LastupdatedAt = AQMlastUpdatedlocator_innertext4;

  console.log("last updated time", AQMlastUpdatedlocator_innertext4);

  if (value === "UP") {
    file.data[5].login = "YES";
  } else {
    file.data[5].login = "No";
  }

  await page.click('button:has-text("Sites")');

  await expect(page).toHaveURL(`${airQualityCreds.host}/sites`);
  await page.waitForLoadState("networkidle");
  await page.click(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/button[1]"
  );

  await page.waitForLoadState("networkidle");

  const query2statuslocator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[4]/span[1]"
  );
  const query2status = await query2statuslocator.innerText();

  const query2namelocator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]"
  );
  const query2name = await query2namelocator.innerText();

  console.log(`${query2name} is ${query2status}`);

  await page.waitForLoadState("networkidle");
  const query1statuslocator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[4]/span[1]"
  );
  const query1status = await query1statuslocator.innerText();
  const query1namelocator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/button[1]"
  );
  const query1name = await query1namelocator.innerText();

  console.log(`${query1name} is ${query1status}`);
  file.data[5].ActiveDeviceCount =
    `${query1name} is ${query1status}` +
    " " +
    `${query2name} is ${query2status}`;

  await page.waitForLoadState("networkidle");

  fs.writeFile(fileName, JSON.stringify(file), function writeJSON(err) {
    if (err) return console.log(err);
    console.log(JSON.stringify(file.data[5]));
    console.log("writing to " + fileName);
  });

  await page.click('button:has-text("Welcome QEERI,")');
  await page.waitForLoadState("networkidle");
  await page.click('button[role="menuitem"]:has-text("logout")');
  await expect(page).toHaveURL(`${airQualityCreds.host}/login`);

  await page.close;
});
