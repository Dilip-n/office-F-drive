const { test, expect } = require("@playwright/test");
const { vignaharthaCreds } = require("../../config");
const fs = require("fs");
const fileName = "../../result.json";
const file = require(fileName);

test("test", async ({ page }) => {
  // Go to vignaharthaCreds.host

  // Go to vignaharthaCreds.host/login
  await page.goto(vignaharthaCreds.host + "/login");
  await page.waitForLoadState("networkidle");
  // Click input[type="username"]
  await page.click('input[type="username"]');

  // Fill input[type="username"]
  await page.fill('input[type="username"]', vignaharthaCreds.username);

  // Click input[type="password"]
  await page.click('input[type="password"]');

  // Fill input[type="password"]
  await page.fill('input[type="password"]', vignaharthaCreds.password);

  // Click button:has-text("Login")
  await Promise.all([
    page.waitForNavigation(/*{ url: 'vignaharthaCreds.host/dashboard' }*/),
    page.click('button:has-text("Login")'),
  ]);

  await page.waitForLoadState("networkidle");

  const url = await page.url();
  let value = "";
  if (url === `${vignaharthaCreds.host}/dashboard`) {
    value = "UP";
  } else {
    value = "Down";
  }
  file.data[4].status = value;

  if (value === "UP") {
    file.data[4].login = "YES";
  } else {
    file.data[4].login = "No";
  }
  await new Promise((resolve) => setTimeout(resolve, 2000));
  await page.waitForLoadState("networkidle");
  const locator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]"
  );
  const locator_innertext = await locator.innerText();
  console.log("Devices online are " + locator_innertext);
  await page.waitForLoadState("networkidle");
  const locator1 = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[2]"
  );
  const locator_innertext1 = await locator1.innerText();

  file.data[4].ActiveDeviceCount = locator_innertext + locator_innertext1;
  await page.click('button:has-text("Devices")');

  await expect(page).toHaveURL(`${vignaharthaCreds.host}/devices`);
  await new Promise((resolve) => setTimeout(resolve, 2000));
  await page.click(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[19]/span[1]/span[1]/span[1]"
  );

  await page.waitForLoadState("networkidle");

  const locator2 = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[10]"
  );
  const locator_innertext2 = await locator2.innerText();

  file.data[4].LastupdatedAt = locator_innertext2;

  fs.writeFile(fileName, JSON.stringify(file), function writeJSON(err) {
    if (err) return console.log(err);
    console.log(JSON.stringify(file.data[4]));
    console.log("writing to " + fileName);
  });

  await page.waitForLoadState("networkidle");
  // Click button:has-text("Welcome Demo BTS 3,")
  await page.click('button:has-text("Welcome Demo BTS 3,")');

  await page.waitForLoadState("networkidle");
  // Click button[role="menuitem"]:has-text("logout")
  await page.click('button[role="menuitem"]:has-text("logout")');
  await expect(page).toHaveURL(vignaharthaCreds.host + "/login");

  await page.waitForLoadState("networkidle");
  // Close page
  await page.close();
});
