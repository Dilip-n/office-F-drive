const { test, expect } = require("@playwright/test");
const { boschAppCreds } = require("../../config");

const fs = require("fs");
const fileName = "../../result.json";
const file = require(fileName);

//console.log(binAppCreds.host);

test("SiteAtest", async ({ page }) => {
  // Go to boschAppCreds.host/user/login
  await page.goto(boschAppCreds.host + "/");
  await page.waitForLoadState("networkidle");
  // Click [placeholder="username"]
  await page.click('[placeholder="username"]');

  // Fill [placeholder="username"]
  await page.fill('[placeholder="username"]', boschAppCreds.username);

  // Click [placeholder="password"]
  await page.click('[placeholder="password"]');

  // Fill [placeholder="password"]
  await page.fill('[placeholder="password"]', boschAppCreds.password);

  // Click button:has-text("Login")
  await Promise.all([
    // page.waitForNavigation({ url: "boschAppCreds.host/dashboard" }),
    page.click('button:has-text("Login")'),
  ]);
  await new Promise((resolve) => setTimeout(resolve, 1500));
  const url = await page.url();
  console.log(url);
  let value = "";
  if (url === `${boschAppCreds.host}/dashboard`) {
    value = "UP";
  } else {
    value = "Down";
  }

  console.log("Value", value);
  file.data[0].status = value;

  if (value === "UP") {
    file.data[0].login = "YES";
  } else {
    file.data[0].login = "No";
  }
  await page.waitForLoadState("networkidle");
  const locator5 = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/section[1]/section[1]/div[1]/main[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[2]/td[1]"
  );
  const locator5_innertext = await locator5.innerText();

  file.data[0].ActiveDeviceCount = locator5_innertext;

  const locator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/section[1]/section[1]/div[1]/main[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[2]/td[7]"
  );
  const locator_innertext = await locator.innerText();
  file.data[0].LastupdatedAt = locator_innertext;

  fs.writeFile(fileName, JSON.stringify(file), function writeJSON(err) {
    if (err) return console.log(err);
    console.log(JSON.stringify(file.data[0]));
    console.log("writing to " + fileName);
  });
  // Click text=Bosch Admin
  await page.click("text=Bosch Admin");
  await page.waitForLoadState("networkidle");
  // Click text=Logout
  await page.click("text=Logout");
  await page.waitForLoadState("networkidle");
  // Close page
  await page.close();
});

test("SiteBtest", async ({ page }) => {
  await page.goto(boschAppCreds.host);
  await page.waitForLoadState("networkidle");
  // Click [placeholder="username"]
  await page.click('[placeholder="username"]');

  // Fill [placeholder="username"]
  await page.fill('[placeholder="username"]', boschAppCreds.username);

  // Click [placeholder="password"]
  await page.click('[placeholder="password"]');

  // Fill [placeholder="password"]
  await page.fill('[placeholder="password"]', boschAppCreds.password);

  // Click button:has-text("Login")
  await Promise.all([
    page.waitForNavigation(/*{ url: 'boschAppCreds.host/dashboard' }*/),
    page.click('button:has-text("Login")'),
  ]);
  await new Promise((resolve) => setTimeout(resolve, 1500));
  const url = await page.url();
  console.log(url);
  let value = "";
  if (url === `${boschAppCreds.host}/dashboard`) {
    value = "UP";
  } else {
    value = "Down";
  }

  console.log("Value", value);
  file.data[1].status = value;

  if (value === "UP") {
    file.data[1].login = "YES";
  } else {
    file.data[1].login = "No";
  }

  const locator5 = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/section[1]/section[1]/div[1]/main[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[3]/td[1]"
  );
  const locator5_innertext = await locator5.innerText();

  file.data[1].ActiveDeviceCount = locator5_innertext;

  const locator = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/section[1]/section[1]/div[1]/main[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[3]/td[7]"
  );
  const locator_innertext = await locator.innerText();
  file.data[1].LastupdatedAt = locator_innertext;

  fs.writeFile(fileName, JSON.stringify(file), function writeJSON(err) {
    if (err) return console.log(err);
    console.log(JSON.stringify(file.data[1]));
    console.log("writing to " + fileName);
  });

  // Click text=Bosch Admin
  await page.click("text=Bosch Admin");

  await page.waitForLoadState("networkidle");

  // Click text=Logout
  await page.click("text=Logout");
  await expect(page).toHaveURL(
    boschAppCreds.host +
      "/user/login?redirect=http%3A%2F%2Fiot2.hyperthings.in%3A6010%2Fdashboard"
  );

  // Close page
  await page.close();
});
