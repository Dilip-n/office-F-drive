const { test, expect } = require("@playwright/test");
const { fmsBadalpurCreds } = require("../../config");

const fs = require("fs");
const fileName = "../../result.json";
const file = require(fileName);

test("test", async ({ page }) => {
  await page.goto(fmsBadalpurCreds.host + "/");
  await page.waitForLoadState("networkidle");
  await page.click('input[type="username"]');

  await page.fill('input[type="username"]', fmsBadalpurCreds.username);

  await page.click('input[type="password"]');

  await page.fill('input[type="password"]', fmsBadalpurCreds.password);

  await Promise.all([
    page.waitForNavigation(/*{ url: `${fmsBadalpurCreds.host}/dashboard` }*/),
    page.click('button:has-text("Login")'),
  ]);

  await page.waitForLoadState("networkidle");

  const url = await page.url();
  let value = "";
  if (url === `${fmsBadalpurCreds.host}/dashboard`) {
    value = "UP";
  } else {
    value = "Down";
  }

  file.data[2].status = value;

  if (value === "UP") {
    file.data[2].login = "YES";
  } else {
    file.data[2].login = "No";
    // content.data[2].login = "No";

    // result.fmsb.push({ login: "No" });
  }

  await new Promise((resolve) => setTimeout(resolve, 3000));
  await page.waitForLoadState("networkidle");
  const onlineDevice = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]"
  );
  const onlineDevice_innertext = await onlineDevice.innerText();

  console.log("online devices", onlineDevice_innertext);
  const totalDevice = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/span[2]"
  );
  const totalDevice_innertext = await totalDevice.innerText();

  // content.data[2].ActiveDeviceCount =
  file.data[2].ActiveDeviceCount =
    onlineDevice_innertext + totalDevice_innertext;

  // result.fmsb.push({
  //   ActiveDeviceCount: onlineDevice_innertext + totalDevice_innertext,
  // });

  //checking last updated time
  await new Promise((resolve) => setTimeout(resolve, 3000));
  await page.click(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]"
  );
  // await page.waitForLoadState("networkidle");
  // await expect(page).toHaveURL(
  //   `${fmsBadalpurCreds.host}/devicesStatus?status=online`
  //  );

  const lastupdatedTime = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/span[1]"
  );
  const lastupdatedTime_innertext = await lastupdatedTime.innerText();

  file.data[2].LastupdatedAt = lastupdatedTime_innertext;

  fs.writeFile(fileName, JSON.stringify(file), function writeJSON(err) {
    if (err) return console.log(err);
    console.log(JSON.stringify(file.data[2]));
    console.log("writing to " + fileName);
  });

  await page.click('button:has-text("Welcome KBMC,")');
  await page.click('button[role="menuitem"]:has-text("logout")');
  await expect(page).toHaveURL(fmsBadalpurCreds.host + "/login");
  await page.close();
});

// console.log("Value", value);
// console.log("total devices", onlineDevice_innertext + totalDevice_innertext);
// console.log("last updateddevices", lastupdatedTime_innertext);
