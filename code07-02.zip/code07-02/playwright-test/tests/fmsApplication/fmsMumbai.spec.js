const { test, expect } = require("@playwright/test");
const { fmsMumbaiCreds } = require("../../config");

const fs = require("fs");
const fileName = "../../result.json";
const file = require(fileName);

test("test", async ({ page }) => {
  await page.goto(fmsMumbaiCreds.host + "/");

  await page.goto(fmsMumbaiCreds.host + "/login");
  await page.waitForLoadState("networkidle");

  await page.click('input[type="username"]');

  await page.fill('input[type="username"]', fmsMumbaiCreds.username);

  await page.click('input[type="password"]');

  await page.fill('input[type="password"]', fmsMumbaiCreds.password);

  await Promise.all([
    page.waitForNavigation(/*{ url:`${fmsMumbaiCreds.host}/dashboard` }*/),
    page.click('button:has-text("Login")'),
  ]);

  await page.waitForLoadState("networkidle");

  const url = await page.url();
  let value = "";
  if (url === `${fmsMumbaiCreds.host}/dashboard`) {
    value = "UP";
  } else {
    value = "Down";
  }

  console.log("Value", value);
  file.data[3].status = value;

  if (value === "UP") {
    file.data[3].login = "YES";
  } else {
    file.data[3].login = "No";
  }

  await new Promise((resolve) => setTimeout(resolve, 5000));
  const onlineDevice = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]"
  );
  const onlineDevice_innertext = await onlineDevice.innerText();

  console.log("online devices", onlineDevice_innertext);
  const totalDevice = page.locator(
    "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]/div[1]/span[2]"
  );
  const totalDevice_innertext = await totalDevice.innerText();

  console.log("total devices", onlineDevice_innertext + totalDevice_innertext);

  if (onlineDevice_innertext != 0) {
    file.data[3].ActiveDeviceCount =
      onlineDevice_innertext + totalDevice_innertext;
    await page.click(
      "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]/div[1]/div[1]"
    );

    await expect(page).toHaveURL(
      `${fmsMumbaiCreds.host}/devicesStatus?status=online`
    );
    await page.waitForLoadState("networkidle");

    const lastupdatedTime = page.locator(
      "//html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[6]/div[1]/span[1]"
    );
    const lastupdatedTime_innertext = await lastupdatedTime.innerText();

    console.log("last updateddevices", lastupdatedTime_innertext);

    file.data[3].LastupdatedAt = lastupdatedTime_innertext;

    await page.click('button:has-text("Welcome MCGM,")');

    await page.click('button[role="menuitem"]:has-text("logout")');
    await expect(page).toHaveURL(fmsMumbaiCreds.host + "/login");

    await page.close();
  } else {
    file.data[3].ActiveDeviceCount =
      onlineDevice_innertext + totalDevice_innertext;

    file.data[3].LastupdatedAt = "No active devices";

    fs.writeFile(fileName, JSON.stringify(file), function writeJSON(err) {
      if (err) return console.log(err);
      console.log(JSON.stringify(file.data[3]));
      console.log("writing to " + fileName);
    });

    await page.click('button:has-text("Welcome MCGM,")');

    await page.click('button[role="menuitem"]:has-text("logout")');
    await expect(page).toHaveURL(fmsMumbaiCreds.host + "/login");

    await page.close();
  }
});
