"use strict";
module.exports = {
  dbHost: process.env.PGDB_HOST || "localhost",

  dbPort: process.env.PGDB_PORT || "54323",

  dbName: process.env.PGDB_NAME || "fms-app",

  dbUser: process.env.PGDB_USERNAME || "master",

  dbPassword: process.env.PGDB_PASSWORD || "DHNNOQIYWMDZZPOQ",

  dbAppId: process.env.FMS_APPID || 3,

  dbSize: process.env.FMS_PACKET_SIZE || 168,

  dbInsert: process.env.DB_INSERT || true,

  dbDuration: process.env.FMS_INSERT_DURATION || 59,
};
