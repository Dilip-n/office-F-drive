const express = require("express");
var bodyParser = require("body-parser");

// create application/json parser
var jsonParser = bodyParser.json();

// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false });

const { Pool, Client } = require("pg");
// const client = new Client({
//   host: "localhost",
//   port: 5432,
//   user: "postgres",
//   password: "password",
// });

const connectionString =
  "postgresql://postgres:password@localhost:5432/postgres";
const pool = new Pool({
  connectionString,
});

pool.connect((err) => {
  if (err) {
    console.error("connection error", err.stack);
  } else {
    console.log("connected");
  }
});

const app = express();

app.get("/", async function (req, res) {
  const result = await pool.query("SELECT * from device_data");

  res.status(200).send({
    success: true,
    data1: result.rows,
  });
});

app.post("/", jsonParser, async (req, res) => {
  const value = JSON.stringify(req.body.value);
  const result =
    await pool.query(`INSERT INTO device_data ("id","device_id","time","data_type","value","device_uid","pf_data_id")
  VALUES ('${req.body.id}','${req.body.device_id}','${req.body.time}','${req.body.data_type}','${value}','${req.body.device_uid}','${req.body.pf_data_id}')`);
  console.log(result.rowCount);

  if (result.rowCount > 0) {
    res.status(200).send({
      success: true,
      data1: `${result.rowCount} data inserted`,
    });
  }
});

app.patch("/:id", jsonParser, async (req, res) => {
  const userId = req.params.id;

  const result = await pool.query(
    `SELECT * from device_data dd where dd.id=${userId} `
  );
  if (result.rowCount == 1) {
    const result1 = await pool.query(
      `UPDATE device_data
        SET device_uid = '${req.body.device_uid}'
        WHERE device_data.id=${userId};`
    );
    if (result.rowCount > 0) {
      res.status(200).send({
        success: true,
        data1: `${result.rowCount} data updates`,
      });
    }
  }
});

app.listen(3000, () => {
  console.log("server started");
});
