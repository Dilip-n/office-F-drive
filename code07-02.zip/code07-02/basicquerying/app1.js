//classes and constructor
//constructor with default parameters
class User {
  constructor() {
    (this.email = "helloclass@example.com"), (this.name = "school");
  }
}

const user1 = new User();

// console.log(user1);

//

class Employee {
  constructor(ename, emobile, edesignation, edepartment) {
    (this.EmployeeName = ename),
      (this.EmployeeMobileNumber = emobile),
      (this.EmployeeDesignation = edesignation),
      (this.EmployeeDepartment = edepartment);
  }
}

const emp1 = new Employee("Jack", 9653254, "aerodynamictec", "buldings");

console.log(emp1);
