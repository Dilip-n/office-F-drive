module.exports = {
  pgdbHost: process.env.FTS_PGDB_HOST || process.env.PGDB_HOST || "localhost",
  pgdbPort: process.env.FTS_PGDB_PORT || process.env.PGDB_PORT || "54323",
  pgdbIsAuth:
    process.env.FTS_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || "true",
  pgdbUsername:
    process.env.FTS_PGDB_USERNAME || process.env.PGDB_USERNAME || "master",
  pgdbPassword:
    process.env.FTS_PGDB_PASSWORD ||
    process.env.PGDB_PASSWORD ||
    "DHNNOQIYWMDZZPOQ",

  pgDbName: process.env.PGDB_NAME || "fts-app",

  appPort: process.env.FTS_API_PORT || 3034,
  appHost: process.env.FTS_API_HOST || "0.0.0.0",

  appEnv: process.env.NODE_ENV || process.env.FTS_ENV || "dev",
  appLog: process.env.FTS_API_LOG || "dev",

  accessTokenSecret:
    process.env.FTS_ACCESS_TOKEN_SECRET ||
    "65E74A532D2BFB455264C110FCDF19BD9B5E4B8BA0D8C11D1152ACCB7DF08F40",
  refreshTokenSecret:
    process.env.FTS_REFRESH_TOKEN_SECRET ||
    "1A0F2EE94F536B0F67408973C7CD1721A7FD375C1AD36DB3E95E8931EC6781B4",
  loginAPIServer:
    process.env.FTS_DS_API ||
    process.env.DS_API ||
    "http://localhost:3002/api/v1",

  dsAPIKey:
    process.env.FTS_DS_API_KEY ||
    process.env.DS_API_KEY ||
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRJZCI6IjVlOTlhOTAzMTQyMWZmMDAxOTk2Y2ZlNCIsImFwcElkIjoiNTIwMzY1ODgyMDg3NDQ5MiIsImlhdCI6MTU4ODkzMDk1MH0._zy8tZBteg1uyG313KSjmI3jpK5USUfILA2Z8MVIYjc",
};
