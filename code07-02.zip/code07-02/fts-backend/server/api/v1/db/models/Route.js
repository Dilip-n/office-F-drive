"use strict";
const { route } = require("../../routes/user");
//Import Schema
const Schema = require("./Schema");

module.exports = (sequelize, DataTypes) => {
  const routeSchema = Schema(DataTypes).Schema.Route;
  const Route = sequelize.define("route", routeSchema);
  Route.associate = function (models) {
    // associations can be defined here
  };
  return Route;
};
