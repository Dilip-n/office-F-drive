"use strict";
//Import Schema
const Schema = require("./Schema");

module.exports = (sequelize, DataTypes) => {
  const driverSchema = Schema(DataTypes).Schema.Driver;
  const Driver = sequelize.define("driver", driverSchema);
  Driver.associate = function (models) {
    // associations can be defined here
    Driver.belongsTo(models.user, {
      foreignKey: {
        name: "userId",
      },
      targetKey: "id",
    });
  };
  return Driver;
};
