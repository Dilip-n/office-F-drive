"use strict";
//Import Axios
const Axios = require("axios");
//Import Joi
const Joi = require("@hapi/joi");
//Import Sequelize
const { Sequelize, Op, QueryTypes } = require("sequelize");
//Import PG Models
const DB = require("./../db/models/pg");
//Import Response Util
const Response = require("./../utils/response");
//Device Schema
const Schema = require("./../db/models/Schema");
//Import lodash
const _ = require("lodash");
//Import Moment
const Moment = require("moment-timezone");
//Import Geolib
const Geolib = require("geolib");

//Default start date
const startOfTheDay = Moment()
  .tz("Asia/Kolkata")
  .startOf("day")
  .format("YYYY-MM-DD HH:mm:ss");
const momentNow = Moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
console.log(momentNow);
//Auth Controller
module.exports = class DataHandler {
  constructor() {}

  //All Device
  static getAllDevices = async (ctx, next) => {
    let selectFields = [];
    //Get Device Schema
    const schemaObj = Schema().DeviceSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    // Find all Device
    try {
      // Device List
      const devices = await DB.device.findAll({
        raw: true,
        attributes: selectFields,
        include: [
          {
            model: DB.vehicle,
            attributes: ["id"],
          },
        ],
      });

      if (devices.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: devices,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //All Vehicles
  static getAllVehicles = async (ctx, next) => {
    //Get date range
    const fromDate = ctx.query.fromDate;
    const toDate = ctx.query.toDate;
    //Selected fields
    let selectFields = [];
    //Get vehicle Schema
    const schemaObj = Schema().VehicleSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    //Raw Data model selection
    let rawDatacCond = {};
    if (fromDate && toDate) {
      rawDatacCond = {
        model: DB.raw_data,
        where: {
          [Op.and]: [
            Sequelize.where(Sequelize.literal("time"), ">=", fromDate),
            Sequelize.where(Sequelize.literal("time"), "<=", toDate),
          ],
        },
        attributes: [[DB.sequelize.literal(`data->'data'`), "raw"], "time"],
        as: "data",
        order: [["time", "desc"]],
      };
    } else {
      rawDatacCond = {
        attributes: [[DB.sequelize.literal(`data->'data'`), "raw"], "time"],
        model: DB.raw_data,
        as: "data",
        limit: 10,
        order: [["time", "desc"]],
      };
    }
    // Find all Device
    try {
      //Get Vehicles
      const vehicles = await DB.vehicle.findAll({
        attributes: selectFields,
        include: [
          {
            model: DB.driver,
            include: [
              { model: DB.user, attributes: ["id", "name", "email", "mobile"] },
            ],
          },
          {
            model: DB.route,
            attributes: ["id", "name", "createdAt", "route"],
          },
          rawDatacCond,
        ],
      });
      //If vehicles found
      if (vehicles.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: vehicles.map((vehicle) => {
            return {
              ...vehicle.dataValues,
              data: vehicle.data.length > 0 ? vehicle.data : {},
            };
          }),
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //All Single vehicle route
  static getVehicleRoute = async (ctx, next) => {
    const deviceId = ctx.params.deviceId;
    // Find one device Device
    try {
      //Find this device
      const device = await DB.device.findOne({
        raw: true,
        where: { deviceId },
      });

      if (!device) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No device Found!",
          data: [],
        });
      }

      // Device raw data
      //Find this device
      const startData = await DB.raw_data.findOne({
        raw: true,
        where: {
          [Op.and]: [
            { deviceId },
            { time: { [Op.lt]: startOfTheDay } },

            Sequelize.where(
              Sequelize.literal("data->'data'->>'engOn'"),
              "=",
              "0"
            ),
          ],
        },
        order: [["time", "desc"]],
      });
      //from date
      let findFrom = startOfTheDay;
      if (startData) {
        findFrom = startData.time;
      }
      //Query
      const tripData = await DB.sequelize.query(
        `Select * from raw_data where "deviceId" = :deviceId and time > :fromDate and time <= :toDate and data->'data'->>'engOn'= '1' order by time desc`,
        {
          replacements: {
            deviceId,
            fromDate: findFrom,
            toDate: momentNow,
          },
          type: QueryTypes.SELECT,
        }
      );

      //If Data
      if (tripData.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: tripData,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Reports
  static getReports = async (ctx, next) => {
    //Get date range
    const fromDate = ctx.query.fromDate;
    const toDate = ctx.query.toDate;

    //Get device from query
    const deviceId = ctx.query.deviceId;

    //Get report type
    const reportType = ctx.query.type;

    //
    if (!fromDate || !toDate || !reportType) {
      return Response.unprocessableEntity(ctx, {
        code: 42,
        msg: "Invalid request data !",
      });
    }

    //Summary Report
    if (reportType == "summary") {
      let rawData = await DB.sequelize.query(
        `SELECT
        d."deviceId" as "vehiNum", 
        v2."name" as "vehicle", 
        u."name" as "driver", 
        rd."time" as time, rd."id",
        cast (rd.data->'data'->>'engOn' as integer) as engOn,
        cast (rd.data->'data'->>'duration' as float) as duration,
        cast (rd.data->'data'->>'distance' as float) as distance,
        (rd.data->'data'->>'packetType') as "voilationType",
        cast (rd.data->'data'->>'spd' as float) as speed,
        cast (rd.data->'data'->>'idalTs' as float) as "idelTime",
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId"
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId"
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        GROUP BY d."deviceId", d.name, d.address, time, rd.data,  rd.id, v2."name", u."name"
        order by time desc;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );

      let finalObj = {};
      rawData.forEach((games) => {
        let currentDate = Moment(games.time, "YYYY-MM-DD").toISOString();
        let d = `"${games.time}"`;
        //console.log(currentDate);
        const date = currentDate.split("T")[0];

        if (finalObj[date]) {
          finalObj[date].push(games);
        } else {
          finalObj[date] = [games];
        }
      });

      let dayWise = Object.values(finalObj);
      let keys = [];
      let sortedData = [];

      let map = await dayWise.map(async (data) => {
        let obj = {};
        let speed = 0;
        let idTime = 0;
        let duration = 0;
        let distance = 0;
        let stopCount = 0;

        //sort max to min
        let dataMaxToMin = data.sort(function (a, b) {
          return b.time - a.time;
        });

        //console.log(dataMaxToMin[0]);
        //obj.eTime = dataMaxToMin[0].time;
        obj.routeStart = dataMaxToMin[0].location;
        obj.voilationType = dataMaxToMin[0].voilationType;

        //sort min to max
        let dataMinToMax = data.sort(function (a, b) {
          return a.time - b.time;
        });

        //console.log(dataMinToMax[0]);

        //obj.sTime = dataMinToMax[0].time;
        obj.routeEnd = dataMinToMax[0].location;
        obj.vehicleNum = dataMinToMax[0].vehiNum;
        obj.fuelConsump = null;
        obj.vehicle = dataMaxToMin[0].vehicle;
        obj.driver = dataMaxToMin[0].driver;

        // obj.engStatus = dataMaxToMin[0].engOn;

        let topSpeed = data.sort(function (a, b) {
          return b.speed - a.speed;
        });
        //console.log(topSpeed);
        obj.topSpeed = parseInt(topSpeed[0].speed);

        let map1 = await dataMaxToMin.map(async (data) => {
          speed = speed + parseInt(data.speed);
          if (data.idel_time == null) {
            idTime = idTime + 0;
            stopCount = stopCount + 0;
          } else {
            idTime = idTime + parseInt(data.idel_time);
            stopCount = stopCount + 1;
          }

          if (data.duration == null) {
            duration = duration + 0;
          } else {
            duration = duration + parseInt(data.duration);
          }

          if (data.distance == null) {
            distance = distance + 0;
          } else {
            distance = distance + parseInt(data.distance);
          }
        });

        Promise.all(map1).then(async (data) => {
          obj.duration = duration;
          obj.distance = parseFloat(
            duration * (speed / dataMinToMax.length).toFixed(2)
          );

          obj.avgSpeed = parseFloat((speed / dataMinToMax.length).toFixed(2));
          obj.ideltime = idTime;
          obj.totalTime = duration + idTime;
          obj.stopCount = parseInt(stopCount);

          let start = JSON.parse(obj.routeStart);
          let end = JSON.parse(obj.routeEnd);

          let dis = await parseFloat(
            Geolib.getPreciseDistance(
              { latitude: start[0], longitude: start[1] },
              { latitude: end[0], longitude: end[1] }
            )
          );

          obj.distance = dis;

          console.log("distance ", dis);
          let columns = Object.keys(obj);
          if (keys.length == 0) {
            keys.push(columns);
          }

          let values = Object.values(obj);
          sortedData.push(values);
        });
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "routeStart",
          "voilationType",
          "routeEnd",
          "vehicleNum",
          "fuelConsump",
          "vehicle",
          "driver",
          "topSpeed",
          "duration",
          "distance",
          "avgSpeed",
          "ideltime",
          "totalTime",
          "stopCount",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: {
            columns: columns,
            data: sortedData,
          },
        });
      });
    }

    //Route Report
    if (reportType == "route") {
      let rawData = await DB.sequelize.query(
        `SELECT
      d."deviceId" as "vehiNum", 
      v2."name" as "vehicle", 
      u."name" as "driver", 
      rd."time" as time, rd."id",
      cast (rd.data->'data'->>'engOn' as integer) as "engOn",
      cast (rd.data->'data'->>'duration' as float) as duration,
      cast (rd.data->'data'->>'distance' as float) as distance,
      (rd.data->'data'->>'packetType') as voilationType,
      cast (rd.data->'data'->>'spd' as float) as speed,
      cast (rd.data->'data'->>'idalTs' as float) as "idelTime",
      CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location
      from devices d
      INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId"
      INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
      INNER JOIN users u ON u.id = d2."userId" 
      INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId"
      WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
      GROUP BY d."deviceId", d.name, d.address, time, rd.data, rd.id, v2."name", u."name"
      order by time desc;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );
      let finalObj = {};
      rawData.forEach((games) => {
        let currentDate = Moment(games.time, "YYYY-MM-DD").toISOString();
        let d = `"${games.time}"`;
        //console.log(currentDate);
        const date = currentDate.split("T")[0];

        if (finalObj[date]) {
          finalObj[date].push(games);
        } else {
          finalObj[date] = [games];
        }
      });

      let dayWise = Object.values(finalObj);

      let sortedData = [];
      let keys = [];

      let map = await dayWise.map(async (data) => {
        let obj = {};
        let speed = 0;
        let idTime = 0;
        let duration = 0;
        let distance = 0;

        //sort max to min
        let dataMaxToMin = data.sort(function (a, b) {
          return b.time - a.time;
        });

        //console.log(dataMaxToMin[0]);
        obj.eTime = dataMaxToMin[0].time;
        obj.startLocation = dataMaxToMin[0].location;

        //sort min to max
        let dataMinToMax = data.sort(function (a, b) {
          return a.time - b.time;
        });

        //console.log(dataMinToMax[0]);

        obj.sTime = dataMinToMax[0].time;
        obj.endLocation = dataMinToMax[0].location;
        obj.vehicleNum = dataMinToMax[0].vehiNum;
        obj.fuelConsump = null;
        obj.driver = dataMaxToMin[0].driver;
        obj.vehicle = dataMaxToMin[0].vehicle;

        // obj.engStatus = dataMaxToMin[0].engOn;

        let topSpeed = data.sort(function (a, b) {
          return b.speed - a.speed;
        });
        //console.log(topSpeed);
        obj.topSpeed = parseInt(topSpeed[0].speed);

        let map1 = await dataMaxToMin.map(async (data) => {
          speed = speed + parseInt(data.speed);
          if (data.idel_time == null) {
            idTime = idTime + 0;
          } else {
            idTime = idTime + parseInt(data.idel_time);
          }

          if (data.duration == null) {
            duration = duration + 0;
          } else {
            duration = duration + parseInt(data.duration);
          }

          if (data.distance == null) {
            distance = distance + 0;
          } else {
            distance = distance + parseInt(data.distance);
          }
        });

        Promise.all(map1).then(async (data) => {
          obj.duration = duration;
          // obj.distance = parseFloat(
          //   duration * (speed / dataMinToMax.length).toFixed(2)
          // );

          obj.ideltime = idTime;
          obj.totalTime = duration + idTime;

          let start = JSON.parse(obj.startLocation);
          let end = JSON.parse(obj.endLocation);

          let dis = await parseFloat(
            Geolib.getPreciseDistance(
              { latitude: start[0], longitude: start[1] },
              { latitude: end[0], longitude: end[1] }
            )
          );

          obj.distance = dis;

          console.log("distance ", dis);
          let columns = Object.keys(obj);
          if (keys.length == 0) {
            keys.push(columns);
          }

          let values = Object.values(obj);
          sortedData.push(values);
        });
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "eTime",
          "startLocation",
          "sTime",
          "endLocation",
          "vehicleNum",
          "fuelConsump",
          "driver",
          "vehicle",
          "topSpeed",
          "duration",
          "ideltime",
          "totalTime",
          "distance",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: sortedData },
        });
      });
    }

    //Daily Route Report
    if (reportType == "dailyRoute") {
      let rawData = await DB.sequelize.query(
        `SELECT
        d."deviceId" as "vehiNum", 
        v2."name" as "vehicle", 
        rd."time" as time, rd."id",
        cast (rd.data->'data'->>'duration' as float) as duration,
        cast (rd.data->'data'->>'distance' as float) as distance,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location,
        cast (rd.data->'data'->>'spd' as float) as speed
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId"
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId"
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        GROUP BY d."deviceId", d.name, d.address, time, rd.data, rd.id, v2."name", u."name"
        order by time desc;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );
      let finalObj = {};
      rawData.forEach((games) => {
        let currentDate = Moment(games.time, "YYYY-MM-DD").toISOString();
        let d = `"${games.time}"`;
        //console.log(currentDate);
        const date = currentDate.split("T")[0];

        if (finalObj[date]) {
          finalObj[date].push(games);
        } else {
          finalObj[date] = [games];
        }
      });

      let dayWise = Object.values(finalObj);

      let sortedData = [];
      let keys = [];

      let map = await dayWise.map(async (data) => {
        let obj = {};
        let speed = 0;
        let duration = 0;

        //sort max to min
        let dataMaxToMin = data.sort(function (a, b) {
          return b.time - a.time;
        });

        //console.log(dataMaxToMin[0]);
        obj.eTime = dataMaxToMin[0].time;
        obj.startLocation = dataMaxToMin[0].location;

        //sort min to max
        let dataMinToMax = data.sort(function (a, b) {
          return a.time - b.time;
        });

        //console.log(dataMinToMax[0]);

        obj.sTime = dataMinToMax[0].time;
        obj.endLocation = dataMinToMax[0].location;
        obj.vehicleNum = dataMinToMax[0].vehiNum;
        obj.vehicle = dataMaxToMin[0].vehicle;

        // obj.engStatus = dataMaxToMin[0].engOn;

        let topSpeed = data.sort(function (a, b) {
          return b.speed - a.speed;
        });
        //console.log(topSpeed);

        let map1 = await dataMaxToMin.map(async (data) => {
          speed = speed + parseInt(data.speed);

          if (data.duration == null) {
            duration = duration + 0;
          } else {
            duration = duration + parseInt(data.duration);
          }
        });

        Promise.all(map1).then(async (data) => {
          obj.duration = duration;
          // obj.distance = parseFloat(
          //   duration * (speed / dataMinToMax.length).toFixed(2)
          // );

          obj.duration = duration;

          obj.avgSpeed = parseFloat((speed / dataMaxToMin.length).toFixed(2));

          let start = JSON.parse(obj.startLocation);
          let end = JSON.parse(obj.endLocation);

          let dis = await parseFloat(
            Geolib.getPreciseDistance(
              { latitude: start[0], longitude: start[1] },
              { latitude: end[0], longitude: end[1] }
            )
          );

          obj.distance = dis;

          console.log("distance ", dis);

          let columns = Object.keys(obj);
          if (keys.length == 0) {
            keys.push(columns);
          }

          let values = Object.values(obj);
          sortedData.push(values);
        });
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "eTime",
          "startLocation",
          "sTime",
          "endLocation",
          "vehicleNum",
          "vehicle",
          "duration",
          "avgSpeed",
          "distance",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: sortedData },
        });
      });
    }

    //Geo Zone report
    if (reportType == "geoZone") {
      let rawData = await DB.sequelize.query(
        ` SELECT 
        d."deviceId" as "vehiNum", 
        v2."name" as "vehicle", 
        u."name" as "driver",             
        rd."time" as time,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location                  from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId" 
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId"
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        and rd.data->'data'->>'packetType' = 'ha'
        GROUP BY d."deviceId", time, rd.data, v2."name", u."name"
        order by time desc ;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );
      let polygon = [];
      await rawData.map(async (data) => {
        let location = JSON.parse(data.location);
        let latlong = {
          latitude: location[0],
          longitude: location[1],
        };
        polygon.push(latlong);
      });

      let sortedData = [];
      let keys = [];

      let map = await rawData.map(async (data) => {
        data.geoZone = "out";
        let location = JSON.parse(data.location);
        let latlong = {
          latitude: location[0],
          longitude: location[1],
        };
        let zone = await Geolib.isPointInPolygon(latlong, polygon);

        if (zone) {
          data.geoZone = "in";
        }

        let columns = Object.keys(data);
        if (keys.length == 0) {
          keys.push(columns);
        }

        let values = Object.values(data);
        sortedData.push(values);
      });
      Promise.all(map).then(async (data) => {
        let columns = [
          "vehiNum",
          "vehicle",
          "driver",
          "time",
          "location",
          "geoZone",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: sortedData },
        });
      });
    }

    //Harsh accleration
    if (reportType == "ha-hb-rt") {
      let rawData = await DB.sequelize.query(
        `SELECT 
        d."deviceId" as "vehiNum", 
        v2."name" as "vehicle", 
        u."name" as "driver",
        d.name as name, 
        (rd.data->'data'->>'packetType') as "voilationType",
        rd."time" as time,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location,
        cast (rd.data->'data'->>'duration' as float) as duration,
        cast (rd.data->'data'->>'spd' as float) as speed
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId" 
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId" 
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        and rd.data->'data'->>'packetType' = 'ha'
        or rd.data->'data'->>'packetType' = 'hb'
        or rd.data->'data'->>'packetType' = 'rt'
        GROUP BY d."deviceId", d.name, time, rd.data, v2."name", u."name"
        order by time desc ;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );
      let keys = [];
      let values = [];

      let map = await rawData.map((data) => {
        let columns = Object.keys(data);
        if (keys.length == 0) {
          keys.push(columns);
        }

        let value = Object.values(data);
        values.push(value);
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "vehiNum",
          "vehicle",
          "driver",
          "name",
          "voilationType",
          "time",
          "location",
          "duration",
          "speed",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: values },
        });
      });
    }

    //Harsh accleration
    if (reportType == "ha") {
      let rawData = await DB.sequelize.query(
        `SELECT 
        d."deviceId" as "vehiNum", 
        v2."name" as "vehicle", 
        u."name" as "driver",
        d.name as name, 
        (rd.data->'data'->>'packetType') as "voilationType",
        rd."time" as time,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location,
        cast (rd.data->'data'->>'duration' as float) as duration,
        cast (rd.data->'data'->>'spd' as float) as speed
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId" 
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId" 
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        and rd.data->'data'->>'packetType' = 'ha'
        GROUP BY d."deviceId", d.name, time, rd.data, v2."name", u."name"
        order by time desc ;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );
      let keys = [];
      let values = [];

      let map = await rawData.map((data) => {
        let columns = Object.keys(data);
        if (keys.length == 0) {
          keys.push(columns);
        }

        let value = Object.values(data);
        values.push(value);
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "vehiNum",
          "vehicle",
          "driver",
          "name",
          "voilationType",
          "time",
          "location",
          "duration",
          "speed",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: values },
        });
      });
    }

    //Harsh breaking
    if (reportType == "hb") {
      let rawData = await DB.sequelize.query(
        `SELECT 
        d."deviceId" as "vehiNum", 
        v2."name" as "vehicle", 
        u."name" as "driver", 
        d.name as name, 
        (rd.data->'data'->>'packetType') as "voilationType",
        rd."time" as time,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location,
        cast (rd.data->'data'->>'duration' as float) as duration,
        cast (rd.data->'data'->>'spd' as float) as speed
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId" 
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId" 
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        and rd.data->'data'->>'packetType' = 'hb'
        GROUP BY d."deviceId", d.name, time, rd.data, v2."name", u."name"
        order by time desc ;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );

      let keys = [];
      let values = [];

      let map = await rawData.map((data) => {
        let columns = Object.keys(data);
        if (keys.length == 0) {
          keys.push(columns);
        }

        let value = Object.values(data);
        values.push(value);
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "vehiNum",
          "vehicle",
          "driver",
          "name",
          "voilationType",
          "time",
          "location",
          "duration",
          "speed",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: values },
        });
      });
    }

    //Harsh turning
    if (reportType == "rt") {
      let rawData = await DB.sequelize.query(
        `SELECT 
        d."deviceId" as "vehiNum", 
        v2."name" as "vehicle", 
        u."name" as "driver", 
        d.name as name, 
        (rd.data->'data'->>'packetType') as "voilationType",
        rd."time" as time,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location,
        cast (rd.data->'data'->>'duration' as float) as duration,
        cast (rd.data->'data'->>'spd' as float) as speed
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId" 
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId" 
        where rd."time" between :fromDate and :toDate
        and rd.data->'data'->>'packetType' = 'rt'
        GROUP BY d."deviceId", d.name, time, rd.data, v2."name", u."name"
        order by time desc ;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );

      let keys = [];
      let values = [];

      let map = await rawData.map((data) => {
        let columns = Object.keys(data);
        if (keys.length == 0) {
          keys.push(columns);
        }

        let value = Object.values(data);
        values.push(value);
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "vehiNum",
          "vehicle",
          "driver",
          "name",
          "voilationType",
          "time",
          "location",
          "duration",
          "speed",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: values },
        });
      });
    }

    //High Speed / Over speed
    if (reportType == "hs") {
      let rawData = await DB.sequelize.query(
        `SELECT 
        d."deviceId" as "vehiNum", 
        u."name" as "driver",
        v2."name" as "vehicle",
        rd."time" as time,
        cast (rd.data->'data'->>'duration' as float) as duration,
        cast (rd.data->'data'->>'spd' as float) as speed,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId" 
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId" 
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        and rd.data->'data'->>'packetType' = 'hs'
        GROUP BY d."deviceId", time, rd.data, v2."name", u."name"
        order by time desc ;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );

      let keys = [];
      let values = [];

      let map = await rawData.map((data) => {
        let columns = Object.keys(data);
        if (keys.length == 0) {
          keys.push(columns);
        }

        let value = Object.values(data);
        values.push(value);
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "vehiNum",
          "driver",
          "vehicle",
          "time",
          "duration",
          "speed",
          "location",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: values },
        });
      });
    }

    //Idel time
    if (reportType == "it") {
      let rawData = await DB.sequelize.query(
        `SELECT 
        d."deviceId" as "vehiNum", 
        u."name" as "driver",
        v2."name" as "vehicle",
        rd."time" as time,
        CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location,
        cast (rd.data->'data'->>'idalTs' as float) as idelTime
        from devices d
        INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId" 
        INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
        INNER JOIN users u ON u.id = d2."userId" 
        INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId" 
        WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
        and rd.data->'data'->>'packetType' = 'if'
        GROUP BY d."deviceId", time, rd.data, v2."name", u."name"
        order by time desc ;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );

      let keys = [];
      let values = [];

      let map = await rawData.map((data) => {
        let columns = Object.keys(data);
        if (keys.length == 0) {
          keys.push(columns);
        }

        let value = Object.values(data);
        values.push(value);
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "vehiNum",
          "driver",
          "vehicle",
          "time",
          "location",
          "ideltime",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: values },
        });
      });
    }

    //Driver behaviour report
    if (reportType == "driverBehav") {
      let rawData = await DB.sequelize.query(
        `SELECT
      d."deviceId" as "vehiNum",
      u."name" as "driver",
      v2."name" as "vehicleName",
      rd."time" as time, rd."id",
      cast (rd.data->'data'->>'engOn' as float) as "engOn",
      cast (rd.data->'data'->>'duration' as float) as duration,
      cast (rd.data->'data'->>'distance' as float) as distance,
      (rd.data->'data'->>'packetType') as "voilationType",
      (rd.data->'data'->>'a01') as fuel,
      cast (rd.data->'data'->>'spd' as float) as speed,
      cast (rd.data->'data'->>'idalTs' as float) as "idelTime",
      CONCAT('[',rd.data->'data'->>'lat', ',', rd.data->'data'->>'lon',']') as location
      from devices d
      INNER JOIN raw_data rd ON rd."deviceId" = d."deviceId"
      INNER JOIN drivers d2 ON d2."deviceId" = d."deviceId" 
      INNER JOIN users u ON u.id = d2."userId" 
      INNER JOIN vehicles v2 ON v2."deviceId" = d."deviceId" 
      WHERE rd."time" >= :fromDate AND rd."time" <= :toDate
      GROUP BY d."deviceId", d.name, d.address, time, rd.data, rd.id, v2."name", u."name"
      order by time desc;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );
      let finalObj = {};
      rawData.forEach((games) => {
        let currentDate = Moment(games.time, "YYYY-MM-DD").toISOString();
        let d = `"${games.time}"`;
        //console.log(currentDate);
        const date = currentDate.split("T")[0];

        if (finalObj[date]) {
          finalObj[date].push(games);
        } else {
          finalObj[date] = [games];
        }
      });

      let dayWise = Object.values(finalObj);

      let sortedData = [];
      let keys = [];

      let map = await dayWise.map(async (data) => {
        let obj = {};
        let speed = 0;
        let idTime = 0;
        let duration = 0;

        let stopCount = 0;
        let voilationCount = 0;
        let hsCount = 0;
        let haCount = 0;
        let hbCount = 0;
        let rtCount = 0;
        let geoVoilationCount = 0;

        //sort max to min
        let dataMaxToMin = data.sort(function (a, b) {
          return b.time - a.time;
        });

        let polygon = [];
        await rawData.map(async (data) => {
          let location = JSON.parse(data.location);
          let latlong = {
            latitude: location[0],
            longitude: location[1],
          };
          polygon.push(latlong);
        });

        //console.log(dataMaxToMin[0]);
        obj.eTime = dataMaxToMin[0].time;
        obj.startLocation = dataMaxToMin[0].location;
        obj.fuelAtStart = parseInt(dataMaxToMin[0].fuel);
        //sort min to max
        let dataMinToMax = data.sort(function (a, b) {
          return a.time - b.time;
        });

        //console.log(dataMinToMax[0]);

        obj.sTime = dataMinToMax[0].time;
        obj.endLocation = dataMinToMax[0].location;
        obj.vehicleNum = dataMinToMax[0].vehiNum;
        obj.fuelAtEnd = parseInt(dataMinToMax[0].fuel);

        let fuelFilled = obj.fuelAtStart - obj.fuelAtEnd;

        if (fuelFilled < 0) {
          obj.fuelFilled = 0;
        } else {
          obj.fuelFilled = fuelFilled;
        }

        obj.fuelFilled = null;
        obj.fuelTheft = null;
        obj.driver = null;

        // obj.engStatus = dataMaxToMin[0].engOn;

        let topSpeed = data.sort(function (a, b) {
          return b.speed - a.speed;
        });
        //console.log(topSpeed);
        obj.topSpeed = parseInt(topSpeed[0].speed);

        let map1 = await dataMaxToMin.map(async (data) => {
          speed = speed + parseInt(data.speed);

          let location = JSON.parse(data.location);
          let latlong = {
            latitude: location[0],
            longitude: location[1],
          };
          let zone = await Geolib.isPointInPolygon(latlong, polygon);

          if (zone) {
            geoVoilationCount = geoVoilationCount + 0;
          } else {
            geoVoilationCount = geoVoilationCount + 1;
          }

          if (data.engOn == 0) {
            stopCount = stopCount + 1;
          }

          if (data.voilationType != "nr") {
            voilationCount = voilationCount + 1;
          }

          if (data.voilationType == "hs") {
            hsCount = hsCount + 1;
          }
          if (data.voilationType == "ha") {
            haCount = haCount + 1;
          }
          if (data.voilationType == "hb") {
            hbCount = hbCount + 1;
          }
          if (data.voilationType == "rt") {
            rtCount = rtCount + 1;
          }

          if (data.idelTime == null) {
            idTime = idTime + 0;
          } else {
            idTime = idTime + parseInt(data.idelTime);
          }

          if (data.duration == null) {
            duration = duration + 0;
          } else {
            duration = duration + parseInt(data.duration);
          }
        });

        Promise.all(map1).then(async (data) => {
          obj.duration = duration;
          obj.avgSpeed = parseFloat((speed / topSpeed.length).toFixed(2));
          obj.stopCount = stopCount;
          obj.voilationCount = voilationCount;
          obj.hsCount = hsCount;
          obj.haCount = haCount;
          obj.hbCount = hbCount;
          obj.rtCount = rtCount;
          obj.geoVoilationCount = geoVoilationCount;

          obj.ideltime = idTime;
          obj.totalTime = duration + idTime;

          let start = JSON.parse(obj.startLocation);
          let end = JSON.parse(obj.endLocation);

          let dis = await parseFloat(
            Geolib.getPreciseDistance(
              { latitude: start[0], longitude: start[1] },
              { latitude: end[0], longitude: end[1] }
            )
          );

          obj.distance = dis;

          obj.mileage = parseFloat(
            ((obj.distance * 0.001) / obj.fuelAtEnd).toFixed(2)
          );

          console.log("distance ", dis);

          let columns = Object.keys(obj);
          if (keys.length == 0) {
            keys.push(columns);
          }

          let values = Object.values(obj);
          sortedData.push(values);
        });
      });

      Promise.all(map).then(async (data) => {
        let columns = [
          "eTime",
          "startLocation",
          "fuelAtStart",
          "sTime",
          "endLocation",
          "vehicleNum",
          "fuelAtEnd",
          "fuelFilled",
          "fuelTheft",
          "driver",
          "topSpeed",
          "duration",
          "avgSpeed",
          "stopCount",
          "voilationCount",
          "hsCount",
          "haCount",
          "hbCount",
          "rtCount",
          "geoVoilationCount",
          "ideltime",
          "totalTime",
          "distance",
          "mileage",
        ];
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: rawData.length > 0 ? "Records Found" : "No Records Found!",
          data: { columns: columns, data: sortedData },
        });
      });
    }
    //Route Report
    if (reportType === "routeNikhil") {
      try {
        //Find this device
        const device = await DB.device.findOne({
          raw: true,
          where: { deviceId },
        });

        if (!device) {
          return Response.success(ctx, {
            statusCode: 200,
            code: 20,
            msg: "No device Found!",
            data: [],
          });
        }

        // Device raw data
        //Find this device
        const startData = await DB.raw_data.findOne({
          raw: true,
          where: {
            [Op.and]: [
              { deviceId },
              { time: { [Op.lt]: fromDate } },

              Sequelize.where(
                Sequelize.literal("data->'data'->>'engOn'"),
                "=",
                "0"
              ),
            ],
          },
          order: [["time", "desc"]],
        });
        //from date
        let findFrom = fromDate;
        if (startData) {
          findFrom = startData.time;
        }
        //Query
        const tripData = await DB.sequelize.query(
          `Select * from raw_data where "deviceId" = :deviceId and time > :fromDate and time <= :toDate and data->'data'->>'engOn'= '1' order by time desc`,
          {
            replacements: {
              deviceId,
              fromDate: findFrom,
              toDate: toDate,
            },
            type: QueryTypes.SELECT,
          }
        );
        //If Data
        if (tripData.length > 0) {
          return Response.success(ctx, {
            statusCode: 200,
            code: 20,
            msg: "Records Found!",
            data: tripData,
          });
        } else {
          return Response.success(ctx, {
            statusCode: 200,
            code: 20,
            msg: "No Records Found!",
            data: [],
          });
        }
      } catch (err) {
        console.log(err);
        return Response.error(ctx, {
          statusCode: 500,
          code: 50,
          msg: "Internal Error",
          error: err,
        });
      }
    }
    //Route Report
    if (reportType === "distance") {
      try {
        //Query
        const distanceData = await DB.sequelize.query(
          `select time_bucket('1 day', time) as date, sum(CAST(data->'data'->>'distance' AS FLOAT)) as dis
           from raw_data WHERE "deviceId" = :deviceId and time >= :fromDate and time <= :toDate and data->'data'->>'engOn'= '1' and data->'data'->>'distance' IS NOT NULL
           group by time order by time desc`,
          {
            replacements: { deviceId, fromDate, toDate },
            type: QueryTypes.SELECT,
          }
        );
        console.log(distanceData, distanceData.length);
        //If Data
        if (distanceData.length > 0) {
          return Response.success(ctx, {
            statusCode: 200,
            code: 20,
            msg: "Records Found!",
            data: distanceData,
          });
        } else {
          return Response.success(ctx, {
            statusCode: 200,
            code: 20,
            msg: "No Records Found!",
            data: [],
          });
        }
      } catch (err) {
        console.log(err);
        return Response.error(ctx, {
          statusCode: 500,
          code: 50,
          msg: "Internal Error",
          error: err,
        });
      }
    }
  };
  //Add Vehicle Detail
  static addVehicle = async (ctx, next) => {
    //Get Input
    const inputs = ctx.request.body;

    //Input Validation Schema
    const schema = Joi.object({
      deviceId: Joi.string().required(),
      chassisNo: Joi.string().required(),
      engineNo: Joi.string().required(),
      existingPlan: Joi.string().required(),
      imei: Joi.string().required(),
      insuranceDate: Joi.date().required(),
      insuranceNo: Joi.string().required(),
      insurancePeriod: Joi.string().required(),
      make: Joi.string().required(),
      mobileNo: Joi.string().required(),
      name: Joi.string().required(),
      nextService: Joi.date().required(),
      owner: Joi.string().required(),
      planValidity: Joi.string().required(),
      roadTaxNo: Joi.string().required(),
      roadTaxPeriod: Joi.string().required(),
      roadTaxRenewDate: Joi.date().required(),
      serviceDate: Joi.date().required(),
      simCardSerialNo: Joi.string().required(),
      unladenWeight: Joi.string().required(),
      vehicleNo: Joi.string().required(),
      vehicleType: Joi.number().required(),
      yearOfMfg: Joi.string().required(),
      odoNumber: Joi.string(),
      rfidNo: Joi.string(),
    });
    try {
      //Validate
      await schema.validateAsync(inputs);
    } catch (err) {
      console.log(err);
      return Response.unprocessableEntity(ctx, {
        code: 42,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Check if any device exists with this deviceId
      const checkDeviceId = await DB.device.findOne({
        raw: true,
        where: {
          deviceId: inputs.deviceId,
        },
      });
      if (!checkDeviceId) {
        return Response.conflict(ctx, {
          code: 20,
          msg: "Device does not exist!",
        });
      }
      // Check if any vehicle exists with this deviceId
      const checkVehicle = await DB.vehicle.findOne({
        raw: true,
        where: {
          deviceId: inputs.deviceId,
        },
      });
      if (checkVehicle) {
        return Response.conflict(ctx, {
          code: 20,
          msg: "Vehicle already exists for this device !",
        });
      }
      //Add vehicle details.
      const newVehicle = await DB.vehicle.create({
        deviceId: inputs.deviceId,
        name: inputs.name,
        imei: inputs.imei,
        vehicleNo: inputs.vehicleNo,
        vehicleType: inputs.vehicleType,
        owner: inputs.owner,
        engineNo: inputs.engineNo,
        chassisNo: inputs.chassisNo,
        make: inputs.make,
        yearOfMfg: inputs.yearOfMfg,
        unladenWeight: inputs.unladenWeight,
        serviceDate: inputs.serviceDate,
        nextService: inputs.nextService,
        insuranceNo: inputs.insuranceNo,
        insurancePeriod: inputs.insurancePeriod,
        insuranceDate: inputs.insuranceDate,
        roadTaxNo: inputs.roadTaxNo,
        roadTaxPeriod: inputs.roadTaxPeriod,
        roadTaxRenewDate: inputs.roadTaxRenewDate,
        simCardSerialNo: inputs.simCardSerialNo,
        mobileNo: inputs.mobileNo,
        existingPlan: inputs.existingPlan,
        planValidity: inputs.planValidity,
        rfidNo: inputs.rfidNo,
      });

      return Response.created(ctx, {
        code: 21,
        msg: "Vehicle Added!",
        data: {},
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update Vehicle
  static updateVehicle = async (ctx, next) => {
    try {
      //Get deviceId
      const deviceId = ctx.params.deviceId;
      // Check if any vehicle exists with this deviceId
      const checkVehicle = await DB.vehicle.findOne({
        where: {
          deviceId,
        },
      });
      if (!checkVehicle) {
        return Response.badRequest(ctx, {
          code: 20,
          msg: "Vehicle does not exists!",
        });
      }
      //Get Input
      const inputs = ctx.request.body;

      //Input Validation Schema
      const schema = Joi.object({
        chassisNo: Joi.string(),
        engineNo: Joi.string(),
        existingPlan: Joi.string(),
        imei: Joi.string(),
        insuranceDate: Joi.date(),
        insuranceNo: Joi.string(),
        insurancePeriod: Joi.string(),
        make: Joi.string(),
        mobileNo: Joi.string(),
        name: Joi.string(),
        nextService: Joi.date(),
        owner: Joi.string(),
        planValidity: Joi.string(),
        roadTaxNo: Joi.string(),
        roadTaxPeriod: Joi.string(),
        roadTaxRenewDate: Joi.date(),
        serviceDate: Joi.date(),
        simCardSerialNo: Joi.string(),
        unladenWeight: Joi.string(),
        vehicleNo: Joi.string(),
        vehicleType: Joi.number(),
        yearOfMfg: Joi.string(),
        polygonId: Joi.number(),
        routeId: Joi.number(),
        rfidNo: Joi.string(),
      });
      try {
        //Validate
        await schema.validateAsync(inputs);
      } catch (err) {
        console.log(err);
        return Response.unprocessableEntity(ctx, {
          code: 42,
          msg: "Please provide valid data!",
        });
      }
      //Data
      let data = {};
      if (inputs.chassisNo) {
        data.chassisNo = inputs.chassisNo;
      }
      if (inputs.engineNo) {
        data.engineNo = inputs.engineNo;
      }
      if (inputs.existingPlan) {
        data.existingPlan = inputs.existingPlan;
      }
      if (inputs.imei) {
        data.imei = inputs.imei;
      }
      if (inputs.insuranceDate) {
        data.insuranceDate = inputs.insuranceDate;
      }
      if (inputs.insuranceNo) {
        data.insuranceNo = inputs.insuranceNo;
      }
      if (inputs.insurancePeriod) {
        data.insurancePeriod = inputs.insurancePeriod;
      }
      if (inputs.make) {
        data.make = inputs.make;
      }
      if (inputs.mobileNo) {
        data.mobileNo = inputs.mobileNo;
      }
      if (inputs.name) {
        data.name = inputs.name;
      }
      if (inputs.nextService) {
        data.nextService = inputs.nextService;
      }
      if (inputs.owner) {
        data.owner = inputs.owner;
      }
      if (inputs.planValidity) {
        data.planValidity = inputs.planValidity;
      }
      if (inputs.roadTaxNo) {
        data.roadTaxNo = inputs.roadTaxNo;
      }
      if (inputs.roadTaxPeriod) {
        data.roadTaxPeriod = inputs.roadTaxPeriod;
      }
      if (inputs.roadTaxRenewDate) {
        data.roadTaxRenewDate = inputs.roadTaxRenewDate;
      }
      if (inputs.serviceDate) {
        data.serviceDate = inputs.serviceDate;
      }
      if (inputs.simCardSerialNo) {
        data.simCardSerialNo = inputs.simCardSerialNo;
      }
      if (inputs.unladenWeight) {
        data.unladenWeight = inputs.unladenWeight;
      }
      if (inputs.vehicleNo) {
        data.vehicleNo = inputs.vehicleNo;
      }
      if (inputs.vehicleType) {
        data.vehicleType = inputs.vehicleType;
      }
      if (inputs.yearOfMfg) {
        data.yearOfMfg = inputs.yearOfMfg;
      }
      if (inputs.rfidNo) {
        data.rfidNo = inputs.rfidNo;
      }
      //Update
      await DB.vehicle.update(data, {
        where: { deviceId },
      });
      //Response
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Vehicle Details updated!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Delete Vehicle
  static deleteVehicle = async (ctx, next) => {
    try {
      //Get deviceId
      const deviceId = ctx.params.deviceId;
      // Check if any vehicle exists with this deviceId
      const checkVehicle = await DB.vehicle.findOne({
        raw: true,
        where: {
          deviceId,
        },
      });
      if (!checkVehicle) {
        return Response.badRequest(ctx, {
          code: 20,
          msg: "Vehicle does not exists!",
        });
      }
      //Remove Vehicle
      await DB.vehicle.destroy({
        where: {
          deviceId,
        },
      });
      //Response
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Vehicle Removed!",
        data: {},
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get Vehicle reminder
  static getVehicleReminder = async (ctx, next) => {
    try {
      //Find this vehicle
      const vehicles = await DB.vehicle.findAll({
        include: [
          {
            model: DB.driver,
            include: [
              { model: DB.user, attributes: ["id", "name", "email", "mobile"] },
            ],
          },
        ],
      });
      //
      if (vehicles.length < 1) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No vehicle Found!",
          data: [],
        });
      }
      //Data
      let data = [];
      vehicles.map((vehicle) => {
        //
        let reminders = {
          serviceReminder: false,
          serviceDate: "N/A",
          insuranceReminder: true,
          insuranceDate: "N/A",
          roadTaxReminder: false,
          roadTaxRenewDate: "N/A",
          driverLicenseReminder: false,
          driverLicenseDate: "N/A",
        };
        //Dates
        reminders.serviceDate = vehicle.nextService;
        reminders.insuranceDate = vehicle.insuranceDate;
        reminders.roadTaxRenewDate = vehicle.roadTaxRenewDate;

        //Service reminder
        if (Moment(reminders.serviceDate).diff(Moment(), "days") <= 30) {
          reminders.serviceReminder = true;
        }
        if (Moment(reminders.insuranceDate).diff(Moment(), "days") <= 30) {
          reminders.insuranceReminder = true;
        }
        if (Moment(reminders.roadTaxRenewDate).diff(Moment(), "days") <= 30) {
          reminders.roadTaxReminder = true;
        }
        if (vehicle.driver) {
          reminders.driverLicenseDate = vehicle.driver.licenseExpiredAt;
          if (
            Moment(reminders.driverLicenseDate).diff(Moment(), "days") <= 30
          ) {
            reminders.driverLicenseReminder = true;
          }
        }
        data.push({ vehicleName: vehicle.name, reminders });
      });
      //Sort Dates
      data = _.sortBy(data, function (o) {
        return new Moment(o.serviceDate);
      });
      data = _.orderBy(
        data,
        function (o) {
          return new Moment(o.serviceDate);
        },
        ["desc"]
      );
      //Return
      return Response.created(ctx, {
        code: 21,
        msg: "Records found!",
        data: data,
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get Vehicle stats
  static getVehicleStats = async (ctx, next) => {
    console.log(momentNow);
    try {
      //
      let stats = {
        moving: 11,
        idle: 3,
        online: 14,
        offline: 0,
        ogCount: 0,
        alarms: 0,
      };
      //All Vehicles with data - in last 5 min
      // const vehicles = await DB.vehicle.findAll({
      //   attributes: ["deviceId"],
      //   include: [
      //     {
      //       model: DB.raw_data,
      //       as: "data",
      //       where: {
      //         [Op.and]: [
      //           Sequelize.where(
      //             Sequelize.literal("data->'data'->>'engOn'"),
      //             "=",
      //             "1"
      //           ),
      //           Sequelize.where(
      //             Sequelize.literal("time"),
      //             ">=",
      //             Moment(momentNow)
      //               .subtract(5, "minutes")
      //               .format("YYYY-MM-DD HH:mm:ss")
      //           ),
      //           Sequelize.where(Sequelize.literal("time"), "<=", momentNow),
      //         ],
      //       },
      //       attributes: [
      //         [DB.sequelize.literal(`data->'data'->'lat'`), "lat"],
      //         [DB.sequelize.literal(`data->'data'->'lon'`), "lon"],
      //         "deviceId",
      //         "time",
      //       ],
      //       limit: 2,
      //       order: [["time", "desc"]],
      //     },
      //   ],
      // });
      //All Vehicles with data - in last 10 min
      // const vehiclesOnline = await DB.vehicle.findAll({
      //   attributes: ["deviceId"],
      //   include: [
      //     {
      //       model: DB.raw_data,
      //       as: "data",
      //       where: {
      //         [Op.and]: [
      //           Sequelize.where(
      //             Sequelize.literal("data->'data'->>'engOn'"),
      //             "=",
      //             "1"
      //           ),
      //           Sequelize.where(
      //             Sequelize.literal("time"),
      //             ">=",
      //             Moment(momentNow)
      //               .subtract(10, "minutes")
      //               .format("YYYY-MM-DD HH:mm:ss")
      //           ),
      //           Sequelize.where(Sequelize.literal("time"), "<=", momentNow),
      //         ],
      //       },
      //       attributes: ["deviceId", "time"],
      //       limit: 1,
      //     },
      //   ],
      // });
      // //Moving/Idle
      // vehicles.map((vehicle) => {
      //   //
      //   if (vehicle.data.length > 0) {
      //     //Update moving
      //     stats.moving += 1;
      //   }
      // });
      // vehiclesOnline.map((vehicle) => {
      //   if (vehicle.data.length > 0) {
      //     //Update Online
      //     stats.online += 1;
      //   }
      // });
      //Update idle
      // stats.idle = vehicles.length - stats.moving;
      // //Update Offline
      // stats.offline = vehicles.length - stats.online;
      // // Alerts List
      // const alerts = await DB.alert.count({});
      // //Update alarms
      // stats.alarms = alerts;

      const ogCount = await DB.alert.count({
        where: { alertType: "og" },
      });
      const alarmCount = await DB.alert.count({});
      stats.ogCount = ogCount;
      stats.alarms = alarmCount;
      //Return
      return Response.created(ctx, {
        code: 21,
        msg: "Records found!",
        data: stats,
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get vehicle types
  static getVehicleTypes = async (ctx, next) => {
    try {
      // Vehicle Types
      const types = await DB.vehicle_types.findAll({
        raw: true,
      });

      if (types.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: types,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //All Units
  static getUnits = async (ctx, next) => {
    // Find all units
    try {
      // Units
      const units = await DB.unit.findAll({
        raw: true,
      });

      if (units.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: units,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Alerts
  static getAlerts = async (ctx, next) => {
    //Get date range
    const fromDate = ctx.query.fromDate;
    const toDate = ctx.query.toDate;

    //Get report type
    const reportType = ctx.query.type;
    if (fromDate) {
      if (toDate) {
        try {
          let alerts = await DB.sequelize.query(
            `SELECT 
          a."time" as time, 
          a.id as "slNo", 
          v2."name" as "vehicleName",
          u."name" as "driverName",
          a."alertType" as alert, 
          a."alertLevel" as level, 
          a."deviceId" as "vehiNum", 
          a."desc" as description, 
          a.severity as severity, 
          a.resolved as resolved, 
          a."resolvedBy" as "resolvedBy", 
          a."resolvedAt" as "resolvedAt" 
          FROM alerts a
          INNER JOIN vehicles v2 ON v2."deviceId" = a."deviceId" 
          INNER JOIN drivers d ON d."deviceId" = a."deviceId" 
          INNER JOIN users u ON u.id = d."userId" 
          WHERE a."time" >= :fromDate AND a."time" <= :toDate
          order by time desc;`,
            {
              replacements: { fromDate, toDate },
              type: QueryTypes.SELECT,
            }
          );

          let keys = [];
          let values = [];

          let map = await alerts.map((data) => {
            let columns = Object.keys(data);
            if (keys.length == 0) {
              keys.push(columns);
            }

            let value = Object.values(data);
            values.push(value);
          });

          Promise.all(map).then(async (data) => {
            let columns = [
              "time",
              "slNo",
              "vehicleName",
              "driverName",
              "alert",
              "level",
              "vehiNum",
              "description",
              "severity",
              "resolved",
              "resolvedBy",
              "resolvedAt",
            ];
            return Response.success(ctx, {
              statusCode: 200,
              code: 20,
              msg: alerts.length > 0 ? "Records Found" : "No Records Found!",
              data: { columns: columns, data: values },
            });
          });
        } catch (err) {
          console.log(err);
          return Response.error(ctx, {
            statusCode: 500,
            code: 50,
            msg: "Internal Error",
            error: err,
          });
        }
      } else {
        return Response.error(ctx, {
          statusCode: 200,
          code: 20,
          msg: "To date is required",
          data: [],
        });
      }
    } else {
      return Response.error(ctx, {
        statusCode: 200,
        code: 20,
        msg: "From date is required",
        data: [],
      });
    }
  };
  //Add routes
  static AddRoute = async (ctx, next) => {
    //Get Input
    const input = ctx.request.body;

    const schema = Joi.object({
      name: Joi.string(),
      route: Joi.array().required(),
    });
    try {
      //Validate
      const value = await schema.validateAsync(input);
      try {
        // Add route
        await DB.route.create({
          name: value.name,
          route: value.route,
          status: false,
        });
        return Response.created(ctx, {
          code: 21,
          msg: "Route Added!",
          data: {},
        });
      } catch (err) {
        console.log(err);
        return Response.error(ctx, {
          statusCode: 500,
          code: 50,
          msg: "Internal Error",
          error: err,
        });
      }
    } catch (err) {
      console.log(err);
      return Response.unprocessableEntity(ctx, {
        code: 42,
        msg: "Invalid request data !",
      });
    }
  };
  //Get Routes
  static getRoutes = async (ctx, next) => {
    try {
      //Get
      const routes = await DB.route.findAll({});
      //If Data
      if (routes.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: routes,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update Routes
  static updateRoutes = async (ctx, next) => {
    try {
      //find
      const id = ctx.params.routeId;
      //Get Input
      const input = ctx.request.body;
      //Validate
      const schema = Joi.object({
        name: Joi.string(),
        route: Joi.array(),
      });
      try {
        //Validate
        await schema.validateAsync(input);
      } catch (err) {
        console.log(err);
        return Response.unprocessableEntity(ctx, {
          code: 42,
          msg: "Invalid request data !",
        });
      }

      //Route exists
      const routeExists = await DB.route.findOne({ where: { id } });

      if (!routeExists) {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Route not exits!",
        });
      }
      let data = {};
      if (input.name) {
        data.name = input.name;
      }
      if (input.route) {
        data.route = input.route;
      }
      const updateRoute = await DB.route.update(data, {
        where: { id: id },
      });
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Route updated!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Delete Route
  static deleteRoute = async (ctx, next) => {
    try {
      //find
      const id = ctx.params.routeId;

      //Route exists
      const routeExists = await DB.route.findOne({ where: { id } });

      if (!routeExists) {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Route not exits!",
        });
      }
      await DB.route.destroy({
        where: {
          id,
        },
      });
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Route Removed!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Add polygon
  static AddPolygon = async (ctx, next) => {
    //Get Input
    const input = ctx.request.body;
    const schema = Joi.object({
      name: Joi.string(),
      polygon: Joi.array().required(),
    });
    try {
      //Validate
      const value = await schema.validateAsync(input);
      try {
        // Add route
        await DB.polygon.create({
          name: value.name,
          polygon: value.polygon,
          status: false,
        });
        return Response.created(ctx, {
          code: 21,
          msg: "Polygon Added!",
          data: {},
        });
      } catch (err) {
        console.log(err);
        return Response.error(ctx, {
          statusCode: 500,
          code: 50,
          msg: "Internal Error",
          error: err,
        });
      }
    } catch (err) {
      console.log(err);
      return Response.unprocessableEntity(ctx, {
        code: 42,
        msg: "Invalid request data !",
      });
    }
  };
  //Get Polygons
  static getPolygons = async (ctx, next) => {
    try {
      //Get
      const polygons = await DB.polygon.findAll({});
      //If Data
      if (polygons.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: polygons,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update Polygon
  static updatePolygon = async (ctx, next) => {
    try {
      //find
      const id = ctx.params.polygonId;
      //Get Input
      const input = ctx.request.body;
      //Validate
      const schema = Joi.object({
        name: Joi.string(),
        polygon: Joi.array(),
      });
      try {
        //Validate
        await schema.validateAsync(input);
      } catch (err) {
        console.log(err);
        return Response.unprocessableEntity(ctx, {
          code: 42,
          msg: "Invalid request data !",
        });
      }

      //PolygonId exists
      const polygonExists = await DB.polygon.findOne({ where: { id } });

      if (!polygonExists) {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Polygon not exits!",
        });
      }
      let data = {};
      if (input.name) {
        data.name = input.name;
      }
      if (input.polygon) {
        data.polygon = input.polygon;
      }
      //Update
      await DB.polygon.update(data, {
        where: { id: id },
      });
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Polygon updated!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Delete polygon
  static deletePolygons = async (ctx, next) => {
    try {
      //find
      const id = ctx.params.polygonId;

      //PolygonId exists
      const polygonExists = await DB.polygon.findOne({ where: { id } });

      if (!polygonExists) {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Polygon not exits!",
        });
      }
      await DB.polygon.destroy({
        where: {
          id,
        },
      });
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Polygon Removed!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update vehicle with one route
  static updateVehicleRoute = async (ctx, next) => {
    try {
      //find
      const deviceId = ctx.params.deviceId;
      //Get Input
      const input = ctx.request.body;
      //Validate
      const schema = Joi.object({
        routeId: Joi.number().required(),
      });
      try {
        //Validate
        await schema.validateAsync(input);
      } catch (err) {
        console.log(err);
        return Response.unprocessableEntity(ctx, {
          code: 42,
          msg: "Invalid request data !",
        });
      }
      //Route exists
      const routeExists = await DB.route.findOne({
        where: { id: input.routeId },
      });

      if (!routeExists) {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Route does not exist!",
        });
      }
      //Find this vehicle
      const vehicle = await DB.vehicle.findOne({
        raw: true,
        where: { deviceId },
      });

      //
      if (!vehicle) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No vehicle Found!",
          data: {},
        });
      }
      //Update
      await DB.vehicle.update(
        { routeId: input.routeId },
        {
          where: { deviceId: deviceId },
        }
      );
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Route assigned",
        data: {},
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update vehicle with one polygon
  static updateVehiclePolygon = async (ctx, next) => {
    try {
      //find
      const deviceId = ctx.params.deviceId;
      //Get Input
      const input = ctx.request.body;
      //Validate
      const schema = Joi.object({
        polygonId: Joi.number().required(),
      });
      try {
        //Validate
        await schema.validateAsync(input);
      } catch (err) {
        console.log(err);
        return Response.unprocessableEntity(ctx, {
          code: 42,
          msg: "Invalid request data !",
        });
      }

      //PolygonId exists
      const polygonExists = await DB.polygon.findOne({
        where: { id: input.polygonId },
      });

      if (!polygonExists) {
        return Response.notFound(ctx, {
          code: 20,
          msg: "Polygon does not exist!",
        });
      }
      //Find this vehicle
      const vehicle = await DB.vehicle.findOne({
        raw: true,
        where: { deviceId },
      });

      //
      if (!vehicle) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No vehicle Found!",
          data: {},
        });
      }
      //Update
      await DB.vehicle.update(
        { polygonId: input.polygonId },
        {
          where: { deviceId: deviceId },
        }
      );
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Polygon assigned!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Vehicle live data
  static getVehicleLiveData = async (ctx, next) => {
    //Get Device ID
    const deviceId = ctx.params.deviceId;
    //Get date range
    const fromDate = ctx.query.fromDate;
    const toDate = ctx.query.toDate;
    // Find one device Device
    try {
      //Find this device
      const device = await DB.vehicle.findOne({
        raw: true,
        where: { deviceId },
      });

      if (!device) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Vehicle Found!",
          data: [],
        });
      }

      // Device raw data
      let liveData = [];
      if (fromDate && toDate) {
        liveData = await DB.raw_data.findAll({
          attributes: [
            [DB.sequelize.literal(`data->'data'->'lat'`), "lat"],
            [DB.sequelize.literal(`data->'data'->'lon'`), "lon"],
            [DB.sequelize.literal(`data->'data'->'packetType'`), "type"],
            "time",
          ],
          raw: true,
          where: {
            [Op.and]: [
              { deviceId },
              Sequelize.where(Sequelize.literal("time"), ">=", fromDate),
              Sequelize.where(Sequelize.literal("time"), "<=", toDate),
            ],
          },
          include: [
            {
              model: DB.vehicle,
              attributes: ["name", "vehicleType"],
            },
          ],
          order: [["time", "desc"]],
        });

        // if (liveData.length < 1) {
        //   //Return last 10 data
        //   liveData = await DB.raw_data.findAll({
        //     raw: true,
        //     where: {
        //       deviceId,
        //     },
        //     limit: 10,
        //     order: [["time", "desc"]],
        //   });
        // }
      } else {
        liveData = await DB.raw_data.findAll({
          attributes: [
            [DB.sequelize.literal(`data->'data'->'lat'`), "lat"],
            [DB.sequelize.literal(`data->'data'->'lon'`), "lon"],
            [DB.sequelize.literal(`data->'data'->'packetType'`), "type"],
            "time",
          ],
          raw: true,
          include: [
            {
              model: DB.vehicle,
              attributes: ["name", "vehicleType"],
            },
          ],
          limit: 1,
          order: [["time", "desc"]],
        });
      }
      //If Data
      if (liveData.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: liveData,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Alerts counts
  static getAlertsCounts = async (ctx, next) => {
    let days = 7;

    if (ctx.query.days) {
      days = parseInt(ctx.query.days) - 1;
    }

    let now = Moment().set({ hour: 23, minute: 59, second: 59 });
    let currentDate = Moment(now).format("YYYY-MM-DD HH:mm:ss");
    let toDate = Moment(currentDate).format("YYYY-MM-DD HH:mm:ss");
    let fromDate = Moment()
      .add(-days, "days")
      .set({ hour: 0, minute: 0, second: 0 })
      .format("YYYY-MM-DD HH:mm:ss"); //Set range
    let fromDateToList = Moment().add(-days, "days").format("YYYY-MM-DD"); //Set range

    console.log("start date ", fromDate);
    console.log("end date ", toDate);

    function enumerateDaysBetweenDates(startDate, endDate) {
      let date = [];
      while (Moment(startDate) <= Moment(endDate)) {
        date.push(startDate);
        startDate = Moment(startDate).add(1, "days").format("YYYY-MM-DD");
      }
      return date;
    }

    const datesList = enumerateDaysBetweenDates(fromDateToList, toDate);

    console.log(datesList);
    //Get date range
    // const fromDate = ctx.query.fromDate;
    //const toDate = ctx.query.toDate;

    //Get report type
    try {
      let alerts = await DB.sequelize.query(
        `SELECT 
            time as date, 
            a."alertType" as alert           
            FROM alerts a            
            WHERE a."time" >= :fromDate AND a."time" <= :toDate
            order by time asc;`,
        {
          replacements: { fromDate, toDate },
          type: QueryTypes.SELECT,
        }
      );

      let defaultAlerts = [
        {
          alert: "ea",
          count: 0,
        },
        {
          alert: "in",
          count: 2,
        },
        {
          alert: "it",
          count: 3,
        },
        {
          alert: "bd",
          count: 0,
        },
        {
          alert: "br",
          count: 4,
        },
        {
          alert: "bl",
          count: 0,
        },
        {
          alert: "bc",
          count: 6,
        },
        {
          alert: "hb",
          count: 7,
        },
        {
          alert: "ha",
          count: 0,
        },
        {
          alert: "og",
          count: 4,
        },
        {
          alert: "hs",
          count: 2,
        },
        {
          alert: "or",
          count: 1,
        },
      ];

      function groupBy(array, f) {
        var groups = {};
        array.forEach(function (o) {
          var group = JSON.stringify(f(o));
          groups[group] = groups[group] || [];
          groups[group].push(o);
        });
        return Object.keys(groups).map(function (group) {
          return groups[group];
        });
      }

      var groupByTwo = groupBy(alerts, function (item) {
        return [item.date, item.alert];
      });

      let result = [];

      let map = await groupByTwo.map(async (arr) => {
        let obj = {};

        obj.date = arr[0].date;
        obj.alert = arr[0].alert;
        obj.count = arr.length;

        result.push(obj);
      });
      Promise.all(map).then(async (finalData) => {
        let groupBy = function (xs, key) {
          return xs.reduce(function (rv, x) {
            (rv[x[key]] = rv[x[key]] || []).push({
              alert: x.alert,
              count: x.count,
            });
            return rv;
          }, {});
        };

        let data = groupBy(result, "date");

        let dates = [];
        let values = [];
        // let dates = Object.keys(data);
        // let values = Object.values(data);

        function combineUnique(array1, array2) {
          let newArray = array1;
          array2.map((obj) => {
            let alert = obj.alert;
            let found = array1.some((obj) => obj.alert === alert);
            //console.log("found ", found);
            if (found) {
              newArray = newArray.filter((item) => item.alert !== alert);
            }
          });
          return newArray.concat(array2);
        }
        let map1 = datesList.map(async (date) => {
          //console.log(data[date]);
          if (data[date]) {
            dates.push(date);
            let filteredValue = data[date].filter(
              (item) => item.alert !== "nr"
            );
            let combinedValue = combineUnique(defaultAlerts, filteredValue);
            values.push(combinedValue);
          } else {
            dates.push(date);
            values.push(defaultAlerts);
          }
        });

        let finalResponse = [];
        for (let i = 0; i < dates.length; i++) {
          let obj = {
            date: dates[i],
          };
          let data = values[i];
          data.map((value) => {
            if (value.alert == "ea") {
              let alertType = "Emergency_Alert";
              obj[alertType] = value.count;
            }
            if (value.alert == "in") {
              let alertType = "Ignition_on";
              obj[alertType] = value.count;
            }
            if (value.alert == "it") {
              let alertType = "Idel_time";
              obj[alertType] = value.count;
            }
            if (value.alert == "bd") {
              let alertType = "Battery_disconnect";
              obj[alertType] = value.count;
            }
            if (value.alert == "br") {
              let alertType = "Battery_reconnect";
              obj[alertType] = value.count;
            }
            if (value.alert == "bl") {
              let alertType = "Battery_low";
              obj[alertType] = value.count;
            }
            if (value.alert == "bc") {
              let alertType = "Battery_current";
              obj[alertType] = value.count;
            }
            if (value.alert == "hb") {
              let alertType = "Harsh_breaking";
              obj[alertType] = value.count;
            }
            if (value.alert == "ha") {
              let alertType = "Harsh_acceleration";
              obj[alertType] = value.count;
            }
            if (value.alert == "og") {
              let alertType = "Out_of_Geofence";
              obj[alertType] = value.count;
            }
            if (value.alert == "hs") {
              let alertType = "High_speed";
              obj[alertType] = value.count;
            }
            if (value.alert == "or") {
              let alertType = "Out_of_Route";
              obj[alertType] = value.count;
            }
          });
          finalResponse.push(obj);
        }

        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: alerts.length > 0 ? "Records Found" : "No Records Found!",
          data: finalResponse,
        });
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Add Bulk vehicle
  static addBulkVehicle = async (ctx, next) => {
    //Get Input
    const inputs = ctx.request.body;

    //Input Validation Schema
    const schema = Joi.array().items(
      Joi.object({
        deviceId: Joi.string().required(),
        chassisNo: Joi.string().required(),
        engineNo: Joi.string().required(),
        existingPlan: Joi.string().required(),
        imei: Joi.string().required(),
        insuranceDate: Joi.date().required(),
        insuranceNo: Joi.string().required(),
        insurancePeriod: Joi.string().required(),
        make: Joi.string().required(),
        mobileNo: Joi.string().required(),
        name: Joi.string().required(),
        nextService: Joi.date().required(),
        owner: Joi.string().required(),
        planValidity: Joi.string().required(),
        roadTaxNo: Joi.string().required(),
        roadTaxPeriod: Joi.string().required(),
        roadTaxRenewDate: Joi.date().required(),
        serviceDate: Joi.date().required(),
        simCardSerialNo: Joi.string().required(),
        unladenWeight: Joi.string().required(),
        vehicleNo: Joi.string().required(),
        vehicleType: Joi.number().required(),
        yearOfMfg: Joi.string().required(),
        odoNumber: Joi.string(),
      })
    );

    try {
      //Validate
      await schema.validateAsync(inputs);
      const validDeviceIds = [];
      let newInputs = [];
      //Get all Unassigned devices
      const devices = await DB.device.findAll({
        raw: true,
        attributes: ["deviceId"],
        include: [
          {
            model: DB.vehicle,
            attributes: ["id"],
          },
        ],
      });
      if (devices.length > 0) {
        devices.map((device) => {
          if (device["vehicle.id"] == null) {
            validDeviceIds.push(device.deviceId);
          }
        });
      }
      if (devices.length < 1 || validDeviceIds.length < 1) {
        return Response.conflict(ctx, {
          code: 20,
          msg: "Devices does not exist!",
        });
      }

      //Filter valid device records
      //Make new final array
      inputs.map((input) => {
        if (validDeviceIds.includes(input.deviceId)) {
          const found = newInputs.some((b) => b.deviceId === input.deviceId);
          if (!found) {
            newInputs.push(input);
          }
        }
      });

      if (newInputs.length < 1) {
        return Response.conflict(ctx, {
          code: 20,
          msg: "Devices does not exist!",
        });
      }

      const t = await DB.sequelize.transaction();
      try {
        //Save all new devices
        await DB.vehicle.bulkCreate(newInputs, { transaction: t });
        // If the execution reaches this line, no errors were thrown.
        // We commit the transaction.
        await t.commit();
        return Response.created(ctx, {
          code: 21,
          msg: "Vehicles Added!",
          data: {},
        });
      } catch (error) {
        console.log(error);
        // If the execution reaches this line, an error was thrown.
        // We rollback the transaction.
        await t.rollback();
        //Response
        return Response.badRequest(ctx, {
          code: 20,
          msg: "Vehicle could not added!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.unprocessableEntity(ctx, {
        code: 42,
        msg: "Please provide valid data !",
      });
    }
  };
};
