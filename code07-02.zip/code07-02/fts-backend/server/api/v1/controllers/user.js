"use strict";
//Import Axios
const Axios = require("axios");
//Import JWT
const Jwt = require("jsonwebtoken");
//Import Joi
const Joi = require("@hapi/joi");
//Import Bcrypt
const Bcrypt = require("bcrypt");
//Import Sequelize
const Sequelize = require("sequelize");
//User Schema
const Schema = require("./../db/models/Schema");
//Import Settings
const {
  jwtSignature,
  loginAPIServer,
  dsAPIKey,
} = require("./../../../config/adaptor");
//Import PG Models
const DB = require("./../db/models/pg");

//Import Response Util
const Response = require("../utils/response");
//Import Multer
const Multer = require("@koa/multer");
//Auth Controller
module.exports = class AuthHandler {
  constructor() {}
  //Signin
  static async signin(ctx, next) {
    const { email, password } = ctx.request.body;
    if (!email || !password) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      // Check if user exists locally
      const checkUser = await DB.user.findAll({
        where: {
          email,
        },
      });
      //If exists
      if (checkUser.length == 1) {
        const passwordCheck = await Bcrypt.compareSync(
          password,
          checkUser[0]["password"]
        );
        // const hashedPassword = await Bcrypt.hash("aqm@d2c@123", 12);
        // console.log(hashedPassword);
        if (!passwordCheck) {
          return Response.unauthorized(ctx, {
            statusCode: 401,
            code: 41,
            msg: "Password does not match!",
          });
        }
        //JWT generate - accessToken
        const accessToken = Jwt.sign(
          {
            id: checkUser[0]["id"],
            name: checkUser[0]["name"],
            email: checkUser[0]["email"],
            isAdmin: true,
          },
          jwtSignature.accessSecret,
          {
            expiresIn: "12h",
          }
        );
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Successful login!",
          data: {
            name: checkUser[0]["name"],
            email: checkUser[0]["email"],
            token: accessToken,
          },
        });
      } else {
        const response = await Axios({
          method: "POST",
          url: `${loginAPIServer}/signin`,
          headers: {
            Authorization: `Bearer ${dsAPIKey}`,
          },
          data: { email, password },
        });
        //JWT generate - accessToken
        const accessToken = Jwt.sign(
          {
            id: null,
            name: response.data.data.results.name,
            email: response.data.data.results.email,
            isAdmin: true,
          },
          jwtSignature.accessSecret,
          {
            expiresIn: "12h",
          }
        );
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Successful login!",
          data: {
            name: response.data.data.results.name,
            email: response.data.data.results.email,
            token: accessToken,
          },
        });
      }
    } catch (err) {
      console.log(err);
      if (err.response && err.response.data.error) {
        return Response.unauthorized(ctx, {
          statusCode: 401,
          code: 41,
          msg: err.response.data.error.msg,
        });
      } else {
        return Response.error(ctx, {
          statusCode: 500,
          code: 50,
          msg: "Internal Error",
          error: err,
        });
      }
    }
  }
  //All Users
  static getAllUsers = async (ctx, next) => {
    let selectFields = [];
    //Get User Schema
    const schemaObj = Schema().UserSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    try {
      // Check if user exists
      const users = await DB.user.findAll({
        raw: true,
        attributes: selectFields,
        where: {
          isStaff: false,
        },
      });
      console.log(users);
      if (users.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: users,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
        });
      }
    } catch (err) {
      // console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Add Users
  static addUser = async (ctx, next) => {
    //Get Input
    const { name, email, mobile, address, password } = ctx.request.body;
    if (!name || !email || !password || !mobile || !address) {
      return Response.badRequest(ctx, {
        code: 40,
        msg: "Please provide valid data !",
      });
    }
    try {
      const Op = Sequelize.Op;
      // Check if user exists
      const checkUser = await DB.user.findAll({
        where: {
          [Op.or]: [{ email }, { mobile }],
        },
      });
      if (checkUser.length < 1) {
        //Hash the password
        const hash = Bcrypt.hashSync(password, 10);
        // Create a new user
        const newUser = await DB.user.create({
          name,
          email,
          mobile,
          address,
          isAdmin: false,
          password: hash,
        });
        //Remove password
        // const { password, ...data } = newUser.dataValues;
        return Response.created(ctx, {
          code: 21,
          msg: "User Added!",
          data: {
            id: newUser.id,
            name: newUser.name,
            email: newUser.email,
            mobile: newUser.mobile,
            address: newUser.address,
          },
        });
      } else {
        return Response.conflict(ctx, {
          code: 20,
          msg: "User already exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  //Update Users
  static updateUser = async (ctx, next) => {
    //Get userId
    const userId = ctx.params.userId;
    // Check if userId exists
    const userDetails = await DB.user.findOne({
      where: {
        id: userId,
      },
    });

    if (!userDetails) {
      return Response.badRequest(ctx, {
        code: 20,
        msg: "User does not exists!",
      });
    }

    const { name, email, mobile, address, password } = ctx.request.body;
    try {
      let data = {};
      if (name) {
        data.name = name;
      }
      if (email) {
        const userExists = await DB.user.findOne({
          where: {
            email,
          },
        });
        //If User exists with email/mobile
        if (userExists) {
          return Response.conflict(ctx, {
            code: 20,
            msg: "Email already exits!",
          });
        }
      }

      if (mobile) {
        data.mobile = mobile;
        // Check if user exists
        const userExists = await DB.user.findOne({
          where: {
            mobile,
          },
        });
        //If User exists with email/mobile
        if (userExists) {
          return Response.conflict(ctx, {
            code: 20,
            msg: "Phone Number already exits!",
          });
        }
      }

      if (address) {
        data.address = address;
      }
      if (password) {
        //Hash the password
        const hash = Bcrypt.hashSync(password, 10);
        data.password = hash;
      }

      const updateUser = await DB.user.update(data, {
        where: { id: userId },
      });
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "User Details updated!",
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Add Drivers
  static addDriver = async (ctx, next) => {
    try {
      const storage = Multer.diskStorage({
        destination: function (req, file, cb) {
          cb(null, "./images/");
        },
        filename: function (req, file, cb) {
          cb(null, file.originalname);
        },
      });
      //Upload Pic
      const upload = Multer({
        storage: storage,
        limits: {
          // 100 mb
          fileSize: 1024 * 1024 * 10,
        },
      }).single("pic");
      //Get form data
      await upload(ctx, async () => {
        //Get Input
        const inputs = ctx.request.body;
        //Input Validation Schema
        const schema = Joi.object({
          name: Joi.string().required(),
          email: Joi.string()
            .email({ minDomainSegments: 2, tlds: { allow: ["com", "in"] } })
            .required(),
          mobile: Joi.string()
            .length(10)
            .pattern(/^[0-9]+$/)
            .required(),
          address: Joi.string().required(),
          password: Joi.string().required(),
          deviceId: Joi.string(),
          dob: Joi.date().required(),
          city: Joi.string().required(),
          emMobileNo: Joi.string().required(),
          emp: Joi.string().required(),
          licenseNo: Joi.string().required(),
          licenseExpiredAt: Joi.date().required(),
          idCardNo: Joi.string().required(),
          bloodGroup: Joi.string().required(),
          pic: Joi.any(),
        });
        try {
          //Validate
          await schema.validateAsync(inputs);
        } catch (err) {
          console.log(err);
          return Response.unprocessableEntity(ctx, {
            code: 42,
            msg: "Please provide valid data !",
          });
        }
        try {
          const Op = Sequelize.Op;
          // Check if user exists
          const checkUser = await DB.user.findOne({
            raw: true,
            where: {
              [Op.or]: [{ email: inputs.email }, { mobile: inputs.mobile }],
            },
          });
          if (checkUser) {
            return Response.conflict(ctx, {
              code: 20,
              msg: "Staff already exits!",
            });
          }

          //Hash the password
          const hash = Bcrypt.hashSync(inputs.password, 10);
          // Create a new user
          const newUser = await DB.user.create({
            name: inputs.name,
            email: inputs.email,
            mobile: inputs.mobile,
            address: inputs.address,
            isAdmin: false,
            isStaff: true,
            password: hash,
          });
          //Add other driver details.
          // Create a new driver
          await DB.driver.create({
            userId: newUser.id,
            dob: inputs.dob,
            city: inputs.city,
            deviceId: inputs.deviceId,
            emMobileNo: inputs.emMobileNo,
            emp: inputs.emp,
            licenseNo: inputs.licenseNo,
            licenseExpiredAt: inputs.licenseExpiredAt,
            idCardNo: inputs.idCardNo,
            bloodGroup: inputs.bloodGroup,
          });

          return Response.created(ctx, {
            code: 21,
            msg: "Driver Added!",
            data: {
              id: newUser.id,
              name: newUser.name,
              email: newUser.email,
              mobile: newUser.mobile,
              address: newUser.address,
              isStaff: true,
            },
          });
        } catch (err) {
          console.log(err);
          return Response.error(ctx, {
            statusCode: 500,
            code: 50,
            msg: "Internal Error",
            error: err,
          });
        }
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //All Drivers
  static getDrivers = async (ctx, next) => {
    try {
      // Check if staffs exists
      const staffs = await DB.driver.findAll({
        raw: true,
        include: [
          {
            model: DB.user,
            as: "user",
            attributes: { exclude: ["password"] },
          },
        ],
      });
      if (staffs.length > 0) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records Found!",
          data: staffs,
        });
      } else {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "No Records Found!",
          data: [],
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update driver details
  static updateDriver = async (ctx, next) => {
    try {
      //Get userId
      const userId = ctx.params.userId;
      // Check if userId exists
      const checkDriver = await DB.driver.findOne({
        where: {
          userId,
        },
      });

      if (!checkDriver) {
        return Response.badRequest(ctx, {
          code: 20,
          msg: "Vehicle does not exists!",
        });
      }

      const storage = Multer.diskStorage({
        destination: function (req, file, cb) {
          cb(null, "./images/");
        },
        filename: function (req, file, cb) {
          cb(null, file.originalname);
        },
      });
      //Upload Pic
      const upload = Multer({
        storage: storage,
        limits: {
          // 100 mb
          fileSize: 1024 * 1024 * 10,
        },
      }).single("pic");
      //Get form data
      await upload(ctx, async () => {
        //Get Input
        const inputs = ctx.request.body;
        //Input Validation Schema
        const schema = Joi.object({
          name: Joi.string(),
          email: Joi.string().email({
            minDomainSegments: 2,
            tlds: { allow: ["com", "in"] },
          }),
          mobile: Joi.string()
            .length(10)
            .pattern(/^[0-9]+$/),
          address: Joi.string(),
          password: Joi.string(),
          deviceId: Joi.string(),
          dob: Joi.date(),
          city: Joi.string(),
          emMobileNo: Joi.string(),
          emp: Joi.string(),
          licenseNo: Joi.string(),
          licenseExpiredAt: Joi.date(),
          idCardNo: Joi.string(),
          bloodGroup: Joi.string(),
          pic: Joi.any(),
        });
        try {
          //Validate
          await schema.validateAsync(inputs);
        } catch (err) {
          console.log(err);
          return Response.unprocessableEntity(ctx, {
            code: 42,
            msg: "Please provide valid data !",
          });
        }
        try {
          if (inputs.email) {
            // Check if user exists
            const checkUser = await DB.user.findOne({
              raw: true,
              where: {
                email: inputs.email,
              },
            });
            if (checkUser) {
              return Response.conflict(ctx, {
                code: 20,
                msg: "Staff already exits!",
              });
            }
          }
          if (inputs.mobile) {
            // Check if user exists
            const checkUser = await DB.user.findOne({
              raw: true,
              where: {
                mobile: inputs.mobile,
              },
            });
            if (checkUser) {
              return Response.conflict(ctx, {
                code: 20,
                msg: "Staff already exits!",
              });
            }
          }
          //Data
          let userData = {};
          if (inputs.name) {
            userData.name = inputs.name;
          }
          if (inputs.email) {
            userData.email = inputs.email;
          }
          if (inputs.mobile) {
            userData.mobile = inputs.mobile;
          }
          if (inputs.address) {
            userData.address = inputs.address;
          }

          if (inputs.password) {
            //Hash the password
            const hash = Bcrypt.hashSync(inputs.password, 10);
            userData.password = hash;
          }

          //Update User
          await DB.user.update(userData, {
            where: { id: userId, isStaff: true },
          });
          //Update other driver details.
          //Data
          let driverData = {};
          if (inputs.dob) {
            driverData.dob = inputs.dob;
          }
          if (inputs.city) {
            driverData.city = inputs.city;
          }
          if (inputs.emMobileNo) {
            driverData.emMobileNo = inputs.emMobileNo;
          }
          if (inputs.emp) {
            driverData.emp = inputs.emp;
          }
          if (inputs.licenseNo) {
            driverData.licenseNo = inputs.licenseNo;
          }
          if (inputs.licenseExpiredAt) {
            driverData.licenseExpiredAt = inputs.licenseExpiredAt;
          }
          if (inputs.idCardNo) {
            driverData.idCardNo = inputs.idCardNo;
          }
          if (inputs.bloodGroup) {
            driverData.bloodGroup = inputs.bloodGroup;
          }
          // Update driver
          await DB.driver.update(driverData, {
            where: { userId },
          });

          return Response.created(ctx, {
            code: 21,
            msg: "Driver Updated!",
            data: {},
          });
        } catch (err) {
          console.log(err);
          return Response.error(ctx, {
            statusCode: 500,
            code: 50,
            msg: "Internal Error",
            error: err,
          });
        }
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Delete Driver
  static deleteDriver = async (ctx, next) => {
    try {
      //Get UserId
      const userId = ctx.params.userId;
      // Check if user exists
      const checkUser = await DB.user.findOne({
        where: {
          id: userId,
          isStaff: true,
        },
      });
      // Check if driver exists
      const checkDriver = await DB.driver.findOne({
        where: { userId },
      });
      //If No User/Driver
      if (!checkUser || !checkDriver) {
        return Response.badRequest(ctx, {
          code: 20,
          msg: "Driver does not exits!",
        });
      }
      //Remove User
      await DB.user.destroy({
        where: {
          id: userId,
          isStaff: true,
        },
      });
      //Remove Driver
      await DB.driver.destroy({
        where: {
          userId,
        },
      });
      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "Driver Removed!",
        data: {},
      });
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Get Profile
  static getProfile = async (ctx, next) => {
    //Get User
    const user = ctx.state.user;

    let selectFields = [];
    //Get User Schema
    const schemaObj = Schema().UserSchema;
    //Query field implementation
    if (ctx.query && ctx.query.fields) {
      const fields = ctx.query.fields;
      let tmpFields = fields.split(",");
      for (let i = 0; i < tmpFields.length; i++) {
        if (tmpFields[i].trim() in schemaObj) {
          //Push
          selectFields.push(tmpFields[i].trim());
        }
      }
    }
    //If no field provided
    if (selectFields.length < 1) {
      for (const property in schemaObj) {
        selectFields.push(property);
      }
    }
    if (!user || !user.id) {
      return Response.forbidden(ctx, {
        code: 41,
        msg: "Unauthorized",
      });
    }
    try {
      // Check if user exists
      const checkUser = await DB.user.findOne({
        where: {
          id: user.id,
        },
        attributes: selectFields,
      });
      if (checkUser) {
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Records found !",
          data: checkUser,
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "User does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
  //Update Profile
  static updateProfile = async (ctx, next) => {
    //Get User
    const user = ctx.state.user;
    if (!user || !user.id) {
      return Response.forbidden(ctx, {
        code: 41,
        msg: "Unauthorized",
      });
    }

    const { name, email, mobile, password, address } = ctx.request.body;
    try {
      // Update a user
      let data = {};
      if (name) {
        data.name = name;
      }
      if (email) {
        data.email = email;
        // Check if user exists
        const userExists = await DB.user.findOne({
          where: {
            email,
          },
        });
        //If User exists with email/mobile
        if (userExists) {
          return Response.conflict(ctx, {
            code: 20,
            msg: "User already exits!",
          });
        }
      }
      if (mobile) {
        data.mobile = mobile;
        // Check if user exists
        const userExists = await DB.user.findOne({
          where: {
            mobile,
          },
        });
        //If User exists with email/mobile
        if (userExists) {
          return Response.conflict(ctx, {
            code: 20,
            msg: "User already exits!",
          });
        }
      }
      if (address) {
        data.address = address;
      }
      if (password) {
        //Hash the password
        const hash = Bcrypt.hashSync(password, 10);
        data.password = hash;
      }
      // Check if user exists
      const checkUser = await DB.user.findOne({
        where: {
          id: user.id,
        },
      });
      if (checkUser) {
        //Update
        await DB.user.update(data, {
          where: { id: user.id },
        });
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "User Details updated!",
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "User does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };

  static deleteUser = async (ctx, next) => {
    try {
      //Get user id
      const userId = ctx.params.userId;

      if (!userId) {
        return Response.unprocessableEntity(ctx, {
          code: 42,
          msg: "Invalid request data !",
        });
      }
      // Check if user exists
      const checkUser = await DB.user.findOne({
        where: {
          id: userId,
        },
      });
      //If No User
      if (!checkUser) {
        return Response.badRequest(ctx, {
          code: 20,
          msg: "User does not exits!",
        });
      }
      //Remove User
      await DB.user.destroy({
        where: {
          id: userId,
        },
      });

      return Response.success(ctx, {
        statusCode: 200,
        code: 20,
        msg: "User Removed!",
        data: {},
      });
    } catch (error) {
      console.log(error);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: error,
      });
    }
  };

  static changePassword = async (ctx, next) => {
    try {
      console.log("change password");
      // return;
      const user = ctx.state.user;
      if (!user || !user.id) {
        return Response.forbidden(ctx, {
          code: 41,
          msg: "Unauthorized",
        });
      }

      const { password, repeatPassword } = ctx.request.body;

      //If No input data
      if (!password || !repeatPassword) {
        return Response.unprocessableEntity(ctx, {
          code: 42,
          msg: "Invalid request data !",
        });
      }

      if (password != repeatPassword) {
        return Response.badRequest(ctx, {
          code: 41,
          msg: "Password and Repeat Password are not same",
        });
      }

      let data = {};
      //Hash the password
      const hash = Bcrypt.hashSync(password, 10);
      data.password = hash;

      // Check if user exists
      const checkUser = await DB.user.findOne({
        where: {
          id: user.id,
        },
      });
      if (checkUser) {
        //Update
        await DB.user.update(data, {
          where: { id: user.id },
        });
        return Response.success(ctx, {
          statusCode: 200,
          code: 20,
          msg: "Password changed!",
        });
      } else {
        return Response.notFound(ctx, {
          code: 20,
          msg: "User does not exits!",
        });
      }
    } catch (err) {
      console.log(err);
      return Response.error(ctx, {
        statusCode: 500,
        code: 50,
        msg: "Internal Error",
        error: err,
      });
    }
  };
};
