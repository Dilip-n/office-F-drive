function myFun(rawData) {
  let date = rawData.substr(17, 6); //6
  let time = rawData.substr(23, 6); //6
  let obj = {};

  let myDate = `${date.substr(0, 2)}-${date.substr(2, 2)}-${date.substr(4, 2)}`;
  myDate = myDate.split("-");
  let newDate = myDate[1] + "/" + myDate[0] + "/" + myDate[2];

  let lat = `${rawData.substr(29, 4)}.${rawData.substr(33, 4)}`;
  let latDD = parseInt(lat.substr(0, 2)) + parseInt(lat.substr(2, 6)) / 60;

  let lang = `${rawData.substr(37, 5)}.${rawData.substr(42, 4)}`;
  let langDD = parseInt(lang.substr(0, 3)) + parseInt(lang.substr(3, 6)) / 60;

  obj.imei = rawData.substr(2, 15); //15
  obj.date = new Date(newDate).getTime() / 1000;
  obj.time = `${time.substr(0, 2)}:${time.substr(2, 2)}:${time.substr(
    4,
    2
  )} GMT `;

  obj.lat = `${latDD.toFixed(4)}`; //8
  obj.long = `${langDD.toFixed(4)}`; //9
  obj.speed = `${parseInt(`0x${rawData.substr(46, 2)}`)}`; //2
  obj.direction = `${parseInt(`0x${rawData.substr(48, 3)}`)}`; //3
  //obj.heading = `${parseInt(`0x${rawData.substr(48, 3)}`)}`; //3;
  let ewns = rawData.substr(51, 1); //
  if (ewns == "0") {
    obj.latDir = "N";
    obj.longDir = "E";
  }
  if (ewns == "1") {
    obj.latDir = "N";
    obj.longDir = "W";
  }
  if (ewns == "2") {
    obj.latDir = "S";
    obj.longDir = "E";
  }
  if (ewns == "3") {
    obj.latDir = "S";
    obj.longDir = "W";
  }

  let statValue = rawData.substr(52, 2); //2
  let binaryStat = parseInt(statValue, 10).toString(2);
  if (statValue < 2) {
    binaryStat = `000${binaryStat}`;
  }
  if (statValue == 2) {
    binaryStat = `00${binaryStat}`;
  }
  if (statValue == 3) {
    binaryStat = `00${binaryStat}`;
  }
  if (statValue <= 7 && statValue >= 4) {
    binaryStat = `0${binaryStat}`;
  }
  obj.stat = binaryStat;
  obj.engineOn = binaryStat.substr(0, 1);
  obj.roamingActive = binaryStat.substr(1, 1);
  obj.gpsAvilable = binaryStat.substr(2, 1);
  obj.digInp1 = binaryStat.substr(3, 1);

  obj.mileage = `${parseInt(`0x${rawData.substr(54, 5)}`)}`; //5
  obj.signal = rawData.substr(59, 2); //2
  let alarms = rawData.substr(62);
  obj.packetType = null;
  obj.packetStatus = "L";
  obj.gpsFix = null;
  obj.noOfSatellites = null;
  obj.altitude = null;
  obj.pdop = null;
  obj.hdop = null;
  obj.vdop = null;
  obj.igStatus = null;
  obj.mainPowerStatus = null;
  obj.batteryVolatge = null;
  obj.emergencyState = null;
  obj.tamperStatus = null;
  obj.di01 = null;
  obj.di02 = null;
  obj.di03 = null;
  obj.di04 = null;
  obj.di05 = null;
  obj.di06 = null;
  obj.do01 = null;
  obj.do02 = null;
  obj.ai01 = null;
  obj.ai02 = null;
  obj.distance = null;
  obj.seqNo = null;
  obj.datafrom = "GPS";
  obj.temperature = null;
  obj.rfid = null;
  obj.pgn = null;
  obj.batteryPercentage = null;
  obj.batteryCurrent = null;
  obj.lac = null;
  obj.cellId = null;
  obj.idelTimeInSec = null;

  obj.Others = {
    mcc: null,
    mnc: null,
    lac: null,
    firstNeighbour: {
      cellId: null,
      gsmStrength: null,
      lac: null,
    },
    secondNeighbour: {
      cellId: null,
      gsmStrength: null,
      lac: null,
    },
    thirdNeighbour: {
      cellId: null,
      gsmStrength: null,
      lac: null,
    },
    fourthNeighbour: {
      cellId: null,
      gsmStrength: null,
      lac: null,
    },
  };

  if (alarms) {
    let alarmsArr = alarms.split(";");

    for (let i = 0; i < alarmsArr.length; i++) {
      switch (alarmsArr[i].substr(0, 3)) {
        case "001":
          obj.packetType = "NR";
          obj.di01 = "passive ";
          break;
        case "002":
          obj.packetType = "NR";
          obj.di01 = "active";
          break;
        case "003":
          obj.packetType = "NR";
          obj.di02 = "passive";
          break;
        case "004":
          obj.packetType = "NR";
          obj.di02 = "active";
          break;
        case "005":
          obj.packetType = "SLV";
          break;
        case "007":
          obj.packetType = "RFID";
          obj.rfid = alarmsArr[i].substr(4);
          break;
        case "008":
          obj.packetType = "NR";
          obj.pgn = alarmsArr[i].substr(4);
          break;
        case "009":
          obj.packetType = "NR";
          break;
        case "00A":
          let hexString = alarmsArr[i].substr(4);
          obj.temperature = parseInt(hexString, 16);
          break;
        case "00C":
          obj.packetType = "NR";
          break;
        case "00D":
          obj.packetType = "EA";
          obj.mainPowerStatus = alarmsArr[i].substr(4);
          break;
        case "00E":
          obj.packetType = "BL";
          obj.batteryPercentage = alarmsArr[i].substr(4);
          break;
        case "00F":
          obj.packetType = "NR";
          break;
        case "019":
          obj.packetType = "NR";
          obj.packetStatus = "L";
          break;
        case "020":
          obj.packetType = "EA";
          obj.packetStatus = "L";
          break;
        case "022":
          obj.packetType = "NR";
          let params022 = alarmsArr[i].substr(4);
          params0221 = params022.split(",");
          obj.lac = params0221[0];
          obj.cellId = params0221[0];
          break;
        case "023":
          obj.packetType = "NR";
          obj.batteryCurrent = alarmsArr[i].substr(4);
          break;
        case "024":
          if ((alarmsArr[i].substr(4) = 1)) {
            obj.packetType = "IN";
            obj.igStatus = alarmsArr[i].substr(4);
          }

          if ((alarmsArr[i].substr(4) = 0)) {
            obj.packetType = "IF";
            obj.igStatus = alarmsArr[i].substr(4);
          }
          break;
        case "025":
          let params025 = alarmsArr[i].substr(4);
          let params0251 = params025.split(",");
          if ((params0251[0] = 1)) {
            obj.gpsFix = "NA";
          }

          if ((params0251[0] = 2)) {
            obj.gpsFix = "2D";
          }

          if ((params0251[0] = 3)) {
            obj.gpsFix = "3D";
          }

          obj.pdop = params0251[1];
          obj.hdop = params0251[2];
          obj.vdop = params0251[3];
          obj.noOfSatellites = params0251[4];
          break;
        case "026":
          let params026 = alarmsArr[i].substr(4);
          let params0261 = params026.split(",");
          obj.distance = params0261[1];
          obj.idelTimeInSec = params0261[3];
          break;
        case "028":
          obj.packetType = "SIMR";
          break;
        case "031":
          obj.packetType = "NR";
          obj.di03 = "deactivated ";
          break;
        case "032":
          obj.packetType = "NR";
          obj.di03 = "active";
          break;
        case "033":
          obj.packetType = "NR";
          obj.di04 = "deactivated";
          break;
        case "034":
          obj.packetType = "NR";
          obj.di04 = "active";
          break;
        case "035":
          obj.packetType = "NR";
          obj.di05 = "deactivated ";
          break;
        case "036":
          obj.packetType = "NR";
          obj.di05 = "active";
          break;
        case "037":
          obj.packetType = "NR";
          obj.di06 = "deactivated";
          break;
        case "038":
          obj.packetType = "NR";
          obj.di06 = "active";
          break;
        case "051":
          let params051 = alarmsArr[i].substr(4);
          params0511 = params051.split(",");
          obj.packetType = "HA";
          break;
        case "052":
          let params052 = alarmsArr[i].substr(4);
          params0521 = params052.split(",");
          obj.packetType = "HB";
          break;
        case "0AA":
          obj.packetType = "NR";
          break;
        case "102":
          obj.packetType = "NR";
          obj.datafrom = "GSM";
          break;
        case "104":
          obj.packetType = "NR";
          break;
        case "106":
          let params106 = alarmsArr[i].substr(4);
          params1061 = params106.split(",");
          obj.packetType = "NR";
          obj.batteryVolatge = params1061[5];
          break;
      }
    }
  }

  return obj;
}
let rawData = `[T353469042193425041212171601410374440285937850103A0250063931-008:FEFC00AA00AA00BB00BBFEEE1122334455667788]`;
//let rawData = `[T353469042193425041212171601410374440285937850103A0250063931- 007:42312356;00C]`;
//let rawData = `[T353469042193425041212171601410374440285937850103A0250063931-002]`;
//let rawData = `[T353469042240986041212144424410524100285250947514F012008D214-025:3,1.1,0.8,0.8,9;00F:f;019]`; // Trio mobile data actual message

//let rawData = `[T358021087054726260120224505125486940773796800003D00165C4727-025:3,1.1,0.8,0.8,9;00F:f;019]`; // Trio mobile data actual message
//let rawData = `[T353469042240986041212144424410524100285250947514F012008D214]`;
let output = myFun(rawData);
console.log("--------------Start--------------");

console.log(output);
//console.log("---------------------------------");

let db_data = {
  ts: output.date,
  DeviceID: output.imei,
  data: {
    time: output.time,
    latitude: output.latitude,
    longitude: output.longitude,
    speed: output.speed,
    direction: output.direction,
    ewns: output.ewns,
    stat: output.stat,
    mileage: output.mileage,
    signal: output.signal,
    day: output.day,
  },
};

console.log("--------------End--------------");
